// TODO: Create webpack config or task runner to mini/uglify this.
document.addEventListener('DOMContentLoaded', function() {
	const data = custom_payment_gateway_ajax_test_api_data;
	const main = document.querySelector('[action="options.php"]');
	const apiKey = document.querySelector('#custom_payment_gateway\\[api_key\\]', main);
	const apiUrl = document.querySelector('#custom_payment_gateway\\[api_url\\]', main);
	const messageId = 'custom_payment_gateway_ajax_test_api_message';
	const message = document.createElement('div');
	message.id = messageId;
	const apiKeyInitialValue = apiKey.value;
	const post_data = {
		nonce: data.nonce,
		action: data.action,
	};

	function postAjax(url, data, callback) {
		let xhr = new XMLHttpRequest();
		xhr.open('POST', url, true);
		xhr.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');
		xhr.onreadystatechange = function() {
			if (xhr.readyState === 4 && xhr.status === 200) {
				callback(xhr.responseText);
			}
		};
		let params = Object.keys(data)
			.map(function(key) {
				return encodeURIComponent(key) + '=' + encodeURIComponent(data[key]);
			})
			.join('&');
		xhr.send(params);
	}

	document.addEventListener('click', function(e) {
		if (e.target && e.target.id === 'custom_payment_gateway_ajax_test_api_button') {
			if (apiKey.value !== apiKeyInitialValue) {
				post_data.api_key = apiKey.value;
			}
			post_data.api_url = apiUrl.value;
			let spinner = document.createElement('span');
			spinner.className = 'spinner spinner--api-test is-active ';
			e.target.appendChild(spinner);
			postAjax(data.ajax_url, post_data, handle);
		}
	});

	function handle(response) {
		if (response) {
			response = JSON.parse(response);
			message.className = 'notice notice-' + response.status + ' is-dismissible';
			message.innerHTML = '<p>' + response.message + '</p>';
			let spinner = main.querySelector('.spinner--api-test');
			spinner.remove();
			if (!main.querySelector('#' + messageId)) {
				main.insertBefore(message, main.firstChild);
			}
		}
	}
});
