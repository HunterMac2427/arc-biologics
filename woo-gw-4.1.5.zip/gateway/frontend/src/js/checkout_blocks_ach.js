const custom_gateway_ach_data = window.wc.wcSettings.getSetting( 'custom_payment_gateway_ach_data', {} );
const custom_gateway_ach_label = window.wp.htmlEntities.decodeEntities( custom_gateway_ach_data.title )
    || window.wp.i18n.__( 'ACH Payment', 'custom_payment_gateway_ach' );
const custom_gateway_ach_content = () => {
    const setting = window.wc.wcSettings.getSetting( 'custom_payment_gateway_ach_data', {} );
    return window.wp.htmlEntities.decodeEntities( setting.description || 'Pay with ACH.' );
};
const ACHGateway = {
    name: 'custom_payment_gateway_ach',
    label: custom_gateway_ach_label,
    content: Object( window.wp.element.createElement )( custom_gateway_ach_content, null ),
    edit: Object( window.wp.element.createElement )( custom_gateway_ach_content, null ),
    canMakePayment: () => true,
    placeOrderButtonLabel: window.wp.i18n.__( 'Continue', 'custom_payment_gateway_ach' ),
    ariaLabel: custom_gateway_ach_label,
    supports: {
        features: custom_gateway_ach_data.supports,
    },
    value: "custom_payment_gateway_ach",
    paymentMethodId: 'custom_payment_gateway_ach',
};
window.wc.wcBlocksRegistry.registerPaymentMethod( ACHGateway );

