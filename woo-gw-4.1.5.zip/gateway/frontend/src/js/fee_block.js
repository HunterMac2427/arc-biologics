// TODO: convert to jQuery
// TODO: Create webpack config or task runner to mini/uglify this.
jQuery(document).ready(function ($) {
    initialize($);
});

async function waitForElement($, selector) {
    while ($(selector).length === 0) {
        await new Promise(resolve => setTimeout(resolve, 100));
    }
    return $(selector);
}

async function initialize($) {
    const extendCard = "#payment-extend-card";
    const extendAch = "#payment-extend-ach";
    await waitForElement($, extendCard);
    await waitForElement($, extendAch);
    $(extendCard).hide();
    $(extendAch).hide();
    await waitForElement($, '#radio-control-wc-payment-method-options-custom_payment_gateway_card');
    setUp($);
}

function setUp($) {
    const ccInputIdSelector = '#custom_payment_gateway_card_number';
    const selectedPaymentMethodSelector = 'input[name="radio-control-wc-payment-method-options"]:checked';
    const savedMethodsRadiosSelector = 'wc-saved-payment-methods input';
    const extendCard = "#payment-extend-card";
    const extendAch = "#payment-extend-ach";
    const updateTotals = "#update-totals";

    let card_element = $('#radio-control-wc-payment-method-options-custom_payment_gateway_card').parent().parent();
    $(extendCard).appendTo(card_element);
    let ach_element = $('#radio-control-wc-payment-method-options-custom_payment_gateway_ach').parent().parent();
    $(extendAch).appendTo(ach_element);
    $(updateTotals).appendTo('#payment-method');
    $("#achCompanyBlock").hide();
    showUpdateTotals("base_method_select");

    function showExtendBlock(type){
        if(type === "custom_payment_gateway_card") {
            $(extendCard).show();
            $(extendAch).hide();
            let card_element = $('#radio-control-wc-payment-method-options-custom_payment_gateway_card').parent().parent();
            $(extendCard).appendTo(card_element);
            $(updateTotals).appendTo(extendCard);
        } else if(type === "custom_payment_gateway_ach"){
            $(extendCard).hide();
            $(extendAch).show();
            let ach_element = $('#radio-control-wc-payment-method-options-custom_payment_gateway_ach').parent().parent();
            $(extendAch).appendTo(ach_element);
            $(updateTotals).appendTo(extendAch);
        } else{
            $(extendCard).hide();
            $(extendAch).hide();
            $(updateTotals).appendTo('#payment-method');
        }
    }

    let checked_payment_method = $('input[name="radio-control-wc-payment-method-options"]:checked');
    let payment_method = checked_payment_method.val() || "";
    showExtendBlock(payment_method);
    if(payment_method === ""){
        let first_type = "";
        if($('#radio-control-wc-payment-method-options-custom_payment_gateway_card').is(':checked')){
            first_type = "custom_payment_gateway_card";
        }
        if($('#radio-control-wc-payment-method-options-custom_payment_gateway_ach').is(':checked')){
            first_type = "custom_payment_gateway_ach";
        }
        checked_payment_method.val(first_type);
        showExtendBlock(first_type);
        showUpdateTotals("base_method_select");
    }

    $('input[name="radio-control-wc-payment-method-options"]').on('change', function() {
        showExtendBlock($('input[name="radio-control-wc-payment-method-options"]:checked').val());
        showUpdateTotals("base_method_select");
    });

    $('input[name="radio-control-wc-payment-method-saved-tokens"]').on('click', function () {
        $(extendCard).hide();
        $(extendAch).hide();
        showUpdateTotals("saved_method_select");
    });

    function isGwMethod() {
        return $.inArray($(selectedPaymentMethodSelector).val(), ['custom_payment_gateway_ach', 'custom_payment_gateway_card']) !== -1;
    }

    function showUpdateTotals(trigger) {
        let shouldShow = false;

        if (!isGwMethod()) {
            trigger = '';
            $(updateTotals).click();
        }

        if(trigger === 'base_method_select'){
            $(updateTotals).click();
            shouldShow = false;
        } else if(trigger === 'saved_method_select'){
            $(updateTotals).click();
            shouldShow = false;
        } else if(trigger === 'cc_input_change'){
            let number_length = $(ccInputIdSelector).val().replace(/\s+/g, '').length;
            if((number_length > 5 && number_length < 9) || number_length > 14) {
                $(updateTotals).click();
                shouldShow = false;
            } else{
                shouldShow = true;
            }
        }

        if (shouldShow) {
            $(updateTotals).show();
            $(".wc-block-components-checkout-place-order-button").prop("disabled", true);
        } else {
            $(updateTotals).hide();
            $(".wc-block-components-checkout-place-order-button").prop("disabled", false);
        }
    }
    //payment method change events
    $(ccInputIdSelector).off('keyup').keyup(function () {
        showUpdateTotals('cc_input_change');
    });
    $(ccInputIdSelector).on( "blur", function() {
        showUpdateTotals('cc_input_change');
        $(ccInputIdSelector).off("blur");
    });
    $(savedMethodsRadiosSelector).off('change').change(function () {
        showUpdateTotals('saved_method_select');
    });
    $(document).on('click','.woocommerce-SavedPaymentMethods-tokenInput', function () {
        showUpdateTotals('saved_method_select');
    });

    $('#accountSecCode').on('change', function() {
        if ($("#accountSecCode").val() === 'ccd') {
            $('#achCompanyBlock').show();
        } else {
            $('#achCompanyBlock').hide();
        }
    });
    //update billing or shipping address events
    $("#billing-postcode").on("blur", function () {
        $(updateTotals).click();
        $("#billing-postcode").off("blur");
    });
    $("#billing-state").on("change", function () {
        $(updateTotals).click();
    });
    $("#billing-country").on("change", function () {
        $(updateTotals).click();
    });
    $("#shipping-postcode").on("blur", function () {
        $(updateTotals).click();
        $("#shipping-postcode").off("blur");
    });
    $("#shipping-state").on("change", function () {
        $(updateTotals).click();
    });
    $("#shipping-country").on("change", function () {
        $(updateTotals).click();
    });

    let previous = '';
    setInterval(() => {
        const current = $(ccInputIdSelector).val();
        if (current && current !== previous) {
            previous = current;
            if ($(selectedPaymentMethodSelector).val() === 'custom_payment_gateway_card') {
                if ($(ccInputIdSelector).val().replace(/\s+/g, '').length > 5) {
                    showUpdateTotals('cc_input_change');
                }
            }
        }
    }, 500);
}