document.addEventListener('DOMContentLoaded', function() {
	function restoreActiveTab() {
        let activeTab = window.location.hash;
        if (!activeTab) {
            activeTab = localStorage.getItem('activeTab');
        }
        if (!activeTab) {
            const firstTab = document.querySelector('a[data-bs-toggle="pill"]');
            if (firstTab) {
                activeTab = firstTab.getAttribute('href');
            }
        }
        if (activeTab) {
            const tabLink = document.querySelector('a[data-bs-toggle="pill"][href="' + activeTab + '"]');
            if (tabLink) {
                const activeLinks = document.querySelectorAll('.nav-link.active');
                activeLinks.forEach(function(link) {
                    link.classList.remove('active');
                });
                tabLink.classList.add('active');
                tabLink.setAttribute('data-bs-toggle', 'pill');
                const activePanes = document.querySelectorAll('.tab-pane.fade.show.active');
                activePanes.forEach(function(pane) {
                    pane.classList.remove('show', 'active');
                });
                const tabPane = document.querySelector(activeTab);
                if (tabPane) {
                    tabPane.classList.add('show', 'active');
                }
            }

			handleHiddenOptions('#custom_payment_gateway\\[cash_discount\\]', '.cash_discount');
			handleHiddenOptions('#custom_payment_gateway\\[service_fee\\]', '.service_fee');
			handleHiddenOptions('#custom_payment_gateway_card\\[allow_surcharge\\]', '.allow_surcharge');
        }
    }

	function handleHiddenOptions(checkboxSelector, divSelector) {
		const divs = document.querySelectorAll(divSelector);
		const checkbox = document.querySelector(checkboxSelector);
		function updateDivDisplay() {
			divs.forEach(function(div) {
				if (!checkbox.checked) {
					div.classList.add("d-none");
				} else {
					div.classList.remove("d-none");
				}
			});
		}
        if (checkbox) {
            checkbox.addEventListener('change', updateDivDisplay);
        }
		updateDivDisplay();
	}

	window.addEventListener('hashchange', function() {
        document.querySelectorAll('.notice').forEach(e => e.hidden = true);
		restoreActiveTab();
    });

    const tabLinks = document.querySelectorAll('a[data-bs-toggle="pill"]');
    tabLinks.forEach(function(tabLink) {
        tabLink.addEventListener('click', function() {
            let activeTab = tabLink.getAttribute('href');
            window.location.hash = activeTab;
            localStorage.setItem('activeTab', activeTab);
        });
    });

    document.getElementById("custom_payment_gateway_troubleshooting[attachments]").addEventListener("change", function() {
        const list = document.getElementById("file-list");
        list.innerHTML = "";

        for (const file of this.files) {
            list.innerHTML += `<p>${file.name}</p>`;
        }
    });

	// Prevent double-submits (notably the "Sync Subscriptions" button) from kicking off two
	// concurrent server-side runs, which could otherwise create duplicate renewal orders.
	function guardFormSubmits() {
		const form = document.getElementById('custom_payment_gateway_form');
		if (!form) {
			return;
		}
		let submitting = false;
		const submitButtons = form.querySelectorAll('input[type="submit"]');
		const busyLabels = {
			submit_sync: 'Syncing...',
			submit_database: 'Running...'
		};
		submitButtons.forEach(function(button) {
			button.addEventListener('click', function(event) {
				if (submitting) {
					event.preventDefault();
					return;
				}
				submitting = true;
				// Defer disabling until after the browser has serialized the form, otherwise the
				// clicked submit button's name/value would be dropped from the POST and the server
				// would never see e.g. submit_sync.
				setTimeout(function() {
					submitButtons.forEach(function(otherButton) {
						otherButton.disabled = true;
					});
					if (busyLabels[button.id]) {
						button.value = busyLabels[button.id];
					}
				}, 0);
			});
		});
	}

	guardFormSubmits();

	restoreActiveTab();
});
