// TODO: convert to jQuery
// TODO: Create webpack config or task runner to mini/uglify this.
jQuery(document).ready(function ($) {
    var $body = $('body');

    var ccInputIdSelector = '#custom_payment_gateway_card_number';
    var selectedPaymentMethodSelector = 'input[name="payment_method"]:checked';
    var savedPaymentMethodTokenInput = '.woocommerce-SavedPaymentMethods-tokenInput';

    var ccInputVal = $(ccInputIdSelector).val();
    var selectedPaymentMethodVal = $(selectedPaymentMethodSelector).val();
    var selectedSavedMethodVal = $(savedPaymentMethodTokenInput + ':checked').val();
    if (!document.querySelector('[data-block-name="woocommerce/checkout"]')) {
        $('#update-totals').hide();
    }
    sendFeeRequest('');

    function isGwMethod() {
        return $.inArray(selectedPaymentMethodVal, ['custom_payment_gateway_ach', 'custom_payment_gateway_card']) !== -1;
    }

    function showUpdateTotals(trigger) {
        let shouldShow = false;

        var oldVal = selectedPaymentMethodVal;
        selectedPaymentMethodVal = $(selectedPaymentMethodSelector).val();
        let checked_from_methods = $(savedPaymentMethodTokenInput + ':checked');

        if (!isGwMethod()) {
            trigger = '';
            sendFeeRequest('', true);
        }

        if(trigger === 'base_method_select'){ // handlePaymentMethodSelect::main payment method change, example: custom_payment_gateway_card, cash, stripe
            if ((selectedPaymentMethodVal === 'custom_payment_gateway_card' && checked_from_methods.length === 0) || (selectedPaymentMethodVal === 'custom_payment_gateway_card' && checked_from_methods.val() === 'new')){
                if(ccInputVal.replace(/\s+/g, '').length === 0){
                    sendFeeRequest('', true);
                    shouldShow = false;
                } else{
                    if (ccInputVal.replace(/\s+/g, '').length > 5) {
                        shouldShow = false;
                        handleTotals();
                    } else{
                        shouldShow = true;
                    }
                }
            } else if (oldVal !== selectedPaymentMethodVal) {
                shouldShow = false;
                handleTotals();
            }
        } else if(trigger === 'saved_method_select'){ // handleSelectedSavedMethodChange::saved method change, saved cards and ach numbers
            if(selectedPaymentMethodVal === 'custom_payment_gateway_card' && checked_from_methods.val() === 'new' && ccInputVal.replace(/\s+/g, '').length === 0){
                sendFeeRequest('', true);
                shouldShow = false;
                selectedSavedMethodVal = "new";
            } else {
                if (checked_from_methods.val() !== selectedSavedMethodVal) {
                    selectedSavedMethodVal = checked_from_methods.val();
                    handleTotals();
                    shouldShow = false;
                }
            }
        } else if(trigger === 'cc_input_change'){ // handleCcInputChange::credit card number field change
            let currentInputVal = $(ccInputIdSelector).val().replace(/\s+/g, '');
            if(currentInputVal.length < 6){
                ccInputVal = currentInputVal;
                shouldShow = false;
            } else if (currentInputVal !== ccInputVal) {
                ccInputVal = currentInputVal;
                shouldShow = true;
            } else {
                shouldShow = (currentInputVal !== ccInputVal);
            }
        }


        if (shouldShow) { // show
            $('button[name="woocommerce_checkout_place_order"]').prop("disabled", true);
            $('.custom-payment-gateway-update-totals').show();
        } else { // hide
            $('.custom-payment-gateway-update-totals').hide();
            $('button[name="woocommerce_checkout_place_order"]').prop("disabled", false);
        }
    }

    function handleTotals() {
        var ccNumber = '';
        if (selectedPaymentMethodVal === 'custom_payment_gateway_card') {
            if(selectedSavedMethodVal === 'new' && ccInputVal.replace(/\s+/g, '').length === 0){
                showUpdateTotals('');
                return;
            }
            if (ccInputVal.replace(/\s+/g, '').length > 5) {
                ccNumber = ccInputVal;
            } else {
                ccNumber = '';
            }
        } else {
            ccNumber = '';
        }
        sendFeeRequest(ccNumber);
        showUpdateTotals('');
    }

    function sendFeeRequest(ccNumber, reset = false) {
        blockCheckout();
        const selected_saved = $(savedPaymentMethodTokenInput + ':checked').val();
        $.post(custom_payment_gateway_data.ajax_url, {
            nonce: custom_payment_gateway_data.nonce,
            action: custom_payment_gateway_data.action,
            reset,
            // @see Constants::FORM_CC_NUMBER_ID
            custom_payment_gateway_card_number: ccNumber,
            // @see Constants::FORM_PAYMENT_METHOD_ID
            custom_payment_gateway_payment_method: getPaymentMethod(),
            customPaymentGatewayID: custom_payment_gateway_data.form_gateway_id,
            // @see Constants::FORM_STORED_CUSTOMER
            stored_customer: selected_saved !== undefined && selected_saved !== 'new',
            // @see Constants::FORM_PAYMENT_ID
            payment_id: selected_saved,
        }, function (response) {
            var $root = $('#custom_payment_gateway_card_form');
            var surchargeId = 'custom_payment_gateway_card_surcharge_wrapper';
            $root.find($('#' + surchargeId)).remove();
            if (response) {
                $root.prepend('<p id="' + surchargeId + '">' + response + '<br><br></p>');
            }
            $body.trigger('update_checkout');
        });
    }

    function getPaymentMethod() {
        var val = '';
        // @see Constants::ACH_METHOD_ID
        if (selectedPaymentMethodVal === 'custom_payment_gateway_ach') {
            val = "ach"
        }
        // @see Constants::CC_METHOD_ID
        if (selectedPaymentMethodVal === 'custom_payment_gateway_card') {
            val = "card";
        }
        return val;
    }

    function blockCheckout() {
        $('.woocommerce-checkout-payment, .woocommerce-checkout-review-order-table').addClass('processing').block({
            message: null,
            overlayCSS: {
                background: '#fff',
                opacity: 0.6
            }
        });
    }

    $body.on('payment_method_selected', function () {
        showUpdateTotals('base_method_select')
    });
    $body.on('updated_checkout', function () {
        $('.custom-payment-gateway-update-totals-button').off('click').click(handleTotals);
        $(ccInputIdSelector).off('keyup').keyup(function () {
            if (selectedPaymentMethodVal === 'custom_payment_gateway_card') {
                showUpdateTotals('cc_input_change')
            }
        });
        $(ccInputIdSelector).on('change', function () {
            if (selectedPaymentMethodVal === 'custom_payment_gateway_card') {
                showUpdateTotals('cc_input_change');
            }
        });
        $(ccInputIdSelector).on( "blur", function() {
            if (selectedPaymentMethodVal === 'custom_payment_gateway_card') {
                if (ccInputVal.replace(/\s+/g, '').length > 5) {
                    handleTotals();
                }
            }
            $(ccInputIdSelector).off("blur");
        });
        $("#billing_state").on('change', function () {
            if (selectedPaymentMethodVal === 'custom_payment_gateway_card') {
                handleTotals();
            }
        });
        $(".woocommerce-SavedPaymentMethods-tokenInput").on('click', function () {
            if (selectedPaymentMethodVal === 'custom_payment_gateway_card') {
                showUpdateTotals('saved_method_select')
            }
            $(".woocommerce-SavedPaymentMethods-tokenInput").off("click");
        });
    });

    let previous = '';
    setInterval(() => {
        const current = ccInputVal;
        if (current && current !== previous) {
            previous = current;
            if (selectedPaymentMethodVal === 'custom_payment_gateway_card') {
                if (ccInputVal.replace(/\s+/g, '').length > 5) {
                    handleTotals();
                }
            }
        }
    }, 500);
});