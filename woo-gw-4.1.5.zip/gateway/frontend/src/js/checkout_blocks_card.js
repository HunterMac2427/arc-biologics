const custom_gateway_card_data = window.wc.wcSettings.getSetting( 'custom_payment_gateway_card_data', {} );
const custom_gateway_card_label = window.wp.htmlEntities.decodeEntities( custom_gateway_card_data.title )
    || window.wp.i18n.__( 'Credit Card Payment', 'custom_payment_gateway_card' );
const custom_gateway_card_content = () => {
    const setting = window.wc.wcSettings.getSetting( 'custom_payment_gateway_card_data', {} );
    return window.wp.htmlEntities.decodeEntities( setting.description || 'Pay with Card.' );
};

const CardGateway = {
    name: 'custom_payment_gateway_card',
    label: custom_gateway_card_label,
    content: Object( window.wp.element.createElement )( custom_gateway_card_content, null ),
    edit: Object( window.wp.element.createElement )( custom_gateway_card_content, null ),
    canMakePayment: () => true,
    placeOrderButtonLabel: window.wp.i18n.__( 'Continue', 'custom_payment_gateway_card' ),
    ariaLabel: custom_gateway_card_label,
    supports: {
        features: custom_gateway_card_data.supports,
    },
    value: "custom_payment_gateway_card",
    paymentMethodId: 'custom_payment_gateway_card',
};
window.wc.wcBlocksRegistry.registerPaymentMethod( CardGateway );

