(function () {
    window.__cpgSessionCheckoutLoaded = true;
    var cfg = window.custom_payment_gateway_fingerprint_data || {};
    var payloadFieldName = cfg.device_fingerprint_field || "device_fingerprint_payload";
    var configured = false;
    var collectPromise = null;
    var collectTs = 0;
    var collectTtlMs = 5000;
    var placeOrderButtonSelector = "#place_order, button[name='woocommerce_checkout_place_order'], .wc-block-components-checkout-place-order-button";

    function debugLog() {
        // Debug logging intentionally disabled.
    }

    function getTracker() {
        return window.SessionTracker || null;
    }

    function configureTracker() {
        var tracker = getTracker();
        if (!tracker || configured) {
            if (!tracker) {
                debugLog("SessionTracker not available during configure");
            }
            return;
        }

        try {
            tracker.configure({
                enableSessionInit: false,
                encryptionPublicKey: cfg.encryption_public_key || null
            });
            configured = true;
            debugLog("SessionTracker configured", {
                enableSessionInit: false,
                hasPublicKey: !!cfg.encryption_public_key
            });
        } catch (_err) {
            configured = true;
            debugLog("SessionTracker configure failed", _err);
        }
    }

    async function collectFingerprintPayload() {
        configureTracker();

        var hasWebCrypto =
            !!window.crypto &&
            !!window.crypto.subtle &&
            typeof window.crypto.subtle.digest === "function";
        if (!hasWebCrypto) {
            debugLog("WebCrypto unavailable: fingerprint collection skipped", {
                isSecureContext: window.isSecureContext,
                protocol: window.location ? window.location.protocol : null,
                host: window.location ? window.location.host : null
            });
            return null;
        }

        var tracker = getTracker();
        if (!tracker || typeof tracker.getCompleteSession !== "function") {
            debugLog("getCompleteSession unavailable", { hasTracker: !!tracker });
            return null;
        }

        var now = Date.now();
        if (collectPromise && now - collectTs <= collectTtlMs) {
            debugLog("Using cached fingerprint payload");
            return collectPromise;
        }

        collectTs = now;
        debugLog("Collecting fingerprint payload");
        collectPromise = tracker.getCompleteSession().catch(async function (err) {
            debugLog("getCompleteSession failed", {
                error: err && err.message ? err.message : String(err),
                hasPublicKey: !!cfg.encryption_public_key,
                publicKeyPrefix: cfg.encryption_public_key ? String(cfg.encryption_public_key).slice(0, 40) : null
            });

            // Diagnostic only: confirms signal collection works when encryption fails.
            if (typeof tracker.getPlaintextSession === "function") {
                try {
                    var plaintext = await tracker.getPlaintextSession();
                    debugLog("getPlaintextSession diagnostic succeeded", {
                        hasPayload: !!plaintext,
                        keys: plaintext && typeof plaintext === "object" ? Object.keys(plaintext).length : 0
                    });
                } catch (plainErr) {
                    debugLog("getPlaintextSession diagnostic failed", plainErr);
                }
            }
            return null;
        });

        return collectPromise;
    }

    function isGatewayPaymentMethodSelected() {
        var selected = document.querySelector('input[name="payment_method"]:checked');
        if (!selected) {
            selected = document.querySelector('input[name="radio-control-wc-payment-method-options"]:checked');
        }
        if (!selected) {
            return false;
        }
        return selected.value === "custom_payment_gateway_card" || selected.value === "custom_payment_gateway_ach";
    }

    function upsertHiddenPayloadField(form, payload) {
        var existing = form.querySelector('input[name="' + payloadFieldName + '"]');
        if (!existing) {
            existing = document.createElement("input");
            existing.type = "hidden";
            existing.name = payloadFieldName;
            form.appendChild(existing);
            debugLog("Created hidden payload field", { formClass: form.className });
        }
        existing.value = payload ? JSON.stringify(payload) : "";
        debugLog("Updated hidden payload field", {
            hasPayload: !!payload,
            valueLength: existing.value.length
        });
    }

    function ensurePayloadFieldInCheckoutForms() {
        var forms = document.querySelectorAll("form.checkout, form.woocommerce-checkout, form[name='checkout'], form.wc-block-checkout__form");
        debugLog("Ensuring payload field in forms", { formCount: forms.length });
        for (var i = 0; i < forms.length; i++) {
            upsertHiddenPayloadField(forms[i], null);
        }
    }

    function isStoreCheckoutRequestTarget(target) {
        if (!target) {
            return false;
        }
        var normalized = String(target).toLowerCase();
        return (
            normalized.indexOf("/wc/store/checkout") !== -1 ||
            normalized.indexOf("/wc/store/v1/checkout") !== -1 ||
            normalized.indexOf("wc-store=checkout") !== -1 ||
            normalized.indexOf("rest_route=/wc/store/v1/checkout") !== -1 ||
            normalized.indexOf("rest_route=%2fwc%2fstore%2fv1%2fcheckout") !== -1
        );
    }

    document.addEventListener(
        "submit",
        async function (event) {
            var form = event.target;
            if (!form || !form.matches || !form.matches("form.checkout, form.woocommerce-checkout, form[name='checkout'], form.wc-block-checkout__form")) {
                return;
            }

            if (!isGatewayPaymentMethodSelected()) {
                debugLog("Submit ignored: non-gateway payment method");
                return;
            }

            if (form.dataset.cpgFingerprintReady === "1") {
                form.dataset.cpgFingerprintReady = "";
                return;
            }

            event.preventDefault();
            debugLog("Classic checkout submit intercepted");
            var payload = await collectFingerprintPayload();
            upsertHiddenPayloadField(form, payload);
            form.dataset.cpgFingerprintReady = "1";

            var placeOrderButton = form.querySelector(placeOrderButtonSelector);
            if (form.requestSubmit && placeOrderButton) {
                form.requestSubmit(placeOrderButton);
            } else if (form.requestSubmit) {
                form.requestSubmit();
            } else {
                form.submit();
            }
        },
        true
    );

    document.addEventListener(
        "click",
        async function (event) {
            var button = event.target && event.target.closest
                ? event.target.closest(placeOrderButtonSelector)
                : null;
            if (!button) {
                return;
            }
            if (!isGatewayPaymentMethodSelected()) {
                debugLog("Click ignored: non-gateway payment method");
                return;
            }
            var form = button.form || document.querySelector("form.checkout, form.woocommerce-checkout, form[name='checkout'], form.wc-block-checkout__form");
            if (!form) {
                return;
            }
            var payload = await collectFingerprintPayload();
            upsertHiddenPayloadField(form, payload);
            debugLog("Place-order click payload prepared");
        },
        true
    );

    ensurePayloadFieldInCheckoutForms();
    document.addEventListener("DOMContentLoaded", ensurePayloadFieldInCheckoutForms);
    if (window.jQuery) {
        window.jQuery(document.body).on("updated_checkout payment_method_selected", ensurePayloadFieldInCheckoutForms);
    }

    if (!window.__customPaymentGatewayFingerprintFetchWrapped) {
        var originalFetch = window.fetch ? window.fetch.bind(window) : null;
        if (originalFetch) {
            window.__customPaymentGatewayFingerprintFetchWrapped = true;
            window.fetch = async function (input, init) {
                var requestUrl = typeof input === "string" ? input : (input && input.url ? input.url : "");
                var method = (init && init.method) || (input && input.method) || "GET";
                var upperMethod = String(method).toUpperCase();

                var isStoreCheckoutEndpoint = isStoreCheckoutRequestTarget(requestUrl);
                if (!isStoreCheckoutEndpoint || upperMethod !== "POST") {
                    return originalFetch(input, init);
                }
                debugLog("Intercepted Store API checkout request", { url: requestUrl });

                var nextInit = init ? Object.assign({}, init) : {};
                var bodyText = nextInit.body;

                if (typeof bodyText !== "string") {
                    if (input && typeof input.clone === "function") {
                        try {
                            bodyText = await input.clone().text();
                        } catch (_err) {
                            bodyText = "";
                        }
                    }
                }

                if (typeof bodyText === "string" && bodyText.trim() !== "") {
                    try {
                        var parsed = JSON.parse(bodyText);
                        var ext = parsed && parsed.extensions && parsed.extensions["checkout-payment-extend"];
                        var paymentMethod = parsed && parsed.payment_method ? parsed.payment_method : "";
                        var inferredType = "";
                        if (paymentMethod === "custom_payment_gateway_card") {
                            inferredType = "card";
                        } else if (paymentMethod === "custom_payment_gateway_ach") {
                            inferredType = "ach";
                        }

                        var currentType = ext && ext.paymentType ? ext.paymentType : inferredType;
                        debugLog("Checkout request payment type context", {
                            paymentMethod: paymentMethod,
                            inferredType: inferredType,
                            currentType: currentType
                        });
                        if (currentType === "card" || currentType === "ach") {
                            var payload = await collectFingerprintPayload();
                            if (payload) {
                                if (!parsed.extensions) {
                                    parsed.extensions = {};
                                }
                                if (!ext) {
                                    ext = {};
                                }
                                if (!ext.paymentType && inferredType) {
                                    ext.paymentType = inferredType;
                                }
                                ext[payloadFieldName] = payload;
                                parsed.extensions["checkout-payment-extend"] = ext;
                                nextInit.body = JSON.stringify(parsed);
                                debugLog("Attached payload to blocks request", {
                                    field: payloadFieldName,
                                    payloadKeys: typeof payload === "object" && payload ? Object.keys(payload).length : 0
                                });
                            } else {
                                debugLog("No payload returned for blocks request");
                            }
                        }
                    } catch (_err) {
                        debugLog("Failed to parse/patch Store API checkout body", _err);
                    }
                }

                return originalFetch(input, nextInit);
            };
        }
    }

    if (window.wp && window.wp.apiFetch && typeof window.wp.apiFetch.use === "function" && !window.__customPaymentGatewayFpApiFetchWrapped) {
        window.__customPaymentGatewayFpApiFetchWrapped = true;
        window.wp.apiFetch.use(function (options, next) {
            try {
                var path = options && options.path ? String(options.path) : "";
                var url = options && options.url ? String(options.url) : "";
                var method = options && options.method ? String(options.method).toUpperCase() : "GET";
                var isStoreCheckout = isStoreCheckoutRequestTarget(path) || isStoreCheckoutRequestTarget(url);
                if (!isStoreCheckout || method !== "POST") {
                    return next(options);
                }

                debugLog("Intercepted wp.apiFetch checkout request", { path: path, url: url });

                var paymentMethod = options && options.data && options.data.payment_method
                    ? options.data.payment_method
                    : "";
                var inferredType = "";
                if (paymentMethod === "custom_payment_gateway_card") {
                    inferredType = "card";
                } else if (paymentMethod === "custom_payment_gateway_ach") {
                    inferredType = "ach";
                }

                return collectFingerprintPayload().then(function (payload) {
                    if (!payload) {
                        debugLog("No payload returned for wp.apiFetch request");
                        return next(options);
                    }

                    var nextOptions = Object.assign({}, options);
                    nextOptions.data = Object.assign({}, nextOptions.data || {});
                    nextOptions.data.extensions = Object.assign({}, nextOptions.data.extensions || {});

                    var ext = Object.assign({}, nextOptions.data.extensions["checkout-payment-extend"] || {});
                    if (!ext.paymentType && inferredType) {
                        ext.paymentType = inferredType;
                    }
                    ext[payloadFieldName] = payload;
                    nextOptions.data.extensions["checkout-payment-extend"] = ext;

                    debugLog("Attached payload to wp.apiFetch request", {
                        field: payloadFieldName,
                        paymentMethod: paymentMethod,
                        paymentType: ext.paymentType || null
                    });

                    return next(nextOptions);
                });
            } catch (err) {
                debugLog("wp.apiFetch middleware failed", err);
                return next(options);
            }
        });
    }
})();
