<?php

namespace CustomPaymentGateway\Actions;

use CustomPaymentGateway\Helper\Constants;
use CustomPaymentGateway\Helper\Container;
use PaymentGateway\Exceptions\GatewayException;
use PaymentGateway\Gateway;

class ApiTestAction implements ActionInterface {
	public const AJAX_HANDLE = Constants::PLUGIN_ID . '_ajax_test_api';
	private Container $c;

	public function __construct( Container $c ) {
		$this->c = $c;
	}

	public function register() {
		$handler = new self( $this->c );
		add_action( 'admin_init', array( $handler, 'registerScript' ) );
		add_action( 'wp_ajax_' . self::AJAX_HANDLE . '_handle', array( $handler, 'handleApiTest' ) );
	}

	public function registerScript() {
		$url = wc_get_current_admin_url();
		if ( strpos( $url, admin_url( 'admin.php?page=' . Constants::PLUGIN_ID ) ) === false && strpos( $url, admin_url( 'options.php' ) ) === false ) {
			return;
		}

		wp_enqueue_script(
			self::AJAX_HANDLE,
			plugins_url( '/gateway/frontend/src/js/api_test.js' ),
			array( 'jquery' ),
			Constants::PLUGIN_VERSION,
			true
		);
		wp_localize_script(
			self::AJAX_HANDLE,
			self::AJAX_HANDLE . '_data',
			array(
				'ajax_url' => admin_url( 'admin-ajax.php' ),
				'nonce'    => wp_create_nonce( self::AJAX_HANDLE . '_nonce' ),
				'action'   => self::AJAX_HANDLE . '_handle',
			)
		);
	}

	public function handleApiTest() {
		self::logPluginVersions( $this->c );
		check_ajax_referer( self::AJAX_HANDLE . '_nonce', 'nonce' );
		$data = array(
			'status'  => 'error',
			'message' => __( 'API connection could not be established. Please provide a valid API key and url.' ),
		);
		if ( ! isset( $_POST['api_key'] ) ) {
			Gateway::$api_key = $this->c->gw_options->api_key;
		} else {
			// TODO: Use $http->post() ?
			Gateway::$api_key = sanitize_text_field( $_POST['api_key'] );
		}
		if ( ! isset( $_POST['api_url'] ) ) {
			Gateway::$api_url = $this->c->gw_options->api_url;
		} else {
			Gateway::$api_url = sanitize_text_field( $_POST['api_url'] ?: '' );
		}

		if ( strpos( Gateway::$api_key, 'api_' ) !== 0 ) {
			$data['status']  = 'error';
			$data['message'] = __( 'API key should start with "api_" characters!' );
			echo json_encode( $data );
			$this->c->logger->error( 'API key should start with "api_" characters!' );
			wp_die();
		}

		try {
			$this->c->gateway->user->get();
		} catch ( \JsonMapper_Exception | GatewayException $e ) {
			echo json_encode( $data );
			$this->c->logger->error( $e->getMessage() );
			wp_die();
		}
		$data['status']  = 'success';
		$data['message'] = __( 'API connection successful.' );
		echo json_encode( $data );
		$this->c->logger->info( 'API connection successful.' );
		wp_die();
	}

	public static function logPluginVersions( $c, $full = true ) {
		$main_versions   = 'PHP-' . phpversion() . '|WP-' . get_bloginfo( 'version' ) . '|WC-' . WC()->version . '|GW-' . Constants::PLUGIN_VERSION;
		$plugin_versions = '';
		$c->logger->info( $main_versions );
		if ( $full ) {
			$apl               = get_option( 'active_plugins' );
			$plugins           = get_plugins();
			$activated_plugins = array();
			foreach ( $apl as $p ) {
				if ( isset( $plugins[ $p ] ) ) {
					$activated_plugins[] = $plugins[ $p ];
				}
			}
			$plugin_list_str = 'Activated plugins:';
			foreach ( $activated_plugins as $plugin ) {
				$plugin_list_str .= $plugin['Name'] . '-' . $plugin['Version'] . '|';
			}
			$plugin_versions = substr( $plugin_list_str, 0, -1 );
			$c->logger->info( $plugin_versions );
		}
		return 'Main versions: ' . $main_versions . "\n Activated plugins: " . $plugin_versions;
	}
}
