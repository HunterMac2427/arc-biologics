<?php

namespace CustomPaymentGateway\Actions;

use CustomPaymentGateway\Gateway\Vault;
use CustomPaymentGateway\Helper\Constants;
use CustomPaymentGateway\Helper\Container;
use CustomPaymentGateway\Log\Logger;
use CustomPaymentGateway\Settings\Settings;
use PaymentGateway\Exceptions\GatewayException;
use WC_Payment_Token;

class PaymentMethodAction implements ActionInterface {
	private Container $c;

	public function __construct( Container $c ) {
		$this->c = $c;
	}

	public function register() {
		$handler = new self( $this->c );
		add_action( 'woocommerce_payment_token_deleted', array( $handler, 'deleteToken' ), 10, 2 );
	}

	/**
	 * Delete the payment token. Called in case when someone deletes a saved payment method.
	 *
	 * @throws \Exception
	 */
	public function deleteToken( int $token_id, WC_Payment_Token $token ) {
		if ( ! in_array( $token->get_gateway_id(), array( Constants::CC_METHOD_ID, Constants::ACH_METHOD_ID ), true ) || ! empty( $GLOBALS['api_key_changed_delete'] ) ) {
			return;
		}
		$v            = new Vault( $this->c );
		$payment_type = $token->get_gateway_id() === Constants::CC_METHOD_ID ? 'card' : 'ach';
		try {
			$response = $v->delete_customer_payment_method( $this->c->meta->get_current_user_customer_id(), $payment_type, $token->get_token() );
		} catch ( \JsonMapper_Exception | GatewayException $e ) {
			$this->c->logger->error( $e->getMessage() );
			Settings::throw_exception( $e->getCode(), $e->getMessage() );
		}
		$logger = new Logger();
		$logger->set_debug( $this->c->gw_options->debug === 'yes' );
		$logger->info(
			sprintf(
			// translators: %1$s: token id, %2$s: response message
				__( 'Deleting payment method. Payment Method ID: %1$s / Message: %2$s' ),
				$token_id,
				$response->msg
			)
		);
	}
}
