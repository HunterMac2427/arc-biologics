<?php

namespace CustomPaymentGateway\Actions;

interface ActionInterface {
	public function register();
}
