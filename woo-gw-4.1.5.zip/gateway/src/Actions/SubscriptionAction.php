<?php

namespace CustomPaymentGateway\Actions;

use CustomPaymentGateway\Cron\SubscriptionCron;
use CustomPaymentGateway\Helper\Constants;
use CustomPaymentGateway\Helper\Container;
use CustomPaymentGateway\Helper\WoocommerceSubscriptions;
use DateTime;

/**
 * Class SubscriptionAction
 */
class SubscriptionAction implements ActionInterface {
	private Container $c;

	public function __construct( Container $c ) {
		$this->c = $c;
	}

	public function register() {
		if ( ! class_exists( '\WC_Subscriptions' ) ) {
			return;
		}

		// TODO remove this section
		$subscription_action = new self( $this->c );
		add_action( 'woocommerce_thankyou', array( $subscription_action, 'addSubscriptionNotice' ), 1 );

		// TODO move SubscriptionCron here as well
		$subscription_cron = new SubscriptionCron( $this->c );
		add_action( Constants::SUBSCRIPTION_CRON_HOOK, array( $subscription_cron, 'cron_job' ) );
		if ( ! wp_next_scheduled( Constants::SUBSCRIPTION_CRON_HOOK ) ) {
			$cron_time = new DateTime( 'now', wp_timezone() );
			$cron_time->setTime( 27, 0 );
			wp_schedule_event( $cron_time->getTimestamp(), 'daily', Constants::SUBSCRIPTION_CRON_HOOK );
		}

		// TODO remove this section
		add_filter(
			'woocommerce_my_account_my_orders_actions',
			array(
				$subscription_action,
				'filterMyAccountOrdersActions',
			),
			10,
			2
		);
	}

	public function addSubscriptionNotice( $order_id ) {
		if ( ! WoocommerceSubscriptions::plugin_available() ) {
			return;
		}
		$subs = wcs_get_subscriptions_for_order( $order_id );
		if ( count( $subs ) > 0 ) {
			echo '<em>' . __( 'Subscription might take up to 24 hours to activate.' ) . '</em>';
		}
	}

	/**
	 * Remove pay action if payment is pending for subscriptions.
	 */
	public function filterMyAccountOrdersActions( $actions, $order ) {
		// @@TODO write tests for that scenario
		$gw = wc_get_payment_gateway_by_order( $order );
		if ( ! in_array( $gw->id, array( Constants::CC_METHOD_ID, Constants::ACH_METHOD_ID ), true ) ) {
			return $actions;
		}
		if ( isset( $actions['pay'] ) && WoocommerceSubscriptions::plugin_available() && wcs_order_contains_subscription( $order, array( 'any' ) ) ) {
			$subscriptions = wcs_get_subscriptions_for_order( wcs_get_objects_property( $order, 'id' ), array( 'order_type' => 'any' ) );

			foreach ( $subscriptions as $subscription ) {
				if ( $this->c->meta->get_subscription_id( $subscription ) && $subscription->get_status() === 'pending' ) {
					unset( $actions['pay'] );
					break;
				}
			}
		}

		return $actions;
	}
}
