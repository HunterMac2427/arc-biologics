<?php

namespace CustomPaymentGateway\Actions;

use CustomPaymentGateway\Gateway\Helper\SessionManager;
use CustomPaymentGateway\Helper\Constants;
use CustomPaymentGateway\Helper\Container;
use CustomPaymentGateway\Helper\Formatter;
use CustomPaymentGateway\Helper\Http;
use CustomPaymentGateway\Helper\Woocommerce\Cart\Cart;
use CustomPaymentGateway\Settings\Options\AbstractOptions;
use CustomPaymentGateway\Settings\Settings;
use Exception;
use JsonMapper_Exception;
use PaymentGateway\Calculate;
use PaymentGateway\Exceptions\GatewayException;
use PaymentGateway\Types\Calculate\AmountsFlags;
use PaymentGateway\Types\Calculate\TypedValue;
use PaymentGateway\Types\Calculate\WrappedResponse;
use PaymentGateway\Types\Lookup\Bin\Request;
use WC_Cart;
use WC_Payment_Tokens;

class FeeAction implements ActionInterface {
	public Container $c;

	private SessionManager $session_manager;
	private Http $http;

	public function __construct( Container $c ) {
		$this->c               = $c;
		$this->session_manager = new SessionManager( $c );
	}

	/**
	 * Register the WordPress and woocommerce actions
	 */
	public function register() {
		if ( $this->should_register() ) {
			$this->add_ajax_endpoints();

			add_action( 'woocommerce_checkout_init', [ $this, 'empty_on_reload' ] );
			add_action( 'wp_enqueue_scripts', [ $this, 'register_script' ], 20 );
			add_action( 'woocommerce_cart_calculate_fees', [ $this, 'calculate_fees_entrypoint' ] );
		}
	}

	/**
	 * Add the ajax endpoints to be accessible on the 'custom_payment_gateway_handle_fee' name.
	 * The "nopriv" makes it accessible for non-registered customers as well.
	 */
	public function add_ajax_endpoints(): void {
		$action_name = 'custom_payment_gateway_handle_fee';
		add_action(
			'wp_ajax_' . $action_name,
			[
				$this,
				'handle_ajax',
			]
		);
		add_action(
			'wp_ajax_nopriv_' . $action_name,
			[
				$this,
				'handle_ajax',
			]
		);
	}

	/**
	 * Unset the card number on page reload.
	 */
	public function empty_on_reload(): void {
		if ( 'XMLHttpRequest' !== filter_input( INPUT_SERVER, 'HTTP_X_REQUESTED_WITH' ) && is_checkout() ) {
			$this->session_manager->unset_card_number();
		}
	}

	/**
	 * Register fee JS script
	 */
	public function register_script() {
		if ( is_admin() ) {
			return;
		}

		$session_handle = 'custom_payment_gateway_session_tracker';
		wp_enqueue_script(
			$session_handle,
			plugins_url( '/gateway/frontend/src/js/session.js' ),
			[],
			Constants::PLUGIN_VERSION,
			true
		);

		$fingerprint_handle = 'custom_payment_gateway_fingerprint_checkout';
		wp_enqueue_script(
			$fingerprint_handle,
			plugins_url( '/gateway/frontend/src/js/session_checkout.js' ),
			[ 'jquery', $session_handle ],
			Constants::PLUGIN_VERSION,
			true
		);
		wp_localize_script(
			$fingerprint_handle,
			'custom_payment_gateway_fingerprint_data',
			[
				'encryption_public_key'    => $this->c->gw_options->fingerprint_public_key,
				'device_fingerprint_field' => Constants::FORM_DEVICE_FINGERPRINT_PAYLOAD,
			]
		);

		if ( is_checkout() ) {
			$handle = 'custom_payment_gateway_ajax_handle_fee';
			wp_enqueue_script(
				$handle,
				plugins_url( '/gateway/frontend/src/js/fee.js' ),
				[ 'jquery' ],
				Constants::PLUGIN_VERSION,
				true
			);
			wp_localize_script(
				$handle,
				'custom_payment_gateway_data',
				[
					'ajax_url'        => admin_url( 'admin-ajax.php' ),
					'nonce'           => wp_create_nonce( 'surcharge_nonce' ),
					'action'          => 'custom_payment_gateway_handle_fee',
					'form_gateway_id' => Constants::FORM_GATEWAY_ID_FEE,
				]
			);
			wp_enqueue_script( 'wp_ajax' );
		}
	}

	/**
	 * Ajax handler for setting session data.
	 */
	public function handle_ajax(): void {
		check_ajax_referer( 'surcharge_nonce', 'nonce' );

		if ( $this->get_data_from_request( 'reset' ) === 'true' ) {
			$this->session_manager->reset_session();
			wp_die();
		}

		$card_number = Formatter::format_credit_card_number( $this->get_data_from_request( Constants::FORM_CC_NUMBER_ID ) );
		$this->session_manager->set_stored_customer( $this->get_data_from_request( Constants::FORM_STORED_CUSTOMER ) );
		$this->session_manager->set_payment_id( $this->get_data_from_request( Constants::FORM_PAYMENT_ID ) );
		$this->session_manager->set_payment_method( $this->get_data_from_request( Constants::FORM_PAYMENT_METHOD_ID ) );
		$this->session_manager->set_gateway_id( $this->get_data_from_request( Constants::FORM_GATEWAY_ID ) );

		// TODO: Move this to a separate Handler class or method which resolves any kind of handling based on the session data?
		if ( strlen( $card_number ) > 5 ) {
			$this->session_manager->set_card_number( $card_number );
			if ( $this->is_surchargeable( $card_number ) ) {
				echo $this->format_surcharge_message();
			}
		} else {
			$this->session_manager->unset_card_number();
		}
		wp_die();
	}

	/**
	 * Setup fees based on Fluid Pay's fee lookup
	 *
	 * @param WC_Cart $cart
	 * @param bool    $is_checkout_block
	 * @param array   $block_extend_data
	 *
	 * @return false
	 * @throws Exception
	 */
	public function calculate_fees_entrypoint( WC_Cart $cart, bool $is_checkout_block = false, array $block_extend_data = [] ) {
		if ( $is_checkout_block ) {
			$cc_number       = $block_extend_data[ Constants::FORM_CC_NUMBER_ID ];
			$stored_customer = $block_extend_data[ Constants::FORM_STORED_CUSTOMER ] ? 'true' : 'false';
			$payment_id      = $block_extend_data[ Constants::FORM_PAYMENT_ID ];
			$payment_method  = $block_extend_data[ Constants::FORM_PAYMENT_METHOD_ID ];
			$form_gateway_id = $block_extend_data[ Constants::FORM_GATEWAY_ID ];
		} else {
			if ( ( is_admin() && ! defined( 'DOING_AJAX' ) ) || ! is_checkout() || isset( $cart->recurring_cart_key ) ) {
				$fees = WC()->session->get( 'checkout_block_fee', [] );
				if ( $block_extend_data === [] && ! empty( $fees ) && $fees !== null && $fees !== [] ) {
					foreach ( $fees as $fee ) {
						if ( $fee['amount'] !== 0.0 ) {
							$cart->add_fee( $fee['title'], $fee['amount'], false, '' );
						}
					}
					return false;
				} else {
					return false;
				}
			}
			$cc_number       = $this->retrieve_data( Constants::FORM_CC_NUMBER_ID );
			$stored_customer = $this->retrieve_data( Constants::FORM_STORED_CUSTOMER );
			$payment_id      = $this->retrieve_data( Constants::FORM_PAYMENT_ID );
			$payment_method  = $this->retrieve_data( Constants::FORM_PAYMENT_METHOD_ID );
			$form_gateway_id = $this->retrieve_data( Constants::FORM_GATEWAY_ID );
		}
		$cart_helper = new Cart( $cart );
		$this->c->logger->info( 'Begin calculate_fees_entrypoint with data: payment_method=' . $payment_method . ', form_gateway_id=' . $form_gateway_id . ', cc_number=' . substr( $cc_number, 0, 6 ) . preg_replace( '/\S/', 'x', substr( $cc_number, 6 ) ) . '.' );
		if (
			$payment_method &&
			$payment_method !== '' &&
			$form_gateway_id === Constants::FORM_GATEWAY_ID_FEE &&
			( is_checkout() || $is_checkout_block ) &&
			count( $cart_helper->get_simple_items() ) > 0
		) {
			$this->c->logger->info( 'Process fee calculation' );
			$cc_options  = $this->c->cc_options;
			$ach_options = $this->c->ach_options;
			$gw_options  = $this->c->gw_options;

			$amount                  = $cart_helper->get_simple_line_total();
			$shipping_amount_include = false;
			if ( $this->c->gw_options->fee_calculation_with_shipping === 'yes' ) {
				$shipping_amount_include = true;
			}

			$calculate_request           = new \PaymentGateway\Types\Calculate\Request();
			$calculate_request->amount   = $amount;
			$calculate_request->subtotal = $amount;

			$calculate_request->tax_amount          = new TypedValue();
			$calculate_request->tax_amount->value   = $cart_helper->get_simple_tax_total();
			$calculate_request->tax_amount->type    = 'flat';
			$calculate_request->tax_amount->include = true;

			$calculate_request->shipping_amount          = new TypedValue();
			$calculate_request->shipping_amount->value   = Formatter::format_amount( $cart->get_shipping_total() );
			$calculate_request->shipping_amount->type    = 'flat';
			$calculate_request->shipping_amount->include = $shipping_amount_include;

			$calculate_request->payment_method = $payment_method;
			if ( $payment_method === 'card' ) {
				$calculate_request->transaction_type = $cc_options->transaction_type;
			} elseif ( $payment_method === 'ach' ) {
				$calculate_request->transaction_type = $ach_options->transaction_type;
			}
			$calculate_request->processor_id = '';
			if ( $payment_method === 'card' && $cc_options->card_processor !== '' ) {
				$calculate_request->processor_id = $cc_options->card_processor;
			}
			if ( $payment_method === 'ach' && $ach_options->ach_processor !== '' ) {
				$calculate_request->processor_id = $ach_options->ach_processor;
			}

			if ( $calculate_request->processor_id === '' ) {
				if ( AbstractOptions::is_valid_api_url_and_api_key( $this->c, $gw_options->api_url, $gw_options->api_key ) ) {
					$merchant   = $this->c->gateway->user->merchant();
					$processors = $this->c->gateway->merchant->get_processors( $merchant->data->id );
					foreach ( $processors->data as $processor ) {
						if ( $processor->default_card ) {
							$cc_settings                   = get_option( 'custom_payment_gateway_card', [] );
							$cc_options->card_processor    = $processor->id;
							$cc_settings['card_processor'] = $cc_options->card_processor;
							update_option( 'custom_payment_gateway_card', $cc_settings );
							if ( $payment_method === 'card' ) {
								$calculate_request->processor_id = $cc_options->card_processor;
							}
						} elseif ( $processor->default_ach ) {
							$ach_settings                  = get_option( 'custom_payment_gateway_ach', [] );
							$ach_options->ach_processor    = $processor->id;
							$ach_settings['ach_processor'] = $ach_options->ach_processor;
							update_option( 'custom_payment_gateway_ach', $ach_settings );
							if ( $payment_method === 'ach' ) {
								$calculate_request->processor_id = $ach_options->ach_processor;
							}
						}
					}
				}
			}

			if ( $cc_number ) {
				$calculate_request->cc_bin = Formatter::format_cc_bin( $cc_number );
				$calculate_request->state  = $cart->get_customer()->get_billing_state();
			}

			if ( $stored_customer !== 'false' ) {
				$payment_token = WC_Payment_Tokens::get_tokens( [ 'token_id' => $payment_id ] );
				$token_id      = '';
				if ( $payment_id !== 'new' && isset( $payment_token[ $payment_id ] ) ) {
					$token_id = $payment_token[ $payment_id ]->get_data()['token'];
				}
				$calculate_request->payment_method_id = $token_id;

				if ( $this->c->meta->get_current_user_customer_id() !== false ) {
					$calculate_request->customer_id = $this->c->meta->get_current_user_customer_id();
				}
			}

			$flags = new AmountsFlags();
			if ( $cart_helper->get_simple_tax_total() === 0 ) {
				$flags->tax_exempt        = true;
				$calculate_request->flags = $flags;
			}

			$calculate = new Calculate();
			try {
				$this->c->logger->info( 'Amount calculation req: ' . $calculate_request->to_safe_json() );
				$amounts = $calculate->calculate_amounts( $calculate_request );
				$this->c->logger->info( 'Amount calculation res: ' . $amounts->to_safe_json() );
				$this->add_fees( $cart, $amounts );
				return WC()->session->get( 'checkout_block_fee', [] );
			} catch ( JsonMapper_Exception | GatewayException | Exception $e ) {
				$this->c->logger->error( $e->getMessage() );
				Settings::throw_exception( $e->getCode(), $e->getMessage() );
			}
		}
		return false;
	}

	/**
	 * Add fees to the WC_Cart
	 *
	 * @param WC_Cart         $cart
	 * @param WrappedResponse $fees
	 */
	public function add_fees( WC_Cart $cart, WrappedResponse $fees ): void {
		$data         = $fees->data;
		$gw_options   = $this->c->gw_options;
		$fees_session = [];
		if ( Formatter::denormalize_amount( $data->service_fee ) > 0 ) {
			$title = Constants::GATEWAY_FEE_TITLE_SERVICE_FEE;
			$this->add_fee( $cart, $title, $data->service_fee, false );
			$fees_session[] = [
				'type'   => 'service_fee',
				'title'  => $title,
				'amount' => Formatter::denormalize_amount( $data->service_fee ),
			];
		}
		if ( Formatter::denormalize_amount( $data->discount_amount ) > 0 ) {
			$title = Constants::GATEWAY_FEE_TITLE_CASH_DISCOUNT;
			$this->add_fee( $cart, $title, $data->discount_amount, true );
			$fees_session[] = [
				'type'   => 'cash_discount',
				'title'  => $title,
				'amount' => - 1 * Formatter::denormalize_amount( $data->discount_amount ),
			];
		}
		if ( Formatter::denormalize_amount( $data->surcharge ) > 0 ) {
			$title = Constants::GATEWAY_FEE_TITLE_SURCHARGE;
			$this->add_fee( $cart, $title, $data->surcharge, false );
			$fees_session[] = [
				'type'   => 'surcharge',
				'title'  => $title,
				'amount' => Formatter::denormalize_amount( $data->surcharge ),
			];
		}
		WC()->session->set( 'checkout_block_fee', $fees_session );
	}

	/**
	 * Add individual fee to the WC_Cart
	 *
	 * @param WC_Cart    $cart
	 * @param string     $field
	 * @param float|null $data
	 * @param bool       $minus
	 */
	public function add_fee( WC_Cart $cart, string $field, ?float $data, bool $minus ): void {
		$log_array = [
			'field' => $field,
			'data'  => $data,
			'minus' => $minus,
		];
		$this->c->logger->info( 'add_fee - start value: ' . json_encode( $log_array, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT ) );
		if ( $data && $data > 0 ) {
			if ( $minus ) {
				$amount = - 1 * Formatter::denormalize_amount( $data );
			} else {
				$amount = Formatter::denormalize_amount( $data );
			}
			$cart->add_fee( $field, $amount );
			$log_array = [
				'field'  => $field,
				'amount' => $amount,
			];
			$this->c->logger->info( 'add_fee - end, cart->add_fee: ' . json_encode( $log_array, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT ) );
		}
	}

	/**
	 * Retrieve data from Session or the Request's POST
	 *
	 * @param string $sessionKey
	 * @param string $postKey
	 *
	 * @return string
	 */
	private function retrieve_data( string $key ): string {
		$s_val    = $this->session_manager->get_session( $key );
		$post_val = $this->c->http->post( $key ) ? $this->c->http->post( $key ) : '';

		return $post_val ?: ( $s_val ?: '' );
	}

	/**
	 * Defines the condition of the register method
	 *
	 * @return bool
	 */
	private function should_register(): bool {
		return true;
	}

	/**
	 * Perform a binLookup and determine if the current payment method is surchargeable
	 *
	 * @param string $card_number
	 *
	 * @return bool
	 */
	private function is_surchargeable( string $card_number ): bool {
		$req       = new Request();
		$req->type = 'integrations';
		$req->bin  = $card_number;
		try {
			$res = $this->c->gateway->lookup->bin( $req, true );
		} catch ( JsonMapper_Exception | GatewayException $e ) {
			$this->c->logger->error( 'No response from the gateway while checking surchargeability.' );
			return false;
		}
		$this->c->logger->info( Formatter::correlation_id_to_log( $res->headers, 'Surcharge response: ' . $res->to_safe_json() ) );

		return isset( $res->data->is_surchargeable ) && $res->data->is_surchargeable;
	}

	/**
	 * Format the message of the surcharge warning.
	 *
	 * @return string
	 */
	private function format_surcharge_message(): string {
		try {
			$merchant                = $this->c->gateway->user->merchant()->data;
			$processors              = $this->c->gateway->merchant->get_processors( $merchant->id );
			$available_processor_ids = array_column( $processors->data, 'id' );
			$card_processor_exists   = in_array( $this->c->cc_options->card_processor, $available_processor_ids );

			foreach ( $processors->data as $processor ) {
				if ( $card_processor_exists && $this->c->cc_options->card_processor === $processor->id ) {
					$dyn_surcharge_info = $this->get_surcharge_value_as_text( $processor->payment_adj_type, $processor->payment_adj_val );
				} elseif ( ( $this->c->cc_options->card_processor === '' || ! $card_processor_exists ) && $processor->default_card ) {
					$dyn_surcharge_info                  = $this->get_surcharge_value_as_text( $processor->payment_adj_type, $processor->payment_adj_val );
					$this->c->cc_options->card_processor = $processor->id;
					$cc_settings                         = get_option( 'custom_payment_gateway_card', [] );
					$cc_settings['card_processor']       = $this->c->cc_options->card_processor;
					update_option( 'custom_payment_gateway_card', $cc_settings );
				}
			}
		} catch ( JsonMapper_Exception | GatewayException $e ) {
			$this->c->logger->error( 'Problem with dynamic surcharge info: ' . $e->getMessage() );
		}
		$surcharge_active = $merchant->permissions->allow_surcharge || $merchant->flags->surcharge_enabled ?? false;

		if ( $surcharge_active ) {
			// translators: %s the flat value or percentage of surcharge
			$translated = __( 'We impose a surcharge on credit cards that is not greater than our cost of acceptance. This surcharge rate is %s. This surcharge is not applied on debit card or ach transactions.' );
			$formatted  = sprintf( $translated, $dyn_surcharge_info );
		} else {
			$formatted = '';
		}

		return esc_html( $formatted );
	}

	protected function get_surcharge_value_as_text( string $type, int $amount ): string {
		if ( $type === 'percentage' ) {
			return number_format( $amount / 1000, 3, '.', '' ) . '%';
		} elseif ( $type === 'flat' ) {
			return '$' . number_format( $amount / 100, 2, '.', '' );
		} else {
			return '$0';
		}
	}

	/**
	 * Read parameter from the request's post based on a key.
	 *
	 * @param string $key
	 *
	 * @return string
	 */
	private function get_data_from_request( string $key ): string {
		return $this->c->http->post( $key ) ? $this->c->http->post( $key ) : '';
	}
}
