<?php

namespace CustomPaymentGateway\Actions;

use CustomPaymentGateway\Helper\Constants;
use CustomPaymentGateway\Helper\Container;

class RedirectAction implements ActionInterface {
	private Container $c;

	public function __construct( Container $c ) {
		$this->c = $c;
	}

	public function register() {
		$redirect_impl = new self( $this->c );
		add_action( 'admin_init', array( $redirect_impl, 'redirect' ) );
	}

	/**
	 * Redirects from the default gateway settings page to the custom settings page created by this plugin.
	 */
	public function redirect() {
		$url = wc_get_current_admin_url();
		if ( $url === admin_url( 'admin.php?page=wc-settings&tab=checkout&section=' . Constants::CC_METHOD_ID ) ) {
			wp_redirect( admin_url( 'admin.php?page=' . Constants::PLUGIN_ID ), 301 );
			exit();
		}
		if ( $url === admin_url( 'admin.php?page=wc-settings&tab=checkout&section=' . Constants::ACH_METHOD_ID ) ) {
			wp_redirect( admin_url( 'admin.php?page=' . Constants::PLUGIN_ID ), 301 );
			exit();
		}
	}
}
