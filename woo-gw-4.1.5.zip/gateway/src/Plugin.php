<?php

namespace CustomPaymentGateway;

use CustomPaymentGateway\Actions\ApiTestAction;
use CustomPaymentGateway\Actions\FeeAction;
use CustomPaymentGateway\Actions\PaymentMethodAction;
use CustomPaymentGateway\Actions\RedirectAction;
use CustomPaymentGateway\Actions\SubscriptionAction;
use CustomPaymentGateway\CheckoutBlocks\CheckoutBlockUpdateTotals;
use CustomPaymentGateway\Gateway\PaymentMethod\Card;
use CustomPaymentGateway\Gateway\PaymentMethod\ACH;
use CustomPaymentGateway\Helper\Constants;
use CustomPaymentGateway\Helper\Container;
use CustomPaymentGateway\Log\Logger;
use CustomPaymentGateway\Settings\Settings;

class Plugin {
	private Container $c;

	public function __construct( Container $c ) {
		$this->c = $c;
	}

	public function init() {
		$redirect_action = new RedirectAction( $this->c );
		$redirect_action->register();

		$hook_loader = new self( $this->c );
		add_action( 'plugins_loaded', array( $hook_loader, 'hooks' ) );
	}

	public function hooks() {
		$this->c->logger = new Logger();
		$this->c->logger->set_debug( $this->c->gw_options->debug === 'yes' );
		load_plugin_textdomain(
			Constants::PLUGIN_ID,
			false,
			plugins_url( '/gateway/l10n/' )
		);

		// Set it after the "plugins_loaded" event because we have to add it after the plugins loaded
		$gateway_filter = new self( $this->c );
		add_filter( 'woocommerce_payment_gateways', array( $gateway_filter, 'add_gateway' ) );

		$settings = new Settings(
			$this->c,
			array(
				$this->c->gw_options,
				$this->c->cc_options,
				$this->c->ach_options,
				$this->c->troubleshooting_options,
			)
		);
		add_action( 'admin_init', array( $settings, 'init' ) );
		add_action( 'admin_menu', array( $settings, 'register_menu' ), 100 );

		$subscription_action = new SubscriptionAction( $this->c );
		$subscription_action->register();

		$fee_action = new FeeAction( $this->c );
		$fee_action->register();

		$payment_method_action = new PaymentMethodAction( $this->c );
		$payment_method_action->register();

		$api_test_action = new ApiTestAction( $this->c );
		$api_test_action->register();

		new CheckoutBlockUpdateTotals( $fee_action );

		add_action(
			'admin_enqueue_scripts',
			function ( $hook ) {
				if ( 'woocommerce_page_' . Constants::PLUGIN_ID !== $hook ) {
					return;
				}

				if ( ! isset( $_GET['page'] ) || $_GET['page'] !== Constants::PLUGIN_ID ) {
					return;
				}

				wp_enqueue_style(
					Constants::PLUGIN_ID . '-bootstrap',
					'https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css',
					[],
					'5.3.0'
				);

				wp_enqueue_script(
					Constants::PLUGIN_ID . '-bootstrap',
					'https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js',
					[],
					'5.3.0',
					true
				);

				wp_enqueue_style(
					Constants::PLUGIN_ID . 'settings-page',
					plugins_url( '/gateway/frontend/src/css/page.css' ),
					[],
					'1.1.0'
				);

				wp_enqueue_script(
					Constants::PLUGIN_ID . 'settings-page',
					plugins_url( '/gateway/frontend/src/js/page.js' ),
					[],
					'1.0.1',
					true
				);
			}
		);
	}

	/**
	 * Add gateway implementations
	 *
	 * @param array $methods List of available methods
	 *
	 * @return array
	 */
	public function add_gateway( $methods ) {
		$methods[] = new Card( $this->c );
		$methods[] = new ACH( $this->c );

		return $methods;
	}
}
