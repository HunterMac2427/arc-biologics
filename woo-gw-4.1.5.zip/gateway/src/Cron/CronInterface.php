<?php

namespace CustomPaymentGateway\Cron;

interface CronInterface {
	public function cron_job();
}
