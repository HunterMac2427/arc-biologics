<?php

namespace CustomPaymentGateway\Cron;

use CustomPaymentGateway\Helper\Constants;
use CustomPaymentGateway\Helper\Container;
use CustomPaymentGateway\Helper\Formatter;
use PaymentGateway\Exceptions\GatewayException;
use PaymentGateway\Types\Transaction\Search\QuerySearchParamString;

class SubscriptionCron implements CronInterface {
	/**
	 * Lock TTL in seconds. Long enough to cover a full sync on a large store, but
	 * self-expiring so a fatal mid-run can never wedge the cron permanently.
	 */
	private const LOCK_TIMEOUT = 15 * 60;

	private Container $c;

	public function __construct( Container $c ) {
		$this->c = $c;
	}

	// @@TODO make comments great again
	public function cron_job() {
		// Re-entrancy guard: the daily cron and the manual "Sync Subscriptions" button run
		// the exact same code, so without this a manual sync overlapping the scheduled run
		// (or a double-clicked submit) could pass is_time_to_pay() twice before either call
		// to wcs_create_renewal_order() lands, creating duplicate renewal orders for the
		// same billing cycle.
		if ( ! $this->acquire_lock() ) {
			$this->c->logger->info( 'SubscriptionCron already running; skipping this run to avoid duplicate renewals.' );

			return;
		}

		try {
			$this->c->logger->info( 'SubscriptionCron job running' );
			$subscriptions = wcs_get_subscriptions( array( 'subscriptions_per_page' => - 1 ) );
			$subscriptions = array_filter( $subscriptions, [ $this, 'filter_subscriptions' ] );
			$this->update_subscriptions( $subscriptions );
		} finally {
			$this->release_lock();
		}
	}

	/**
	 * Best-effort lock acquisition. Returns false if a run is already in progress.
	 */
	private function acquire_lock(): bool {
		if ( get_transient( Constants::SUBSCRIPTION_CRON_LOCK ) ) {
			return false;
		}
		set_transient( Constants::SUBSCRIPTION_CRON_LOCK, time(), self::LOCK_TIMEOUT );

		return true;
	}

	private function release_lock(): void {
		delete_transient( Constants::SUBSCRIPTION_CRON_LOCK );
	}

	/**
	 * @param \WC_Subscription $subscription
	 *
	 * @return bool
	 */
	private function filter_subscriptions( \WC_Subscription $subscription ): bool {
		if ( ! $this->is_gw_subscription( $subscription ) || ! $this->c->meta->get_subscription_id( $subscription ) ) {
			return false;
		}

		return true;
	}

	/**
	 * @param \WC_Subscription[] $subscriptions
	 */
	private function update_subscriptions( array $subscriptions ) {
		foreach ( $subscriptions as $subscription ) {
			$subscription_response = $this->get_subscription_from_gw( $subscription );
			if ( ! $subscription_response ) {
				continue;
			}
			if ( $this->should_skip_subscription( $subscription, $subscription_response->status ) ) {
				continue;
			}
			$last_transaction = $this->get_last_transaction( $this->c->meta->get_subscription_id( $subscription ) );
			if ( ! $last_transaction ) {
				continue;
			}
			// WC Transaction status can be 'pending', 'processing', 'on-hold', 'completed', 'cancelled', 'refunded', 'failed'
			$wc_last_order  = wc_get_order( $subscription->get_last_order() );
			$next_bill_date = $subscription_response->next_bill_date;
			if ( $this->is_critical_subscription( $wc_last_order, $last_transaction ) ) {
				$this->resolve_critical_subscription( $wc_last_order, $subscription, $last_transaction, $next_bill_date );
			}
			if ( $this->is_time_to_pay( $subscription, $wc_last_order, $last_transaction->id ) ) {
				$this->handle_renewal( $subscription, $last_transaction, $next_bill_date );
			}
		}
	}

	/**
	 * @param \WC_Subscription $subscription
	 *
	 * @return bool
	 */
	private function is_gw_subscription( \WC_Subscription $subscription ): bool {
		return in_array(
			$subscription->get_payment_method(),
			array(
				Constants::CC_METHOD_ID,
				Constants::ACH_METHOD_ID,
			),
			true
		);
	}

	/**
	 * @param \WC_Subscription $subscription
	 *
	 * @return array|null
	 */
	private function get_subscription_from_gw( \WC_Subscription $subscription ): ?\PaymentGateway\Types\Recurring\Subscription\Response {
		$subscription_id       = $this->c->meta->get_subscription_id( $subscription );
		$subscription_response = null;

		try {
			$subscription_response = $this->c->gateway->recurring->get_subscription( $subscription_id, true );
			$this->c->logger->info( Formatter::correlation_id_to_log( $subscription_response->headers, 'GW subscription get;' ) );
		} catch ( GatewayException | \JsonMapper_Exception $e ) {
			$this->c->logger->error( $e->getMessage() );
		}

		$data = $subscription_response->data;

		if ( ! $data ) {
			$this->c->logger->error( __( "Couldn't connect to gateway. The API key or the URL might be wrong." ) );

			return null;
		}
		if ( ! isset( $data->status ) ) {
			$subscription->add_order_note( __( 'Subscription not found in Gateway.' ) );
			try {
				$this->c->gateway->recurring->update_subscription_status( $subscription_id, 'cancelled', true );
				$this->c->logger->info( Formatter::correlation_id_to_log( $subscription_response->headers, 'GW subscription update cancel;' ) );
			} catch ( GatewayException | \JsonMapper_Exception $e ) {
				$this->c->logger->error( $e->getMessage() );
			}

			return null;
		}

		return $data;
	}

	/**
	 * @param \WC_Subscription $subscription
	 * @param string $gw_subscription_status
	 *
	 * @return bool
	 */
	private function should_skip_subscription( \WC_Subscription $subscription, string $gw_subscription_status ): bool {
		// WC Sub Status can be: 'active', 'on-hold', 'pending-cancel', 'cancelled', 'expired', 'switched', 'pending', 'processing', 'completed', 'refunded', 'failed'
		// GW Sub Status can be: 'active','failing','failed','completed','paused','past_due','cancelled','stopped'
		$skip_status_map = array(
			'cancelled'      => 'cancelled',
			'pending-cancel' => 'cancelled',
			'expired'        => 'completed',
		);
		// Skip updating the subscription if it is cancelled, pending-cancel or expired
		if ( isset( $skip_status_map[ $subscription->get_status() ] ) && ( $skip_status_map[ $subscription->get_status() ] === $gw_subscription_status ) ) {
			return true;
		}
		// Cancel the subscription if the GW status is failed or cancelled
		if ( in_array( $gw_subscription_status, [ 'failed', 'cancelled' ], true ) ) {
			\WC_Subscriptions_Manager::cancel_subscriptions_for_order( $subscription );

			return true;
		}

		return false;
	}

	/**
	 * @param string $subscription_id
	 *
	 * @return \PaymentGateway\Types\Transaction\Response
	 */
	private function get_last_transaction( string $subscription_id ): ?\PaymentGateway\Types\Transaction\Response {
		$request = new \PaymentGateway\Types\Transaction\Search\Request();

		$search_param           = new QuerySearchParamString();
		$search_param->operator = '=';
		$search_param->value    = $subscription_id;

		$request->subscription_id = $search_param;

		$transactions_response = null;
		try {
			$transactions_response = $this->c->gateway->transaction->search( $request, true );
			$this->c->logger->info( Formatter::correlation_id_to_log( $transactions_response->headers, 'Last transaction get;' ) );
		} catch ( GatewayException | \JsonMapper_Exception $e ) {
			// A null/invalid `data` payload from the gateway surfaces here as a
			// JsonMapper_Exception ("...WrappedResponse must not be NULL"). This runs
			// inside the daily subscription cron, so re-throwing aborts the whole cron
			// run for every remaining subscription (the historical fatal). Log and skip
			// this subscription instead, matching get_subscription_from_gw().
			$this->c->logger->error( $e->getMessage() );

			return null;
		}

		$data = $transactions_response->data;

		// If there are no transactions there's nothing to do
		if ( ! $data || count( $data ) === 0 ) {
			return null;
		}

		// The gateway's transaction search does not guarantee any particular ordering, so we
		// cannot assume $data[0] is the most recent. Every downstream decision (critical-order
		// resolution, renewal, and the duplicate-renewal dedup gate that compares the last
		// transaction id against the order's stored transaction id) depends on this being the
		// *latest* transaction, so select it explicitly by created_at.
		return $this->latest_transaction( $data );
	}

	/**
	 * Pick the most recent transaction from an (unordered) search result by created_at.
	 *
	 * @param \PaymentGateway\Types\Transaction\Response[] $transactions
	 *
	 * @return \PaymentGateway\Types\Transaction\Response
	 */
	private function latest_transaction( array $transactions ): \PaymentGateway\Types\Transaction\Response {
		usort(
			$transactions,
			static function ( $a, $b ) {
				$a_time = isset( $a->created_at ) ? (int) strtotime( $a->created_at ) : 0;
				$b_time = isset( $b->created_at ) ? (int) strtotime( $b->created_at ) : 0;

				// Newest first.
				return $b_time <=> $a_time;
			}
		);

		return $transactions[0];
	}

	/**
	 * @param string $last_transaction_status
	 *
	 * @return bool
	 */
	private function is_last_transaction_successful( string $last_transaction_status ): bool {
		// GW Transaction status can be 'unknown','declined','authorized','pending_settlement','settled','voided','refunded','returned','late_return','pending','partially_refunded'
		return in_array(
			$last_transaction_status,
			array(
				'pending_settlement',
				'settled',
			),
			true
		);
	}

	/**
	 * @param \WC_Order $wc_last_order
	 * @param \PaymentGateway\Types\Transaction\Response $last_transaction
	 *
	 * @return bool
	 */
	private function is_critical_subscription( \WC_Order $wc_last_order, \PaymentGateway\Types\Transaction\Response $last_transaction ): bool {
		return in_array( $wc_last_order->get_status(), array( 'pending', 'on-hold', 'failed' ), true ) &&
			   $last_transaction->id !== $wc_last_order->get_transaction_id() &&
			   $this->is_last_transaction_successful( $last_transaction->status );
	}

	/**
	 * @param \WC_Order $wc_last_order
	 * @param \WC_Subscription $subscription
	 * @param \PaymentGateway\Types\Transaction\Response $last_transaction
	 * @param string $next_bill_date
	 */
	private function resolve_critical_subscription( \WC_Order $wc_last_order, \WC_Subscription $subscription, \PaymentGateway\Types\Transaction\Response $last_transaction, string $next_bill_date ) {
		$wc_last_order->payment_complete( $last_transaction->id );
		$subscription->update_dates( array( 'next_payment' => wp_date( 'Y-m-d H:i:s', strtotime( $next_bill_date ) ) ) );
	}

	/**
	 * @param \WC_Subscription $subscription
	 * @param \WC_Order $wc_last_order
	 * @param string $last_transaction_id
	 *
	 * @return bool
	 */
	private function is_time_to_pay( \WC_Subscription $subscription, \WC_Order $wc_last_order, string $last_transaction_id ) {
		return $subscription->get_time( 'next_payment' ) <= current_time( 'timestamp' ) &&
			! in_array(
				$wc_last_order->get_status(),
				array(
					'pending',
					'on-hold',
					'failed',
					'cancelled',
				),
				true
			) &&
			$last_transaction_id !== $wc_last_order->get_transaction_id();
	}

	/**
	 * @param \WC_Subscription $subscription
	 * @param \PaymentGateway\Types\Transaction\Response $last_transaction
	 * @param string $next_bill_date
	 *
	 * @return void
	 */
	private function handle_renewal( \WC_Subscription $subscription, \PaymentGateway\Types\Transaction\Response $last_transaction, string $next_bill_date ): void {
		$renewal_order = wcs_create_renewal_order( $subscription );
		if ( is_wp_error( $renewal_order ) ) {
			$this->c->logger->set_debug( true );
			$this->c->logger->error( 'subscription_id: ' . $this->c->meta->get_subscription_id( $subscription ) . '. Message: ' . $renewal_order->get_error_message() );

			return;
		}

		if ( Formatter::format_amount( $renewal_order->get_total() ) === 0 ) {
			$renewal_order->payment_complete();
		} else {
			$renewal_order->set_payment_method( wc_get_payment_gateway_by_order( $subscription ) );
			if ( is_callable( array( $renewal_order, 'save' ) ) ) {
				$renewal_order->save();
			}
		}
		$wc_last_order = wc_get_order( $subscription->get_last_order() );
		if ( $this->is_last_transaction_successful( $last_transaction->status ) ) {
			$wc_last_order->payment_complete( $last_transaction->id );
			$subscription->update_dates( array( 'next_payment' => wp_date( 'Y-m-d H:i:s', strtotime( $next_bill_date ) ) ) );
		} else {
			$wc_last_order->update_status( 'failed', __( 'Transaction for renewal order was unsuccessful' ) );
		}
	}
}
