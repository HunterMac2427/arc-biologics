<?php

namespace CustomPaymentGateway;

use CustomPaymentGateway\Helper\Constants;
use CustomPaymentGateway\Helper\Container;
use CustomPaymentGateway\Helper\WoocommerceSubscriptions;

final class Install {
	private Container $c;

	public function __construct( Container $c ) {
		$this->c = $c;
	}

	public function get_db_version_key(): string {
		return Constants::DB_VERSION_KEY;
	}

	public function run_updates() {
		$updates = $this->get_runnable_updates();
		foreach ( $updates as $key => $update ) {
			call_user_func( array( __CLASS__, $update ) );
			update_option( Constants::DB_VERSION_KEY, $key );
		}
	}

	public function get_all_updates(): array {
		$updates = array();
		foreach ( preg_grep( '/_\\d+$/', get_class_methods( __CLASS__ ) ) as $update ) {
			$updates[ substr( $update, strrpos( $update, '_' ) + 1 ) ] = $update;
		}

		return $updates;
	}

	public function get_runnable_updates(): array {
		$updates    = $this->get_all_updates();
		$db_version = get_option( Constants::DB_VERSION_KEY );
		// When someone runs the updates via the button and the db_version doesn't exist in the DB yet, that means
		// we want to run all available updates.
		if ( $db_version === false ) {
			add_option( Constants::DB_VERSION_KEY, 0 );
			$db_version = 0;
		}
		$updates = array_filter(
			$updates,
			function ( $key ) use ( $db_version ) {
				return $key > $db_version;
			},
			ARRAY_FILTER_USE_KEY
		);
		ksort( $updates );

		return $updates;
	}

	/**
	 * Migrate settings.
	 */
	public function update_1() {
		$old_cc_options  = get_option( 'woocommerce_paymentgateway_settings' );
		$old_ach_options = get_option( 'woocommerce_paymentgateway_echeck_settings' );
		$gateway_options = array();
		$gateway_options[ Constants::GATEWAY_CONFIG_KEY_API_KEY ] = $old_cc_options['api_key'] ?: '';
		$gateway_options[ Constants::GATEWAY_CONFIG_KEY_API_URL ] = $old_cc_options['url'] ?: '';
		$gateway_options[ Constants::GATEWAY_CONFIG_KEY_DEBUG ]   = $old_cc_options['debug'] ?: 'no';
		$new_card_options                                   = array();
		$new_card_options[ Constants::PM_CONFIG_KEY_TITLE ] = $old_cc_options['title'] ?: $this->c->cc_options->title;
		$new_card_options[ Constants::PM_CONFIG_KEY_DESCRIPTION ]       = $old_cc_options['description'] ?: $this->c->cc_options->description;
		$new_card_options[ Constants::PM_CONFIG_KEY_TRANSACTION_TYPE ]  = $old_cc_options['transactiontype'] ?: $this->c->cc_options->transaction_type;
		$new_card_options[ Constants::PM_CONFIG_KEY_SAVE_METHOD ]       = $old_cc_options['save_cards'] ?: $this->c->cc_options->save_method;
		$new_card_options[ Constants::CARD_CONFIG_KEY_SURCHARGE ]       = $old_cc_options['surcharge'] ?: $this->c->cc_options->surcharge;
		$new_card_options[ Constants::CARD_CONFIG_KEY_SURCHARGE_TITLE ] = $old_cc_options['surcharge_title'] ?: $this->c->cc_options->surcharge_title;
		$new_card_options[ Constants::CARD_CONFIG_KEY_SURCHARGE_TYPE ]  = $old_cc_options['surcharge_type'] ?: $this->c->cc_options->surcharge_type;
		$new_ach_options                                   = array();
		$new_ach_options[ Constants::PM_CONFIG_KEY_TITLE ] = $old_ach_options['title'] ?: $this->c->ach_options->title;
		$new_ach_options[ Constants::PM_CONFIG_KEY_DESCRIPTION ]      = $old_ach_options['description'] ?: $this->c->ach_options->description;
		$new_ach_options[ Constants::PM_CONFIG_KEY_TRANSACTION_TYPE ] = $old_ach_options['transactiontype'] ?: $this->c->ach_options->transaction_type;
		$new_ach_options[ Constants::PM_CONFIG_KEY_SAVE_METHOD ]      = $old_ach_options['save_cards'] ?: $this->c->ach_options->save_method;
		update_option( 'woocommerce_' . $this->c->cc_options->get_options_id() . '_settings', array( 'enabled' => $old_cc_options['enabled'] ?: 'no' ) );
		update_option( 'woocommerce_' . $this->c->ach_options->get_options_id() . '_settings', array( 'enabled' => $old_ach_options['enabled'] ?: 'no' ) );
		$this->c->gw_options->update_options_in_db( $gateway_options );
		$this->c->cc_options->update_options_in_db( $new_card_options );
		$this->c->ach_options->update_options_in_db( $new_ach_options );
	}

	/**
	 * Updates the gateway specific customer_id metadata for the existing users with a prefixed version.
	 */
	public function update_2() {
		$users = get_users( array( 'meta_key' => 'customer_id' ) );
		// Nothing to do if no users have the `customer_id` meta field.
		if ( empty( $users ) ) {
			return;
		}
		foreach ( $users as $user ) {
			$customer_id = get_user_meta( $user->ID, 'customer_id', true );
			if ( $customer_id ) {
				$this->c->meta->update_current_user_customer_id( $customer_id );
				delete_user_meta( $user->ID, 'customer_id' );
			}
		}
	}

	/**
	 * Updates the gateway specific subscription_id metadata on the existing subscriptions with a prefixed version.
	 */
	public function update_3() {
		if ( ! WoocommerceSubscriptions::plugin_available() ) {
			return;
		}
		$subscriptions = wcs_get_subscriptions( array( 'subscriptions_per_page' => - 1 ) );
		// Nothing to do if there are no subscriptions.
		if ( empty( $subscriptions ) ) {
			return;
		}
		// Update subscription_id meta field for available subscriptions.
		foreach ( $subscriptions as $subscription ) {
			$subscription_id = $subscription->get_meta( 'subscription_id' );
			if ( $subscription_id ) {
				$this->c->meta->update_subscription_id( $subscription, $subscription_id );
				// Remove the old meta field.
				$subscription->delete_meta_data( 'subscription_id' );
				if ( is_callable( array( $subscription, 'save' ) ) ) {
					$subscription->save();
				}
			}
		}
	}

	/**
	 * Updates the gateway specific plan_id metadata on the existing products with a prefixed version.
	 */
	public function update_4() {
		// Nothing to do if subscriptions is not enabled.
		if ( ! class_exists( '\WC_Subscriptions' ) ) {
			return;
		}
		$products = wc_get_products(
			array(
				'limit' => - 1,
				'type'  => 'subscription',
			)
		);
		// Nothing to do if there are no subscription products.
		if ( empty( $products ) ) {
			return;
		}
		// Update the plan_id meta field for the available products.
		foreach ( $products as $product ) {
			$plan_id = $product->get_meta( 'plan_id' );
			$this->c->meta->update_plan_id( $product, $plan_id );
			$product->delete_meta_data( 'plan_id' );
			if ( is_callable( array( $product, 'save' ) ) ) {
				$product->save();
			}
		}
	}
}
