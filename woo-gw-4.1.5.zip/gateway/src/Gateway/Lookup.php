<?php declare( strict_types=1 );

namespace CustomPaymentGateway\Gateway;

use CustomPaymentGateway\Actions\ApiTestAction;
use CustomPaymentGateway\Helper\Container;
use CustomPaymentGateway\Helper\Formatter;
use PaymentGateway\Exceptions\GatewayException;
use PaymentGateway\Types\Lookup\Fee\WrappedResponse;
use PaymentGateway\Types\Transaction\PaymentAdjustmentRequest;

class Lookup {
	private Container $c;
	private Builder $b;

	public function __construct( Container $c ) {
		$this->c = $c;
		$this->b = new Builder( $c );
	}

	/**
	 * Lookup for transaction fees and returns the correct values
	 *
	 * @param string $card_number
	 * @param int    $base_amount
	 * @param string $payment_method
	 * @param bool   $stored_customer
	 * @param string $customer_id
	 * @param string $payment_id
	 * @param string $processor_id
	 *
	 * @return WrappedResponse
	 */
	public function fee( string $card_number, int $base_amount, string $payment_method, bool $stored_customer, string $customer_id = '', string $payment_id = '', string $processor_id = '' ): ?WrappedResponse {
		ApiTestAction::logPluginVersions( $this->c, false );
		try {
			$req = $this->b->build_lookup_fee_request( Formatter::format_credit_card_number( $card_number ), $base_amount, $payment_method, $stored_customer, $customer_id, $payment_id, $processor_id );
			$this->c->logger->info( 'Fee calculation request: ' . $req->to_safe_json() );
			$res = $this->c->gateway->lookup->fee( $req, true );
		} catch ( \JsonMapper_Exception | GatewayException $e ) {
			$this->c->logger->error( $e->getMessage() );
			return null;
		}
		$this->c->logger->info( Formatter::correlation_id_to_log( $res->headers, 'Fee calculation response: ' . $res->to_safe_json() ) );

		return $res; // @TODO assume there is a result
	}
}
