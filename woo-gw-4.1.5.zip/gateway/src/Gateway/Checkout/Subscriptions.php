<?php declare( strict_types=1 );

namespace CustomPaymentGateway\Gateway\Checkout;

use PaymentGateway\Types\Recurring\Subscription\Request;

class Subscriptions implements \IteratorAggregate {
	/**
	 * @var Request[]
	 */
	private array $subscriptions = [];

	public function add( Request $sub ) {
		$this->subscriptions[] = $sub;
	}


	public function getIterator(): \Traversable {
		return new \ArrayIterator( $this->subscriptions );
	}
}
