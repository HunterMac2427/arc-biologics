<?php declare( strict_types=1 );

namespace CustomPaymentGateway\Gateway\Checkout;

use PaymentGateway\Types\Transaction\Request;

class Transactions implements \IteratorAggregate {
	/**
	 * @var Request[]
	 */
	private array $transactions = [];

	public function add( Request $tr ) {
		$this->transactions[] = $tr;
	}


	public function getIterator(): \Traversable {
		return new \ArrayIterator( $this->transactions );
	}
}
