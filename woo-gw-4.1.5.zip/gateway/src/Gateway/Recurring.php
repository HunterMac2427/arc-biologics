<?php declare( strict_types=1 );

namespace CustomPaymentGateway\Gateway;

use CustomPaymentGateway\Helper\Container;
use CustomPaymentGateway\Helper\Formatter;
use CustomPaymentGateway\Helper\RecurringBilling;
use JsonMapper_Exception;
use PaymentGateway\Exceptions\GatewayException;
use PaymentGateway\Types\Recurring\Subscription\CustomerRequest;
use PaymentGateway\Types\Recurring\Subscription\Request;
use PaymentGateway\Types\Recurring\Subscription\WrappedResponse;
use WC_Order;
use WC_Order_Item_Product;

class Recurring {

	private Container $c;
	private Builder $b;

	public function __construct( Container $c ) {
		$this->c = $c;
		$this->b = new Builder( $c );
	}

	/**
	 * @param WC_Order                 $order
	 * @param \WC_Product_Subscription $product
	 *
	 * @return \PaymentGateway\Types\Recurring\Plan\WrappedResponse
	 * @throws JsonMapper_Exception
	 * @throws GatewayException
	 */
	public function create_plan( WC_Order $order, \WC_Product_Subscription $product ): \PaymentGateway\Types\Recurring\Plan\WrappedResponse {
		$req = new \PaymentGateway\Types\Recurring\Plan\Request();

		try {
			$interval = (int) \WC_Subscriptions_Product::get_interval( $product );
			$billing  = new RecurringBilling( \WC_Subscriptions_Product::get_period( $product ), $interval );
		} catch ( \InvalidArgumentException $e ) {
			$this->c->logger->error( $e->getMessage() );
			// translators: %p the product name
			throw new \Exception( sprintf( __( 'Product %p cannot be purchased with the selected payment method.' ), $product->get_title() ) );
		}
		$req->name   = $product->get_title();
		$description = wp_strip_all_tags( html_entity_decode( $product->get_description() ) );
		$description = str_replace( array( "\r", "\n", "\t" ), ' ', $description );
		if ( strlen( $description ) > 254 ) {
			$req->description = mb_substr( $description, 0, 253 );
		} else {
			$req->description = $description;
		}
		$req->amount                 = Formatter::format_amount( wc_get_price_including_tax( $product ) );
		$req->billing_cycle_interval = $billing->billing_cycle_interval;
		$req->billing_frequency      = $billing->billing_frequency;
		$req->billing_days           = $billing->billing_days;
		$req->duration               = (int) \WC_Subscriptions_Product::get_length( $product );
		$req->add_ons                = array();
		$req->discounts              = array();

		$order_id = $order->get_id();
		$this->c->logger->info( "Create plan request: [${order_id}]: " . $req->to_safe_json() );
		$res = $this->c->gateway->recurring->create_plan( $req, true );
		$this->c->logger->info( Formatter::correlation_id_to_log( $res->headers, 'Create plan response: [${order_id}]: ' . $res->to_safe_json() ) );

		return $res;
	}

	/**
	 * @param string $subscription_id
	 *
	 * @return WrappedResponse
	 * @throws JsonMapper_Exception
	 * @throws GatewayException
	 */
	public function get_subscription( string $subscription_id ): WrappedResponse {
		$res = $this->c->gateway->recurring->get_subscription( $subscription_id, true );
		$this->c->logger->info( Formatter::correlation_id_to_log( $res->headers, 'Recurring get subscription;' ) );
		return $res;
	}

	/**
	 * @param WC_Order                                                $order
	 * @param WC_Order_Item_Product                                   $order_item
	 * @param \PaymentGateway\Types\Transaction\PaymentMethod\Request $pm
	 *
	 * @return WrappedResponse
	 * @throws JsonMapper_Exception
	 * @throws GatewayException
	 */
	public function create_subscription( WC_Order $order, WC_Order_Item_Product $order_item, \PaymentGateway\Types\Transaction\PaymentMethod\Request $pm ): WrappedResponse {
		if ( ! isset( $pm->customer ) || ! $pm->customer ) {
			throw new \InvalidArgumentException( 'No customer token provided.' );
		}
		$req     = new Request();
		$product = $order_item->get_product();
		// TODO: Getting the right subscription from the order based on the 'product_id' seems good, but should sanity check
		$subscription = wcs_get_subscriptions_for_order( $order, [ 'product_id' => $product->get_id() ] ) ?: wcs_get_subscription( $order );
		/** @var \WC_Subscription $subscription */
		$subscription = is_array( $subscription ) ? reset( $subscription ) : $subscription;

		// Format the billing time period fields.
		$billing = new RecurringBilling(
			$subscription->get_billing_period(),
			(int) $subscription->get_billing_interval()
		);

		$req->plan_id        = $this->c->meta->get_plan_id( $product );
		$req->next_bill_date = wp_date( 'Y-m-d', \WC_Subscriptions_Product::get_trial_expiration_date( $product ) ? strtotime( \WC_Subscriptions_Product::get_trial_expiration_date( $product ) ) : current_time( 'timestamp' ) );
		$description         = wp_strip_all_tags( html_entity_decode( $product->get_description() ) );
		$description         = str_replace( array( "\r", "\n", "\t" ), ' ', $description );
		if ( strlen( $description ) > 254 ) {
			$req->description = mb_substr( $description, 0, 253 );
		} else {
			$req->description = $description;
		}
		$req->amount                 = Formatter::format_amount( $order->get_line_total( $order_item, true ) );
		$req->billing_cycle_interval = $billing->billing_cycle_interval;
		$req->billing_frequency      = $billing->billing_frequency;
		$req->billing_days           = $billing->billing_days;
		$req->duration               = (int) \WC_Subscriptions_Product::get_length( $product );
		$req->add_ons                = array();
		$req->discounts              = array();
		$req->customer               = $this->convert_pm_request( $pm );

		$order_id = $order->get_id();
		$this->c->logger->info( "Create subscription request: [${order_id}]: " . $req->to_safe_json() );
		$res = $this->c->gateway->recurring->create_subscription( $req, true );
		$this->c->logger->info( Formatter::correlation_id_to_log( $res->headers, 'Create subscription response: [${order_id}]: ' . $res->to_safe_json() ) );

		return $res;
	}

	/**
	 * @param \WC_Subscription                                        $subscription
	 * @param WC_Order_Item_Product                                   $order_item
	 * @param \PaymentGateway\Types\Transaction\PaymentMethod\Request $pm
	 *
	 * @return WrappedResponse
	 * @throws JsonMapper_Exception
	 * @throws GatewayException
	 */
	public function update_subscription( \WC_Subscription $subscription, WC_Order_Item_Product $order_item, \PaymentGateway\Types\Transaction\PaymentMethod\Request $pm ) {
		$req      = $this->b->build_subscription_update_request( $subscription, $order_item, $pm->customer );
		$order_id = $subscription->get_id();
		$this->c->logger->info( "Update subscription request: [${order_id}]: " . $req->to_safe_json() );
		$res = $this->c->gateway->recurring->update_subscription( $this->c->meta->get_subscription_id( $subscription ), $req, true );
		$this->c->logger->info( Formatter::correlation_id_to_log( $res->headers, 'Update subscription response: [${order_id}]: ' . $res->to_safe_json() ) );
		return $res;
	}

	/**
	 * @param \PaymentGateway\Types\Transaction\PaymentMethod\Request $pm
	 *
	 * @return CustomerRequest
	 */
	private function convert_pm_request( \PaymentGateway\Types\Transaction\PaymentMethod\Request $pm ): CustomerRequest {
		$customer = new CustomerRequest();
		$customer->set_id( $pm->customer->get_id() );
		$customer->set_payment_method_id( $pm->customer->get_payment_method_id() );
		$customer->payment_method_type = $pm->customer->payment_method_type;

		return $customer;
	}
}
