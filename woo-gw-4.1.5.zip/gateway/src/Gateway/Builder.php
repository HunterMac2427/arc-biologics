<?php declare( strict_types=1 );

namespace CustomPaymentGateway\Gateway;

use CustomPaymentGateway\Gateway\Helper\SessionManager;
use CustomPaymentGateway\Helper\Constants;
use CustomPaymentGateway\Helper\Container;
use CustomPaymentGateway\Helper\Formatter;
use CustomPaymentGateway\Helper\IpAddress;
use CustomPaymentGateway\Helper\RecurringBilling;
use CustomPaymentGateway\Helper\Woocommerce\Cart\Cart;
use CustomPaymentGateway\Helper\Woocommerce\Cart\CartItem;
use CustomPaymentGateway\Settings\Options\AbstractOptions;
use CustomPaymentGateway\Settings\Settings;
use DateTimeZone;
use Exception;
use JsonMapper_Exception;
use PaymentGateway\Calculate;
use PaymentGateway\Exceptions\GatewayException;
use PaymentGateway\Types\Address\Address;
use PaymentGateway\Types\Calculate\AmountsAdditional;
use PaymentGateway\Types\Calculate\AmountsFlags;
use PaymentGateway\Types\Calculate\TypedValue;
use PaymentGateway\Types\Recurring\Discount\CreateRequest;
use PaymentGateway\Types\Recurring\Subscription\CustomerRequest;
use PaymentGateway\Types\Recurring\Subscription\SubscriptionNextBillDatesRequest;
use PaymentGateway\Types\Recurring\Subscription\UpdateRequest;
use PaymentGateway\Types\Transaction\PaymentAdjustmentRequest;
use PaymentGateway\Types\Transaction\PaymentMethod\CustomerToken\CustomerToken;
use PaymentGateway\Types\Transaction\Request;
use WC_Cart;
use WC_Coupon;
use WC_Order;
use WC_Order_Item_Fee;
use WC_Subscriptions_Product;
use WC_Tax;
use function str_replace;

class Builder {
	private Container $c;

	public function __construct( Container $c ) {
		$this->c = $c;
	}

	/**
	 * @param WC_Order $order
	 * @param bool     $shipping
	 *
	 * @return Address
	 */
	public function build_transaction_address( WC_Order $order, bool $shipping = false ): Address {
		$a = new Address();
		if ( $shipping ) {
			$a->first_name     = $order->get_shipping_first_name();
			$a->last_name      = $order->get_shipping_last_name();
			$a->company        = $order->get_shipping_company();
			$a->address_line_1 = $order->get_shipping_address_1();
			$a->address_line_2 = $order->get_shipping_address_2();
			$a->city           = $order->get_shipping_city();
			$a->state          = $order->get_shipping_state();
			$a->postal_code    = $order->get_shipping_postcode();
			$a->country        = $order->get_shipping_country();
			$a->phone          = $order->get_shipping_phone();
			$a->email          = $order->get_billing_email() ?: '';
		} else {
			$a->first_name     = $order->get_billing_first_name();
			$a->last_name      = $order->get_billing_last_name();
			$a->company        = $order->get_billing_company();
			$a->address_line_1 = $order->get_billing_address_1();
			$a->address_line_2 = $order->get_billing_address_2();
			$a->city           = $order->get_billing_city();
			$a->state          = $order->get_billing_state();
			$a->postal_code    = $order->get_billing_postcode();
			$a->country        = $order->get_billing_country();
			$a->phone          = $order->get_billing_phone();
			$a->email          = $order->get_billing_email();
		}

		return $a;
	}

	/**
	 * @param WC_Order|null $order
	 * @param bool          $shipping
	 *
	 * @return \PaymentGateway\Types\Vault\Customer\Address
	 * @throws \Exception
	 */
	public function build_vault_address( ?WC_Order $order = null, bool $shipping = false ): \PaymentGateway\Types\Vault\Customer\Address {
		$source = $order;
		if ( ! $source ) {

			// TODO: need to validate if this is the same as new \WC_Customer(get_current_user_id())
			$source = WC()->customer;
		}
		if ( ! $source ) {
			throw new Exception( "Can't get address data." );
		}
		$a = new \PaymentGateway\Types\Vault\Customer\Address();
		if ( $shipping ) {
			$a->first_name  = $source->get_shipping_first_name();
			$a->last_name   = $source->get_shipping_last_name();
			$a->company     = $source->get_shipping_company();
			$a->line_1      = $source->get_shipping_address_1();
			$a->line_2      = $source->get_shipping_address_2();
			$a->city        = $source->get_shipping_city();
			$a->state       = $source->get_shipping_state();
			$a->postal_code = $source->get_shipping_postcode();
			$a->country     = $source->get_shipping_country();
			$a->phone       = $source->get_shipping_phone();
			$a->email       = $source->get_billing_email();
		} else {
			$a->first_name  = $source->get_billing_first_name();
			$a->last_name   = $source->get_billing_last_name();
			$a->company     = $source->get_billing_company();
			$a->line_1      = $source->get_billing_address_1();
			$a->line_2      = $source->get_billing_address_2();
			$a->city        = $source->get_billing_city();
			$a->state       = $source->get_billing_state();
			$a->postal_code = $source->get_billing_postcode();
			$a->country     = $source->get_billing_country();
			$a->phone       = $source->get_billing_phone();
			$a->email       = $source->get_billing_email();
		}

		return $a;
	}

	/**
	 * @param WC_Cart                                                      $cart
	 * @param WC_Order                                                     $order
	 * @param string                                                       $tr_type
	 * @param \PaymentGateway\Types\Transaction\PaymentMethod\Request|null $pm_req
	 * @param int                                                          $sign_up_fee
	 *
	 * @return Request
	 * @throws Exception
	 */
	public function build_transaction_request( WC_Cart $cart, WC_Order $order, string $tr_type, ?\PaymentGateway\Types\Transaction\PaymentMethod\Request $pm_req = null, int $sign_up_fee = 0 ): Request {
		$r           = new Request();
		$order_id    = $order->get_id();
		$cart_helper = new Cart( $cart );

		$shipping_tax    = Formatter::format_amount( $order->get_shipping_tax() );
		$shipping_amount = Formatter::format_amount( $order->get_shipping_total() );

		$line_amount = $cart_helper->get_simple_line_total();

		$total_line     = $cart_helper->get_simple_total();
		$total_tax      = $cart_helper->get_simple_tax_total() + $shipping_tax;
		$total_shipping = $shipping_amount + $shipping_tax;

		$ip                     = new IpAddress( $this->c->http );
		$r->type                = $tr_type;
		$r->ip_address          = $ip->get_ip();
		$r->amount              = $total_line + Formatter::format_amount( $cart->get_fee_total() ) + $total_shipping;
		$r->tax_amount          = $total_tax;
		$r->shipping_amount     = $shipping_amount;
		$r->currency            = get_woocommerce_currency();
		$r->order_id            = Formatter::format_numeric_id_to_string( $order_id );
		$r->po_number           = Formatter::format_numeric_id_to_string( $order_id );
		$r->email_receipt       = false;
		$r->create_vault_record = false;
		if ( $pm_req ) {
			$r->payment_method = $pm_req;
		}
		$device_fingerprint_payload = $this->c->http->post( Constants::FORM_DEVICE_FINGERPRINT_PAYLOAD ) ? $this->c->http->post( Constants::FORM_DEVICE_FINGERPRINT_PAYLOAD ) : '';
		if ( $device_fingerprint_payload === '' && isset( $_REQUEST[ Constants::FORM_DEVICE_FINGERPRINT_PAYLOAD ] ) ) {
			if ( is_string( $_REQUEST[ Constants::FORM_DEVICE_FINGERPRINT_PAYLOAD ] ) ) {
				$device_fingerprint_payload = $_REQUEST[ Constants::FORM_DEVICE_FINGERPRINT_PAYLOAD ];
			} else {
				$r->device_fingerprint_payload = $_REQUEST[ Constants::FORM_DEVICE_FINGERPRINT_PAYLOAD ];
			}
		}
		if ( is_string( $device_fingerprint_payload ) && $device_fingerprint_payload !== '' ) {
			$decoded_payload               = json_decode( $device_fingerprint_payload );
			$r->device_fingerprint_payload = json_last_error() === JSON_ERROR_NONE ? $decoded_payload : $device_fingerprint_payload;
		}
		$r->billing_address = $this->build_transaction_address( $order );
		if ( $order->has_shipping_address() ) {
			$r->shipping_address = $this->build_transaction_address( $order, true );
		}

		$cc_options     = $this->c->cc_options;
		$ach_options    = $this->c->ach_options;
		$gw_options     = $this->c->gw_options;
		$payment_method = str_replace( 'custom_payment_gateway_', '', $order->get_payment_method() );

		$calculate_request                   = new \PaymentGateway\Types\Calculate\Request();
		$calculate_request->amount           = $line_amount;
		$calculate_request->subtotal         = $line_amount;
		$calculate_request->transaction_type = $r->type;
		$calculate_request->payment_method   = $payment_method;
		$calculate_request->source           = 'woocommerce';

		$calculate_request->tax_amount          = new TypedValue();
		$calculate_request->tax_amount->value   = $total_tax;
		$calculate_request->tax_amount->type    = 'flat';
		$calculate_request->tax_amount->include = true;

		$calculate_request->shipping_amount          = new TypedValue();
		$calculate_request->shipping_amount->value   = $shipping_amount;
		$calculate_request->shipping_amount->type    = 'flat';
		$calculate_request->shipping_amount->include = $gw_options->fee_calculation_with_shipping === 'yes';

		$processor_id = '';
		if ( $payment_method === 'card' && $cc_options->card_processor !== '' ) {
			$processor_id = $cc_options->card_processor;
		}

		if ( $payment_method === 'ach' && $ach_options->ach_processor !== '' ) {
			$processor_id = $ach_options->ach_processor;
		}

		if ( $processor_id !== '' ) {
			$calculate_request->processor_id = $processor_id;
			$r->processor_id                 = $processor_id;
		} else {
			if ( AbstractOptions::is_valid_api_url_and_api_key( $this->c, $gw_options->api_url, $gw_options->api_key ) ) {
				$merchant   = $this->c->gateway->user->merchant();
				$processors = $this->c->gateway->merchant->get_processors( $merchant->data->id );
				foreach ( $processors->data as $processor ) {
					if ( $processor->default_card ) {
						$cc_settings                   = get_option( 'custom_payment_gateway_card', [] );
						$cc_options->card_processor    = $processor->id;
						$cc_settings['card_processor'] = $cc_options->card_processor;
						update_option( 'custom_payment_gateway_card', $cc_settings );
						if ( $payment_method === 'card' ) {
							$calculate_request->processor_id = $cc_options->card_processor;
						}
					} elseif ( $processor->default_ach ) {
						$ach_settings                  = get_option( 'custom_payment_gateway_ach', [] );
						$ach_options->ach_processor    = $processor->id;
						$ach_settings['ach_processor'] = $ach_options->ach_processor;
						update_option( 'custom_payment_gateway_ach', $ach_settings );
						if ( $payment_method === 'ach' ) {
							$calculate_request->processor_id = $ach_options->ach_processor;
						}
					}
				}
			}
		}

		$session_manager = new SessionManager( $this->c );
		$card_number     = $session_manager->get_card_number();
		if ( isset( $pm_req->card ) ) {
			$card_number              = $pm_req->card->get_number();
			$calculate_request->state = $r->billing_address->state;
		}
		$calculate_request->cc_bin = Formatter::format_cc_bin( $card_number );

		if ( isset( $pm_req->customer ) ) {
			$calculate_request->customer_id       = $pm_req->customer->get_id();
			$calculate_request->payment_method_id = $pm_req->customer->get_payment_method_id();
		}

		$flags = new AmountsFlags();
		if ( $total_tax === 0 ) {
			$flags->tax_exempt        = true;
			$calculate_request->flags = $flags;
		}

		$calculate = new Calculate();
		try {
			$this->c->logger->info( 'Amount calculation req: ' . $calculate_request->to_safe_json() );
			$amount_calculation = $calculate->calculate_amounts( $calculate_request );
			$this->c->logger->info( 'Amount calculation res: ' . $amount_calculation->to_safe_json() );
			$r->amounts = $amount_calculation->data;
			if ( $gw_options->fee_calculation_with_shipping !== 'yes' ) {
				$r->amounts->total += $shipping_amount;
			}
			if ( $sign_up_fee > 0 ) {
				if ( $total_line + Formatter::format_amount( $cart->get_fee_total() ) === 0 ) {
					$r->amount         -= $total_shipping;
					$r->shipping_amount = 0;
					$r->tax_amount     -= $shipping_tax;
				}
				$r->amounts->subtotal += $sign_up_fee;
				$r->amounts->total    += $sign_up_fee;
			}
		} catch ( JsonMapper_Exception | GatewayException $e ) {
			$this->c->logger->error( $e->getMessage() );
			Settings::throw_exception( $e->getCode(), $e->getMessage() );
		}

		/*
		 * Fold third-party fees on the order (anything on $order->get_fees()
		 * that we did not put there ourselves) onto $r->amounts so the
		 * processor charge matches the order total the customer saw at
		 * checkout. The calculate /api/calculate/amounts request is built
		 * from line items only and the response overwrites $r->amounts, so
		 * without this step fees added via woocommerce_cart_calculate_fees
		 * (shipping insurance, signature confirmation, handling fees, etc.)
		 * silently disappear from the charge.
		 *
		 * The order is the source of truth at process_payment time; the cart
		 * is passed in only as a parity check because $cart->get_fees() can
		 * legitimately be empty here in some flows (see the gateway-owned
		 * checkout_block_fee restore block immediately below).
		 */
		$this->apply_third_party_fees_to_request( $r, $order, $cart );

		if ( Formatter::format_amount( $cart->get_fee_total() ) === 0 ) {
			$fees = WC()->session->get( 'checkout_block_fee', [] );
			if ( ! empty( $fees ) ) {
				foreach ( $fees as $f ) {
					if ( floatval( $f['amount'] ) !== 0.0 ) {
						$fee = new WC_Order_Item_Fee();
						$fee->set_name( $f['title'] );
						$fee->set_amount( floatval( $f['amount'] ) );
						$fee->set_total( floatval( $f['amount'] ) );
						$fee->set_tax_status( 'none' );
						$order->add_item( $fee );
					}
				}
			}
			$order->save();
			$order->calculate_totals();
		}

		return $r;
	}

	/**
	 * Add any fees on the order that the gateway did not put there itself
	 * (third-party fees added via woocommerce_cart_calculate_fees,
	 * $cart->add_fee(), etc., which WooCommerce copies onto the order as
	 * WC_Order_Item_Fee items during order creation) onto $r->amounts so the
	 * processor charge includes them. Gateway-owned fees (service fee, cash
	 * discount, surcharge) are excluded by display title because they are
	 * already in $r->amounts via the calculate API response. Fee tax is
	 * folded into $r->tax_amount for level-2/3 reporting.
	 *
	 * The order is authoritative at process_payment time. The cart is passed
	 * only as a parity check; if the two disagree by more than a cent we log
	 * a warning so future plugin interactions surface in the WC log without
	 * forcing a customer hit to discover them. Either way the order delta is
	 * what gets applied — this prevents the v4.1.2 regression where a stale
	 * or already-cleared cart fee collection caused undercharges in flows
	 * where $cart->get_fees() returns empty at process_payment.
	 *
	 * Public for testability — the typical caller is build_transaction_request.
	 *
	 * @param Request  $r     Transaction request that has already had $r->amounts populated.
	 * @param WC_Order $order The order whose third-party fees should be merged in.
	 * @param WC_Cart  $cart  The cart used for parity-checking the order's fee list.
	 *
	 * @return array{subtotal:int,total:int,tax:int} Delta (in cents) that was applied.
	 */
	public function apply_third_party_fees_to_request( Request $r, WC_Order $order, WC_Cart $cart ): array {
		$order_delta = $this->compute_third_party_fee_delta_from_order( $order );
		$cart_delta  = $this->compute_third_party_fee_delta_from_cart( $cart );

		// Parity check: warn (do not change behavior) when cart and order disagree
		// by more than a cent. An empty cart is treated as "no signal" rather than
		// a mismatch because that's the failure mode this helper is designed to
		// paper over — the order is authoritative either way.
		$cart_has_fees = ! empty( $cart->get_fees() );
		if ( $cart_has_fees && (
			abs( $order_delta['subtotal'] - $cart_delta['subtotal'] ) > 1
			|| abs( $order_delta['total'] - $cart_delta['total'] ) > 1
			|| abs( $order_delta['tax'] - $cart_delta['tax'] ) > 1
		) ) {
			$this->c->logger->warning(
				'Third-party fee parity mismatch between cart and order; using order delta. ' . wp_json_encode(
					[
						'order_delta' => $order_delta,
						'cart_delta'  => $cart_delta,
					]
				)
			);
		}

		$delta = $order_delta;
		if ( $delta['total'] === 0 && $delta['subtotal'] === 0 && $delta['tax'] === 0 ) {
			$this->guard_amounts_total_against_order_total( $r, $order );
			return $delta;
		}
		if ( isset( $r->amounts ) ) {
			$r->amounts->subtotal = ( $r->amounts->subtotal ?? 0 ) + $delta['subtotal'];
			$r->amounts->total    = ( $r->amounts->total ?? 0 ) + $delta['total'];
		}
		if ( $delta['tax'] !== 0 ) {
			$r->tax_amount = ( $r->tax_amount ?? 0 ) + $delta['tax'];
		}
		$this->c->logger->info( 'Third-party fees applied to processor amounts: ' . wp_json_encode( $delta ) );

		$this->guard_amounts_total_against_order_total( $r, $order );

		return $delta;
	}

	/**
	 * Sum the fees on the order that the gateway did not put there. Excludes
	 * gateway-owned fees by display title (Constants::GATEWAY_FEE_TITLES) since
	 * those are already represented in $r->amounts via the calculate API.
	 *
	 * @param WC_Order $order
	 *
	 * @return array{subtotal:int,total:int,tax:int}
	 */
	private function compute_third_party_fee_delta_from_order( WC_Order $order ): array {
		$delta = [
			'subtotal' => 0,
			'total'    => 0,
			'tax'      => 0,
		];
		foreach ( $order->get_fees() as $item ) {
			$name = $item instanceof WC_Order_Item_Fee ? $item->get_name() : ( $item->name ?? '' );
			if ( in_array( $name, Constants::GATEWAY_FEE_TITLES, true ) ) {
				continue;
			}
			$pre_tax = $item instanceof WC_Order_Item_Fee ? (float) $item->get_total() : (float) ( $item->total ?? 0 );
			$tax     = $item instanceof WC_Order_Item_Fee ? (float) $item->get_total_tax() : (float) ( $item->total_tax ?? 0 );

			$delta['subtotal'] += Formatter::format_amount( $pre_tax );
			$delta['total']    += Formatter::format_amount( $pre_tax + $tax );
			$delta['tax']      += Formatter::format_amount( $tax );
		}
		return $delta;
	}

	/**
	 * Sum the third-party fees currently on the cart. Identical exclusion rule
	 * to the order variant; used only for the parity check.
	 *
	 * @param WC_Cart $cart
	 *
	 * @return array{subtotal:int,total:int,tax:int}
	 */
	private function compute_third_party_fee_delta_from_cart( WC_Cart $cart ): array {
		$delta = [
			'subtotal' => 0,
			'total'    => 0,
			'tax'      => 0,
		];
		foreach ( $cart->get_fees() as $fee ) {
			if ( in_array( $fee->name, Constants::GATEWAY_FEE_TITLES, true ) ) {
				continue;
			}
			$delta['subtotal'] += Formatter::format_amount( $fee->amount );
			$delta['total']    += Formatter::format_amount( $fee->total );
			$delta['tax']      += Formatter::format_amount( $fee->tax ?? 0 );
		}
		return $delta;
	}

	/**
	 * Diagnostic-only guard. After all amount adjustments have been folded
	 * into $r->amounts->total, compare it to $order->get_total() and log a
	 * warning if the two disagree by more than a cent. Never changes the
	 * charge — its purpose is to make any *other* third-party hook we have
	 * not enumerated (woocommerce_calculated_total, woocommerce_get_order_total,
	 * etc.) immediately visible in the WC log without another customer hit.
	 *
	 * Note: subscription orders that include a sign-up fee can legitimately
	 * trigger this warning because $r->amounts->total carries the sign-up fee
	 * while $order->get_total() does not. Treat warnings on subscription
	 * orders accordingly.
	 *
	 * @param Request  $r
	 * @param WC_Order $order
	 */
	private function guard_amounts_total_against_order_total( Request $r, WC_Order $order ): void {
		if ( ! isset( $r->amounts ) || ! isset( $r->amounts->total ) ) {
			return;
		}
		$order_total_cents = Formatter::format_amount( $order->get_total() );
		$amounts_total     = (int) $r->amounts->total;
		if ( abs( $amounts_total - $order_total_cents ) > 1 ) {
			$this->c->logger->warning(
				'Processor charge total diverges from order total. ' . wp_json_encode(
					[
						'amounts_total_cents' => $amounts_total,
						'order_total_cents'   => $order_total_cents,
						'order_id'            => $order->get_id(),
					]
				)
			);
		}
	}

	/**
	 * @param WC_Order                                               $order
	 * @param \CustomPaymentGateway\Helper\Woocommerce\Cart\CartItem $cart_item
	 * @param CustomerToken|null                                     $customer_token
	 *
	 * @return array
	 */
	public function build_subscription_request( \WC_Order $order, CartItem $cart_item, ?CustomerToken $customer_token = null ) {
		$req     = new \PaymentGateway\Types\Recurring\Subscription\Request();
		$product = $cart_item->data;
		// TODO: Getting the right subscription from the order based on the 'product_id' seems good, but should sanity check
		$subscription = wcs_get_subscriptions_for_order( $order, [ 'product_id' => $product->get_id() ] ) ?: wcs_get_subscription( $order );
		/** @var \WC_Subscription $subscription */
		$subscription = is_array( $subscription ) ? reset( $subscription ) : $subscription;

		$trial_expiration_date = \WC_Subscriptions_Product::get_trial_expiration_date( $product );
		// Format the billing time period fields.
		$billing = new RecurringBilling(
			$subscription->get_billing_period(),
			(int) $subscription->get_billing_interval(),
			$trial_expiration_date === 0 ? null : $trial_expiration_date
		);

		$sign_up_fee_subtotal = Formatter::format_amount( WC_Subscriptions_Product::get_sign_up_fee( $product ) );
		$sign_up_fee_tax      = 0;
		if ( $product->get_tax_status() !== 'none' ) {
			$tax_class        = $product->get_tax_class();
			$tax_rates        = WC_Tax::get_rates( $tax_class );
			$tax_rate_percent = 0;
			if ( ! empty( $tax_rates ) ) {
				$first_rate       = array_shift( $tax_rates );
				$tax_rate_percent = $first_rate['rate'];
			}
			$sign_up_fee_tax = (int) round( $sign_up_fee_subtotal * ( $tax_rate_percent / 100 ) );
		}

		$sign_up_fee_total = $this->get_sign_up_fee_coupon( $order, $cart_item, $product, $sign_up_fee_subtotal ) + $this->get_sign_up_fee_coupon( $order, $cart_item, $product, $sign_up_fee_tax );
		$line_total        = Formatter::format_amount( $cart_item->line_total + $cart_item->line_tax ) - $sign_up_fee_total;
		$line_subtotal     = Formatter::format_amount( $cart_item->line_subtotal + $cart_item->line_subtotal_tax ) - $sign_up_fee_subtotal - $sign_up_fee_tax;

		$shipping_amount = 0;
		if ( ! $product->is_virtual() ) {
			$shipping_amount += Formatter::format_amount( $subscription->get_shipping_total() );
			$shipping_amount += Formatter::format_amount( $subscription->get_shipping_tax() );
		}
		// todo: van shipping amount field?

		// Use existing subscription_id if this is a subscription update request.
		$req->plan_id        = $this->c->meta->get_plan_id( $product );
		$req->next_bill_date = wp_date( 'Y-m-d', $trial_expiration_date ? strtotime( $trial_expiration_date ) : \WC_Subscriptions_Product::get_first_renewal_payment_time( $product ) );
		$description         = wp_strip_all_tags( html_entity_decode( $product->get_description() ) );
		$description         = str_replace( array( "\r", "\n", "\t" ), ' ', $description );
		if ( strlen( $description ) > 254 ) {
			$req->description = mb_substr( $description, 0, 253 );
		} else {
			$req->description = $description;
		}
		$req->amount                 = $line_subtotal + $shipping_amount;
		$req->currency               = $order->get_currency();
		$req->billing_cycle_interval = $billing->billing_cycle_interval;
		$req->billing_frequency      = $billing->billing_frequency;
		$req->billing_days           = $billing->billing_days;
		if ( $customer_token ) {
			$req->customer = $this->convert_customer_token_to_customer_request( $customer_token );
		}
		$req->duration     = (int) WC_Subscriptions_Product::get_length( $product );
		$req->add_ons      = [];
		$discount_requests = $this->build_subscription_coupon( $order, $cart_item, $product, $req, $line_subtotal - $line_total );
		if ( $discount_requests !== false ) {
			$req->discounts = $discount_requests;
		}

		return [
			'request'    => $req,
			'signup_fee' => $sign_up_fee_total,
		];
	}

	/**
	 * @param WC_Cart   $cart
	 * @param \WC_Order $order
	 * @param Request   $r
	 *
	 * @return \PaymentGateway\Types\Calculate\Request
	 */
	public function build_transaction_amounts( WC_Cart $cart, WC_Order $order, Request $r ): \PaymentGateway\Types\Calculate\Request {
		$pm_req         = $r->payment_method;
		$payment_method = '';
		if ( isset( $pm_req->card ) ) {
			$payment_method = 'card';
		} elseif ( isset( $pm_req->ach ) ) {
			$payment_method = 'ach';
		} elseif ( isset( $pm_req->customer ) ) {
			$payment_method = $pm_req->customer->payment_method_type;
		}

		$calculate_request                   = new \PaymentGateway\Types\Calculate\Request();
		$calculate_request->amount           = $r->amount;
		$calculate_request->subtotal         = Formatter::format_amount( $order->get_subtotal() );
		$calculate_request->transaction_type = $r->type;
		$calculate_request->payment_method   = $payment_method;
		if ( isset( $pm_req->card ) ) {
			$calculate_request->cc_bin = Formatter::format_cc_bin( $pm_req->card->get_number() );
			$calculate_request->state  = $r->billing_address->state;
		}
		$calculate_request->tax_amount          = new TypedValue();
		$calculate_request->tax_amount->value   = Formatter::format_amount( $order->get_total_tax() );
		$calculate_request->tax_amount->type    = 'flat';
		$calculate_request->tax_amount->include = false;

		$calculate_request->shipping_amount          = new TypedValue();
		$calculate_request->shipping_amount->value   = Formatter::format_amount( $order->get_shipping_total() );
		$calculate_request->shipping_amount->type    = 'flat';
		$calculate_request->shipping_amount->include = false;

		$fees = $cart->get_fees();
		foreach ( $fees as $fee ) {
			if ( ! isset( $calculate_request->additional_amounts ) ) {
				$calculate_request->additional_amounts = [];
			}
			$additional_amount                       = new AmountsAdditional();
			$additional_amount->title                = $fee->name;
			$amount                                  = new TypedValue();
			$amount->type                            = 'flat';
			$amount->include                         = false;
			$amount->value                           = Formatter::format_amount( $fee->total );
			$additional_amount->amount               = $amount;
			$additional_amount->operation            = '+';
			$calculate_request->additional_amounts[] = $additional_amount;
			$calculate_request->amount              -= $amount->value;
		}

		return $calculate_request;
	}

	public function get_sign_up_fee_coupon( \WC_Order $order, CartItem $cart_item, \WC_Product $product, int $sign_up_fee ) {
		$sign_up_fee_amount           = $sign_up_fee;
		$coupon_types_for_sign_up_fee = [ 'sign_up_fee', 'sign_up_fee_percent', 'percent' ];
		$used_coupons                 = $order->get_coupon_codes();
		foreach ( $used_coupons as $coupon_code ) {
			$coupon = new WC_Coupon( $coupon_code );
			if ( ( $coupon->is_valid_for_product( $product, $cart_item ) && in_array( $coupon->get_discount_type(), $coupon_types_for_sign_up_fee ) ) ) {
				if ( $coupon->get_discount_type() === 'sign_up_fee_percent' || $coupon->get_discount_type() === 'percent' ) {
					$sign_up_fee_amount = (int) ( ( $sign_up_fee_amount * (float) $coupon->get_amount() ) / 100 );
				} elseif ( $coupon->get_discount_type() === 'sign_up_fee' ) {
					$sign_up_fee_amount = $sign_up_fee_amount - Formatter::format_amount( $coupon->get_amount() );
				}
			}
		}
		return $sign_up_fee_amount;
	}

	public function build_subscription_coupon( \WC_Order $order, CartItem $cart_item, \WC_Product $product, \PaymentGateway\Types\Recurring\Subscription\Request $req, int $discount_amount ): array {
		$coupon_types_for_subscription    = [ 'percent', 'fixed_product', 'recurring_percent', 'recurring_fee', 'fixed_cart' ];
		$coupon_one_time_for_subscription = [ 'percent', 'fixed_product', 'fixed_cart' ];
		$discount_requests                = [];
		$used_coupons                     = $order->get_coupon_codes();
		foreach ( $used_coupons as $coupon_code ) {
			$coupon = new WC_Coupon( $coupon_code );
			if ( ( $coupon->is_valid_for_product( $product, $cart_item ) && in_array( $coupon->get_discount_type(), $coupon_types_for_subscription ) ) || $coupon->get_discount_type() === 'fixed_cart' ) {
				$discount              = new CreateRequest();
				$discount->name        = "Woocommerce Coupon - $coupon_code - " . bin2hex( random_bytes( 8 ) );
				$discount->description = "Woocommerce Coupon : $coupon_code";
				if ( $coupon->get_discount_type() === 'recurring_percent' || $coupon->get_discount_type() === 'percent' ) {
					$discount->percentage = Formatter::format_percentage( $coupon->get_amount() );
				} else {
					$discount->amount = $discount_amount;
				}
				$next_bill_request                         = new SubscriptionNextBillDatesRequest();
				$next_bill_request->billing_frequency      = $req->billing_frequency;
				$next_bill_request->billing_days           = $req->billing_days;
				$next_bill_request->first_bill_date        = $req->next_bill_date;
				$next_bill_request->billing_cycle_interval = $req->billing_cycle_interval;
				$next_bill_request->duration               = $req->duration;
				$next_bill_request->charge_on_day          = false;
				try {
					$next_bill_dates_list = $this->c->gateway->recurring->list_next_bill_dates( $next_bill_request )->data;
				} catch ( JsonMapper_Exception | GatewayException $e ) {
					$this->c->logger->error( $e->getMessage() );
					Settings::throw_exception( $e->getCode(), $e->getMessage() );
				}
				if ( $coupon->get_meta( 'wcs_number_payments' ) !== null && $coupon->get_meta( 'wcs_number_payments' ) !== '' ) {
					$discount->duration = $coupon->get_meta( 'wcs_number_payments' );
				}
				$date_time             = $coupon->get_date_expires();
				$active_for_x_payments = $coupon->get_meta( '_wcs_number_payments' );

				if ( ( $date_time === null || $date_time === '' ) && $active_for_x_payments === '' ) {
					$discount->duration = 0;
				} elseif ( $active_for_x_payments !== '' ) {
					$discount->duration = (int) $active_for_x_payments;
				} else {
					$date_time->setTimezone( new DateTimeZone( 'UTC' ) );
					$expiry_date           = $date_time->format( 'Y-m-d\TH:i:s\Z' );
					$duration              = 0;
					$next_bill_date_length = count( $next_bill_dates_list ) - 1;
					for ( $i = 0; $i < $next_bill_date_length; $i ++ ) {
						$duration++;
						if ( $next_bill_dates_list[ $i ] <= $expiry_date && $expiry_date < $next_bill_dates_list[ $i + 1 ] ) {
							break;
						}
					}
					$discount->duration = $duration;
				}
				if ( in_array( $coupon->get_discount_type(), $coupon_one_time_for_subscription ) ) {
					$discount->duration = 1;
				}
				try {
					$resp_discount        = $this->c->gateway->recurring->create_discount( $discount )->data;
					$discount_request     = new \PaymentGateway\Types\Recurring\Discount\Request();
					$discount_request->id = $resp_discount->id;
					$description          = wp_strip_all_tags( html_entity_decode( $resp_discount->description ) );
					$description          = str_replace( array( "\r", "\n", "\t" ), ' ', $description );
					if ( strlen( $description ) > 254 ) {
						$discount_request->description = mb_substr( $description, 0, 253 );
					} else {
						$discount_request->description = $description;
					}
					$discount_request->amount     = $resp_discount->amount;
					$discount_request->percentage = $resp_discount->percentage;
					$discount_request->duration   = $resp_discount->duration;
					$discount_requests[]          = $discount_request;
				} catch ( JsonMapper_Exception | GatewayException $e ) {
					$this->c->logger->error( $e->getMessage() );
					Settings::throw_exception( $e->getCode(), $e->getMessage() );
				}
			}
		}
		return $discount_requests;
	}

	/**
	 * @param \WC_Subscription       $subscription
	 * @param \WC_Order_Item_Product $order_item
	 * @param CustomerToken|null     $customer_token
	 *
	 * @return UpdateRequest
	 */
	public function build_subscription_update_request( \WC_Subscription $subscription, \WC_Order_Item_Product $order_item, ?CustomerToken $customer_token = null ): UpdateRequest {
		$req     = new UpdateRequest();
		$product = $order_item->get_product();
		// Format the billing time period fields.
		$billing = new RecurringBilling(
			$subscription->get_billing_period(),
			(int) $subscription->get_billing_interval()
		);
		// Use existing subscription_id if this is a subscription update request.
		$req->amount                 = Formatter::format_amount( $subscription->get_total( 'anyad' ) );
		$req->billing_cycle_interval = $billing->billing_cycle_interval;
		$req->billing_frequency      = $billing->billing_frequency;
		$req->billing_days           = $billing->billing_days;
		$req->next_bill_date         = wp_date( 'Y-m-d', \strtotime( $subscription->get_date( 'next_payment' ) ) );
		if ( $customer_token ) {
			$req->customer = $this->convert_customer_token_to_customer_request( $customer_token );
		}
		$req->duration = (int) WC_Subscriptions_Product::get_length( $product );

		return $req;
	}

	/**
	 * Build the request body of fee lookup
	 *
	 * @param string $card_number
	 * @param int    $base_amount
	 * @param string $payment_method
	 * @param bool   $stored_customer
	 * @param string $customer_id
	 * @param string $payment_id
	 * @param string $processor_id
	 *
	 * @return \PaymentGateway\Types\Lookup\Fee\Request
	 */
	public function build_lookup_fee_request( string $card_number, int $base_amount, string $payment_method, bool $stored_customer, string $customer_id = '', string $payment_id = '', string $processor_id = '' ): \PaymentGateway\Types\Lookup\Fee\Request {
		$req                  = new \PaymentGateway\Types\Lookup\Fee\Request();
		$req->type            = 'integrations';
		$req->type_id         = Formatter::gen_uuid();
		$req->bin             = substr( $card_number, 0, 6 );
		$req->state           = WC()->customer->get_billing_state();
		$req->payment_method  = $payment_method;
		$req->base_amount     = $base_amount;
		$req->stored_customer = $stored_customer;
		if ( $stored_customer ) {
			$req->customer_id = $customer_id;
			$req->payment_id  = $payment_id;
		} else {
			$req->customer_id = '';
			$req->payment_id  = '';
		}
		if ( $processor_id !== '' ) {
			$req->processor_id = $processor_id;
		}
		return $req;
	}

	/**
	 * @param string $value
	 * @param string $type 'flat', 'percentage'
	 *
	 * @return \PaymentGateway\Types\Transaction\PaymentAdjustmentRequest
	 */
	public function build_payment_adjustment_request( string $value, string $type = 'flat' ): PaymentAdjustmentRequest {
		$accepted_values = [ 'flat', 'percentage' ];
		if ( ! \in_array( $type, $accepted_values, true ) ) {
			throw new \InvalidArgumentException( 'Invalid Payment Adjustment type.' );
		}

		$pa_req       = new PaymentAdjustmentRequest();
		$pa_req->type = $type;
		if ( $type === 'flat' ) {
			$pa_req->value = Formatter::format_amount( $value );
		}
		if ( $type === 'percentage' ) {
			$pa_req->value = Formatter::format_percentage( $value );
		}

		return $pa_req;
	}

	/**
	 * @param \PaymentGateway\Types\Transaction\PaymentMethod\Request $pm
	 *
	 * @return CustomerRequest
	 */
	private function convert_customer_token_to_customer_request( CustomerToken $customer_token ): CustomerRequest {
		$customer = new CustomerRequest();
		$customer->set_id( $customer_token->get_id() );
		$customer->set_payment_method_id( $customer_token->get_payment_method_id() );
		$customer->payment_method_type = $customer_token->payment_method_type;

		return $customer;
	}
}
