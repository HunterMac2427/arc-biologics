<?php declare( strict_types=1 );

namespace CustomPaymentGateway\Gateway\PaymentMethod;

use CustomPaymentGateway\Helper\Constants;
use CustomPaymentGateway\Helper\Container;
use CustomPaymentGateway\Helper\Http;
use CustomPaymentGateway\Settings\Settings;
use PaymentGateway\Types;

/**
 * Class ECheckMethod
 */
final class ACH extends AbstractPaymentMethod {
	/**
	 * Constructor method
	 */
	public function __construct( Container $c ) {
		parent::__construct( $c );
		$this->title            = $this->c->ach_options->title;
		$this->description      = $this->c->ach_options->description;
		$this->save_method      = $this->c->ach_options->save_method;
		$this->transaction_type = $this->c->ach_options->transaction_type;
		$this->method_title     = __( 'Payment Gateway - eCheck' );
		$supports               = array(
			'products',
			'refunds',
			'subscriptions',
			'gateway_scheduled_payments',
			'subscription_cancellation',
			'subscription_payment_method_change',
			'subscription_payment_method_change_customer',
			'multiple_subscriptions',
			'subscription_amount_changes',
			'default_store_api',
			'subscription_suspension',
			'subscription_reactivation',
		);
		if ( $this->save_method === 'yes' ) {
			$supports[] = 'tokenization';
		}
		$this->supports = $supports;

		$this->init_settings();

		add_action(
			'woocommerce_store_api_checkout_update_order_from_request',
			function( \WC_Order $order, \WP_REST_Request $request ) {
				$request_struct = json_decode( $request->get_body(), true );
				if ( isset( $request_struct['extensions'] ) ) {
					$payment_extend = $request_struct['extensions']['checkout-payment-extend'];
					if ( isset( $payment_extend['paymentType'] ) && $payment_extend['paymentType'] === 'ach' ) {
						$_REQUEST[ Constants::FORM_ACH_ACCOUNT_NUMBER_ID ]   = $payment_extend['accountNumber'];
						$_REQUEST[ Constants::FORM_ACH_ROUTING_NUMBER_ID ]   = $payment_extend['routingNumber'];
						$_REQUEST[ Constants::FORM_ACH_ACCOUNT_TYPE_ID ]     = $payment_extend['accountType'];
						$_REQUEST[ Constants::FORM_ACH_ACCOUNT_SEC_CODE_ID ] = $payment_extend['accountSecCode'];
						if ( isset( $payment_extend[ Constants::FORM_DEVICE_FINGERPRINT_PAYLOAD ] ) ) {
							$_REQUEST[ Constants::FORM_DEVICE_FINGERPRINT_PAYLOAD ] = wp_json_encode( $payment_extend[ Constants::FORM_DEVICE_FINGERPRINT_PAYLOAD ] );
						}
						if ( $payment_extend['accountSecCode'] === 'ccd' ) {
							$_REQUEST[ Constants::FORM_ACH_COMPANY ] = $payment_extend['achCompany'];
						}
						$_REQUEST['save_method'] = $payment_extend['achSave'];
					}
				}
			},
			10,
			2
		);

		add_action(
			'admin_init',
			function () {
				if (
				isset( $_GET['page'], $_GET['tab'], $_GET['section'] ) &&
				$_GET['page'] === 'wc-settings' &&
				$_GET['tab'] === 'checkout' &&
				$_GET['section'] === 'custom_payment_gateway_ach'
				) {
					wp_safe_redirect( admin_url( 'admin.php?page=custom_payment_gateway#ach-configuration' ) );
					exit;
				}
			}
		);
	}

	/**
	 * Validate the ECheck payment fields.
	 */
	public function validate_fields(): bool {
		$all_green = parent::validate_fields();
		if ( ! $this->get_token_id_from_post() ) {
			$ach = $this->build_transaction_payment_method()->ach;
			if ( ! $ach->get_account_number() ) {
				wc_add_notice( __( 'Please provide an account number.' ), 'error' );
				$all_green = false;
			}
			if ( ! $ach->get_routing_number() ) {
				wc_add_notice( __( 'Please provide a routing number.' ), 'error' );
				$all_green = false;
			}
		}

		return $all_green;
	}

	/**
	 * @inheritDoc
	 */
	public function print_payment_form(): void { ?>
		<fieldset id="<?php echo esc_attr( Constants::FORM_ACH_ID ); ?>"
				class="wc-echeck-form wc-payment-form">
			<?php do_action( 'woocommerce_echeck_form_start', Constants::ACH_METHOD_ID ); ?>
			<p class="form-row form-row-first">
				<label
					for="<?php echo esc_attr( Constants::FORM_ACH_ACCOUNT_TYPE_ID ); ?>"><?php echo esc_html__( 'Account Type', 'custom_payment_gateway' ); ?>
					<span class="required">*</span></label>
				<select id="<?php echo esc_attr( Constants::FORM_ACH_ACCOUNT_TYPE_ID ); ?>"
						name="<?php echo esc_attr( Constants::FORM_ACH_ACCOUNT_TYPE_ID ); ?>"
						class="wc-enhanced-select">
					<option value="checking">Checking</option>
					<option value="savings">Saving</option>
				</select>
			</p>
			<p class="form-row form-row-last">
				<label
					for="<?php echo esc_attr( Constants::FORM_ACH_ACCOUNT_SEC_CODE_ID ); ?>"><?php echo esc_html__( 'Account SEC Code', 'custom_payment_gateway' ); ?>
					<span
						class="required">*</span></label>
				<select id="<?php echo esc_attr( Constants::FORM_ACH_ACCOUNT_SEC_CODE_ID ); ?>"
						name="<?php echo esc_attr( Constants::FORM_ACH_ACCOUNT_SEC_CODE_ID ); ?>"
						class="wc-enhanced-select">
					<option value="ppd">Personal</option>
					<option value="ccd">Corporate</option>
					<option value="web">Web</option>
				</select>
			</p>
			<p class="form-row form-row-first">
				<label
					for="<?php echo esc_attr( Constants::FORM_ACH_ROUTING_NUMBER_ID ); ?>"><?php echo esc_html__( 'Routing number', 'custom_payment_gateway' ); ?>
					<span
						class="required">*</span></label>
				<input id="<?php echo esc_attr( Constants::FORM_ACH_ROUTING_NUMBER_ID ); ?>"
					class="input-text"
					type="text"
					maxlength="9" autocomplete="off"
					name="<?php echo esc_attr( Constants::FORM_ACH_ROUTING_NUMBER_ID ); ?>"/>
			</p>
			<p class="form-row form-row-last">
				<label
					for="<?php echo esc_attr( Constants::FORM_ACH_ACCOUNT_NUMBER_ID ); ?>"><?php echo esc_html__( 'Account number', 'custom_payment_gateway' ); ?>
					<span class="required">*</span></label>
				<input id="<?php echo esc_attr( Constants::FORM_ACH_ACCOUNT_NUMBER_ID ); ?>"
					class="input-text"
					type="text"
					autocomplete="off"
					name="<?php echo esc_attr( Constants::FORM_ACH_ACCOUNT_NUMBER_ID ); ?>"
					maxlength="17"/>
			</p>
			<?php do_action( 'woocommerce_echeck_form_end', Constants::ACH_METHOD_ID ); ?>
			<div class="clear"></div>
		</fieldset>
		<?php
	}

	/**
	 * @return string
	 */
	public function get_payment_method_type(): string {
		return Constants::ACH_PAYMENT_METHOD_NAME;
	}

	/**
	 * @inheritDoc
	 */
	public function get_method_id(): string {
		return $this->c->ach_options->get_options_id();
	}

	/**
	 * @inheritDoc
	 */
	public function get_transaction_type(): string {
		return $this->c->ach_options->transaction_type;
	}

	/**
	 * @inheritDoc
	 */
	public function save_payment_method( Types\Transaction\Checkout\Response $res ): void {
		$ach_id     = '';
		$ach_number = '';
		if ( isset( $res->ach ) ) {
			$ach        = $res->ach;
			$ach_id     = $ach->get_id();
			$ach_number = $ach->masked_account_number;
		} elseif ( isset( $res->transactions ) && count( $res->transactions ) > 0 ) {
			if ( isset( $res->record ) ) {
				$first_ach  = reset( $res->record->data->customer->payments->ach );
				$ach_id     = $res->record->data->customer->defaults->get_payment_method_id();
				$ach_number = $first_ach->masked_account_number;
			} else {
				$this->c->logger->error( 'Error with save ach payment data.' );
				Settings::throw_exception( 0, 'Error with save ach payment data.' );
			}
		}
		if ( isset( $ach ) ) {
			$token = new \WC_Payment_Token_ECheck();
			$token->set_last4( $ach_number );
			$token->set_token( $ach_id );
			$token->set_gateway_id( $this->id );
			$token->set_user_id( get_current_user_id() );
			$token->save();
		} else {
			$this->save_payment_method_from_customer( $res->record->data->customer );
		}
	}

	/**
	 * @inheritDoc
	 */
	public function save_payment_method_from_customer( Types\Vault\Customer $customer ): void {
		$ach_tokens = $customer->payments->ach ?? [];
		$ach        = end( $ach_tokens );

		if ( ! $ach ) {
			return;
		}

		if ( $ach instanceof Types\Vault\PaymentMethod\ACH ) {
			$ach_id = $ach->get_id();
		} else {
			if ( ! isset( $ach->id ) ) {
				$this->c->logger->error( 'Missing ach data properties in stdClass.' );
				Settings::throw_exception( 0, 'Error with save ach payment data from customer.' );
			}
			$ach_id = $ach->id;
		}

		if ( $this->is_token_already_saved( $ach_id ) ) {
			return;
		}

		try {
			$token = new \WC_Payment_Token_ECheck();
			$token->set_last4( substr( $ach->masked_account_number, -4 ) );
			$token->set_token( $ach_id );
			$token->set_gateway_id( $this->id );
			$token->set_user_id( get_current_user_id() );
			$token->save();
		} catch ( \Exception $e ) {
			$this->c->logger->error( 'WooCommerce token save failed: ' . $e->getMessage() );
			Settings::throw_exception( 0, 'WooCommerce token save failed' );
		}
	}

	/**
	 * @inheritDoc
	 */
	public function build_transaction_payment_method(): Types\Transaction\PaymentMethod\Request {
		$http = $this->c->http;
		$pm   = new Types\Transaction\PaymentMethod\Request();
		$ach  = new Types\Transaction\PaymentMethod\ACH\Request();
		$ach->set_routing_number( $http->post( Constants::FORM_ACH_ROUTING_NUMBER_ID ) ? $http->post( Constants::FORM_ACH_ROUTING_NUMBER_ID ) : '' );
		if ( $ach->get_routing_number() === '' ) {
			$ach->set_routing_number( $_REQUEST[ Constants::FORM_ACH_ROUTING_NUMBER_ID ] ?? '' );
		}
		$ach->set_account_number( $http->post( Constants::FORM_ACH_ACCOUNT_NUMBER_ID ) ? $http->post( Constants::FORM_ACH_ACCOUNT_NUMBER_ID ) : '' );
		if ( $ach->get_account_number() === '' ) {
			$ach->set_account_number( $_REQUEST[ Constants::FORM_ACH_ACCOUNT_NUMBER_ID ] ?? '' );
		}
		$ach->set_sec_code( $http->post( Constants::FORM_ACH_ACCOUNT_SEC_CODE_ID ) ? $http->post( Constants::FORM_ACH_ACCOUNT_SEC_CODE_ID ) : '' );
		if ( $ach->get_sec_code() === '' ) {
			$ach->set_sec_code( $_REQUEST[ Constants::FORM_ACH_ACCOUNT_SEC_CODE_ID ] ?? '' );
			if ( $_REQUEST[ Constants::FORM_ACH_ACCOUNT_SEC_CODE_ID ] === 'ccd' ) {
				WC()->session->set( 'checkout_block_ach_company', $_REQUEST[ Constants::FORM_ACH_COMPANY ] );
			}
		}
		$ach->set_account_type( $http->post( Constants::FORM_ACH_ACCOUNT_TYPE_ID ) ? $http->post( Constants::FORM_ACH_ACCOUNT_TYPE_ID ) : '' );
		if ( $ach->get_account_type() === '' ) {
			$ach->set_account_type( $_REQUEST[ Constants::FORM_ACH_ACCOUNT_TYPE_ID ] ?? '' );
		}
		$pm->ach = $ach;
		return $pm;
	}

	/**
	 * @inheritDoc
	 */
	public function build_vault_payment_method(): Types\Vault\PaymentMethod\Create {
		$http   = $this->c->http;
		$create = new Types\Vault\PaymentMethod\Create();
		$ach    = new Types\Vault\PaymentMethod\ACH();
		$ach->set_routing_number( $http->post( Constants::FORM_ACH_ROUTING_NUMBER_ID ) ? $http->post( Constants::FORM_ACH_ROUTING_NUMBER_ID ) : '' );
		if ( $ach->get_routing_number() === '' ) {
			$ach->set_routing_number( $_REQUEST[ Constants::FORM_ACH_ROUTING_NUMBER_ID ] ?? '' );
		}
		$ach->set_account_number( $http->post( Constants::FORM_ACH_ACCOUNT_NUMBER_ID ) ? $http->post( Constants::FORM_ACH_ACCOUNT_NUMBER_ID ) : '' );
		if ( $ach->get_account_number() === '' ) {
			$ach->set_account_number( $_REQUEST[ Constants::FORM_ACH_ACCOUNT_NUMBER_ID ] ?? '' );
		}
		$ach->set_sec_code( $http->post( Constants::FORM_ACH_ACCOUNT_SEC_CODE_ID ) ? $http->post( Constants::FORM_ACH_ACCOUNT_SEC_CODE_ID ) : '' );
		if ( $ach->get_sec_code() === '' ) {
			$ach->set_sec_code( $_REQUEST[ Constants::FORM_ACH_ACCOUNT_SEC_CODE_ID ] ?? '' );
			if ( $_REQUEST[ Constants::FORM_ACH_ACCOUNT_SEC_CODE_ID ] === 'ccd' ) {
				WC()->session->set( 'checkout_block_ach_company', $_REQUEST[ Constants::FORM_ACH_COMPANY ] );
			}
		}
		$ach->set_account_type( $http->post( Constants::FORM_ACH_ACCOUNT_TYPE_ID ) ? $http->post( Constants::FORM_ACH_ACCOUNT_TYPE_ID ) : '' );
		if ( $ach->get_account_type() === '' ) {
			$ach->set_account_type( $_REQUEST[ Constants::FORM_ACH_ACCOUNT_TYPE_ID ] ?? '' );
		}
		$create->ach = $ach;
		return $create;
	}

	/**
	 * @inheritDoc
	 */
	public function set_payment_create_method( Types\Vault\Customer\PaymentTypeCreateRequest &$req ): void {
		$req->ach_create_request = $this->build_vault_payment_method()->ach;
	}
}
