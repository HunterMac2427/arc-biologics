<?php declare( strict_types=1 );

namespace CustomPaymentGateway\Gateway\PaymentMethod;

use CustomPaymentGateway\Helper\Constants;
use CustomPaymentGateway\Helper\Container;
use CustomPaymentGateway\Helper\Formatter;
use CustomPaymentGateway\Settings\Settings;
use PaymentGateway\Types;

/**
 * Class CcMethod
 */
final class Card extends AbstractPaymentMethod {
	/**
	 * Constructor method
	 */
	public function __construct( Container $c ) {
		parent::__construct( $c );
		$this->title            = $this->c->cc_options->title;
		$this->description      = $this->c->cc_options->description;
		$this->save_method      = $this->c->cc_options->save_method;
		$this->transaction_type = $this->c->cc_options->transaction_type;
		$this->method_title     = __( 'Payment Gateway - Credit card' );
		$supports               = array(
			'products',
			'default_credit_card_form',
			'refunds',
			'subscriptions',
			'gateway_scheduled_payments',
			'subscription_cancellation',
			'subscription_payment_method_change',
			'subscription_payment_method_change_customer',
			'multiple_subscriptions',
			'subscription_amount_changes',
			'default_store_api',
			'subscription_suspension',
			'subscription_reactivation',
		);
		if ( $this->save_method === 'yes' ) {
			$supports[] = 'tokenization';
		}
		$this->supports = $supports;

		$this->init_settings();

		add_action(
			'woocommerce_store_api_checkout_update_order_from_request',
			function( \WC_Order $order, \WP_REST_Request $request ) {
				$request_struct = json_decode( $request->get_body(), true );
				if ( isset( $request_struct['extensions'] ) ) {
					$payment_extend = $request_struct['extensions']['checkout-payment-extend'];
					if ( isset( $payment_extend['paymentType'] ) && $payment_extend['paymentType'] === 'card' ) {
						$_REQUEST[ Constants::FORM_CC_NUMBER_ID ] = $payment_extend['cardNumber'];
						$_REQUEST[ Constants::FORM_CC_CVC_ID ]    = $payment_extend['cardCvc'];
						$_REQUEST[ Constants::FORM_CC_EXPIRY_ID ] = $payment_extend['cardExpiry'];
						if ( isset( $payment_extend[ Constants::FORM_DEVICE_FINGERPRINT_PAYLOAD ] ) ) {
							$_REQUEST[ Constants::FORM_DEVICE_FINGERPRINT_PAYLOAD ] = wp_json_encode( $payment_extend[ Constants::FORM_DEVICE_FINGERPRINT_PAYLOAD ] );
						}
						$_REQUEST['save_method'] = $payment_extend['cardSave'];
					}
				}
			},
			10,
			2
		);

		add_action(
			'admin_init',
			function () {
				if (
				isset( $_GET['page'], $_GET['tab'], $_GET['section'] ) &&
				$_GET['page'] === 'wc-settings' &&
				$_GET['tab'] === 'checkout' &&
				$_GET['section'] === 'custom_payment_gateway_card'
				) {
					wp_safe_redirect( admin_url( 'admin.php?page=custom_payment_gateway#credit-card-configuration' ) );
					exit;
				}
			}
		);
	}

	/**
	 * Validate the Credit Card payment fields.
	 */
	public function validate_fields(): bool {
		$all_green = parent::validate_fields();
		if ( ! $this->get_token_id_from_post() ) {
			$card = $this->build_transaction_payment_method()->card;
			if ( ! $card->get_number() && ! ( isset( $_REQUEST[ Constants::FORM_CC_NUMBER_ID ] ) && ! empty( $_REQUEST[ Constants::FORM_CC_NUMBER_ID ] ) ) ) {
				wc_add_notice( __( 'Please provide a credit card number.' ), 'error' );
				$all_green = false;
			}
			if ( ! $card->get_expiration_date() && ! ( isset( $_REQUEST[ Constants::FORM_CC_EXPIRY_ID ] ) && ! empty( $_REQUEST[ Constants::FORM_CC_EXPIRY_ID ] ) ) ) {
				wc_add_notice( __( 'Please provide an expiry date for your credit card.' ), 'error' );
				$all_green = false;
			}
			if ( ! $card->get_cvc() && ! ( isset( $_REQUEST[ Constants::FORM_CC_CVC_ID ] ) && ! empty( $_REQUEST[ Constants::FORM_CC_CVC_ID ] ) ) ) {
				wc_add_notice( __( 'Please provide the card security code.' ), 'error' );
				$all_green = false;
			}
		}

		return $all_green;
	}

	/**
	 * @inheritdoc
	 */
	public function print_payment_form(): void {
		?>
		<fieldset id="<?php echo esc_attr( Constants::FORM_CC_ID ); ?>"
				class='wc-credit-card-form wc-payment-form'>
			<?php do_action( 'woocommerce_credit_card_form_start', Constants::CC_METHOD_ID ); ?>
			<p class="form-row form-row-wide">
				<label for="<?php echo esc_attr( Constants::FORM_CC_NUMBER_ID ); ?>">
					<?php echo esc_html__( 'Card Number', 'custom_payment_gateway' ); ?>
					<span class="required">*</span>
				</label>
				<input
					id="<?php echo esc_attr( Constants::FORM_CC_NUMBER_ID ); ?>"
					class="input-text wc-credit-card-form-card-number"
					type="text"
					data-fp-track="pan"
					maxlength="20"
					autocomplete="off"
					placeholder="&bull;&bull;&bull;&bull; &bull;&bull;&bull;&bull; &bull;&bull;&bull;&bull; &bull;&bull;&bull;&bull;"
					name="<?php echo esc_attr( Constants::FORM_CC_NUMBER_ID ); ?>"
				/>
			</p>
			<p class="form-row form-row-first">
				<label
					for="<?php echo esc_attr( Constants::FORM_CC_EXPIRY_ID ); ?>"><?php echo esc_html__( 'Expiry (MM/YY)', 'custom_payment_gateway' ); ?>
					<span class="required">*</span>
				</label>
				<input
					id="<?php echo esc_attr( Constants::FORM_CC_EXPIRY_ID ); ?>"
					class="input-text wc-credit-card-form-card-expiry"
					type="text" maxlength="7"
					data-fp-track="expiry"
					autocomplete="off"
					placeholder="MM / YY"
					name="<?php echo esc_attr( Constants::FORM_CC_EXPIRY_ID ); ?>"
				/>
			</p>
			<p class="form-row form-row-last">
				<label
					for="<?php echo esc_attr( Constants::FORM_CC_CVC_ID ); ?>"><?php echo esc_html__( 'Card Code', 'custom_payment_gateway' ); ?>
					<span class="required">*</span>
				</label>
				<input
					id="<?php echo esc_attr( Constants::FORM_CC_CVC_ID ); ?>"
					class="input-text wc-credit-card-form-card-cvc"
					type="text"
					data-fp-track="cvv"
					autocomplete="off"
					maxlength="4"
					placeholder="CVC"
					name="<?php echo esc_attr( Constants::FORM_CC_CVC_ID ); ?>"
				/>
			</p>
			<?php do_action( 'woocommerce_credit_card_form_end', Constants::CC_METHOD_ID ); ?>
			<div class="clear"></div>
		</fieldset>
		<?php
	}

	/**
	 * @inheritDoc
	 */
	public function save_payment_method( Types\Transaction\Checkout\Response $res ): void {
		$token       = new \WC_Payment_Token_CC();
		$card_id     = '';
		$card_number = '';
		if ( isset( $res->card ) ) {
			$card        = $res->card;
			$card_id     = $res->card->get_id();
			$card_number = $card->masked_number;
		} elseif ( isset( $res->transactions ) && count( $res->transactions ) > 0 ) {
			if ( isset( $res->record ) ) {
				$first_card = reset( $res->record->data->customer->payments->cards );
				// TODO: card id for $token->set_token not working as expected
				$card_id     = $res->record->data->customer->defaults->get_payment_method_id();
				$card_number = $first_card->masked_number;
			} else {
				$this->c->logger->error( 'Error with save card payment data.' );
				Settings::throw_exception( 0, 'Error with save card payment data.' );
			}
		}
		if ( isset( $card ) ) {
			$token->set_last4( substr( $card_number, - 4 ) );
			$token->set_expiry_year( '20' . substr( $card->get_expiration_date(), - 2 ) );
			$token->set_expiry_month( substr( $card->get_expiration_date(), 0, 2 ) );
			$token->set_card_type( $card->card_type );
			$token->set_token( $card_id );
			$token->set_gateway_id( $this->id );
			$token->set_user_id( get_current_user_id() );
			$token->save();
		} else {
			$this->save_payment_method_from_customer( $res->record->data->customer );
		}
	}

	/**
	 * @inheritDoc
	 */
	public function save_payment_method_from_customer( Types\Vault\Customer $customer ): void {
		$cards = $customer->payments->cards ?? [];
		$card  = end( $cards );

		if ( ! $card ) {
			return;
		}

		if ( $card instanceof Types\Vault\PaymentMethod\Card ) {
			$expiration_date = $card->get_expiration_date();
			$card_id         = $card->get_id();
		} else {
			if ( ! isset( $card->expiration_date ) || ! isset( $card->id ) ) {
				$this->c->logger->error( 'Missing card data properties in stdClass.' );
				Settings::throw_exception( 0, 'Error with save card payment data from customer.' );
			}
			$expiration_date = $card->expiration_date;
			$card_id         = $card->id;
		}

		if ( $this->is_token_already_saved( $card_id ) ) {
			return;
		}

		try {
			$token = new \WC_Payment_Token_CC();
			$token->set_last4( substr( $card->masked_number, - 4 ) );
			$token->set_expiry_year( '20' . substr( $expiration_date, - 2 ) );
			$token->set_expiry_month( substr( $expiration_date, 0, 2 ) );
			$token->set_card_type( strtolower( $card->card_type ) );
			$token->set_token( $card_id );
			$token->set_gateway_id( $this->id );
			$token->set_user_id( get_current_user_id() );
			$token->save();
		} catch ( \Exception $e ) {
			$this->c->logger->error( 'WooCommerce token save failed: ' . $e->getMessage() );
			Settings::throw_exception( 0, 'WooCommerce token save failed' );
		}
	}

	/**
	 * @return string
	 */
	public function get_payment_method_type(): string {
		return Constants::CC_PAYMENT_METHOD_NAME;
	}

	/**
	 * @inheritDoc
	 */
	public function get_method_id(): string {
		return $this->c->cc_options->get_options_id();
	}

	/**
	 * @inheritDoc
	 */
	public function get_transaction_type(): string {
		return $this->c->cc_options->transaction_type;
	}

	/**
	 * @inheritDoc
	 */
	public function build_transaction_payment_method(): Types\Transaction\PaymentMethod\Request {
		$http = $this->c->http;
		$pm   = new Types\Transaction\PaymentMethod\Request();
		$c    = new Types\Transaction\PaymentMethod\Card\Request();
		$c->set_number( $http->post( Constants::FORM_CC_NUMBER_ID ) ? Formatter::format_credit_card_number( $http->post( Constants::FORM_CC_NUMBER_ID ) ) : '' );
		if ( $c->get_number() === '' ) {
			$c->set_number( isset( $_REQUEST[ Constants::FORM_CC_NUMBER_ID ] ) ? Formatter::format_credit_card_number( $_REQUEST[ Constants::FORM_CC_NUMBER_ID ] ) : '' );
		}
		$c->set_expiration_date( $http->post( Constants::FORM_CC_EXPIRY_ID ) ? Formatter::format_expiry_date( $http->post( Constants::FORM_CC_EXPIRY_ID ) ) : '' );
		if ( $c->get_expiration_date() === '' ) {
			$c->set_expiration_date( isset( $_REQUEST[ Constants::FORM_CC_EXPIRY_ID ] ) ? Formatter::format_expiry_date( $_REQUEST[ Constants::FORM_CC_EXPIRY_ID ] ) : '' );
		}
		$c->set_cvc( $http->post( Constants::FORM_CC_CVC_ID ) ? $http->post( Constants::FORM_CC_CVC_ID ) : '' );
		if ( $c->get_cvc() === '' ) {
			$c->set_cvc( $_REQUEST[ Constants::FORM_CC_CVC_ID ] ?? '' );
		}
		$pm->card = $c;

		return $pm;
	}


	/**
	 * @inheritDoc
	 */
	public function build_vault_payment_method(): Types\Vault\PaymentMethod\Create {
		$http   = $this->c->http;
		$create = new Types\Vault\PaymentMethod\Create();
		$c      = new Types\Vault\PaymentMethod\Card();
		$c->set_number( $http->post( Constants::FORM_CC_NUMBER_ID ) ? Formatter::format_credit_card_number( $http->post( Constants::FORM_CC_NUMBER_ID ) ) : '' );
		if ( $c->get_number() === '' ) {
			$c->set_number( isset( $_REQUEST[ Constants::FORM_CC_NUMBER_ID ] ) ? Formatter::format_credit_card_number( $_REQUEST[ Constants::FORM_CC_NUMBER_ID ] ) : '' );
		}
		$c->set_expiration_date( $http->post( Constants::FORM_CC_EXPIRY_ID ) ? Formatter::format_expiry_date( $http->post( Constants::FORM_CC_EXPIRY_ID ) ) : '' );
		if ( $c->get_expiration_date() === '' ) {
			$c->set_expiration_date( isset( $_REQUEST[ Constants::FORM_CC_EXPIRY_ID ] ) ? Formatter::format_expiry_date( $_REQUEST[ Constants::FORM_CC_EXPIRY_ID ] ) : '' );
		}
		$c->set_cvc( $http->post( Constants::FORM_CC_CVC_ID ) ? $http->post( Constants::FORM_CC_CVC_ID ) : '' );
		if ( $c->get_cvc() === '' ) {
			$c->set_cvc( $_REQUEST[ Constants::FORM_CC_CVC_ID ] ?? '' );
		}
		$create->card = $c;

		return $create;
	}

	/**
	 * @inheritDoc
	 */
	public function set_payment_create_method( Types\Vault\Customer\PaymentTypeCreateRequest &$req ): void {
		$req->card_create_request = $this->build_vault_payment_method()->card;
	}
}
