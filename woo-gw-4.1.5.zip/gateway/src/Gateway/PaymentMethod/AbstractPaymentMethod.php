<?php declare( strict_types=1 );

namespace CustomPaymentGateway\Gateway\PaymentMethod;

use CustomPaymentGateway\Actions\ApiTestAction;
use CustomPaymentGateway\Gateway\Builder;
use CustomPaymentGateway\Gateway\Checkout;
use CustomPaymentGateway\Gateway\Checkout\Subscriptions;
use CustomPaymentGateway\Gateway\Checkout\Transactions;
use CustomPaymentGateway\Gateway\Recurring;
use CustomPaymentGateway\Gateway\Transaction;
use CustomPaymentGateway\Gateway\Vault;
use CustomPaymentGateway\Helper\Constants;
use CustomPaymentGateway\Helper\Container;
use CustomPaymentGateway\Helper\Formatter;
use CustomPaymentGateway\Helper\Woocommerce\Cart\Cart;
use CustomPaymentGateway\Helper\Woocommerce\Cart\CartItem;
use CustomPaymentGateway\Helper\WoocommerceSubscriptions;
use CustomPaymentGateway\Settings\Settings;
use Exception;
use PaymentGateway\Exceptions\GatewayException;
use PaymentGateway\Types\Transaction\Checkout\Response;
use PaymentGateway\Types\Transaction\PaymentMethod\CustomerToken\CustomerToken;
use PaymentGateway\Types\Transaction\PaymentMethod\Request;
use PaymentGateway\Types\Vault\Customer;
use PaymentGateway\Types\Vault\PaymentMethod\Create;
use PaymentGateway\Types\Vault\WrappedResponse;
use WC_Order;
use WC_Payment_Gateway;
use WC_Payment_Tokens;
use WC_Product_Subscription;
use WC_Subscription;

/**
 * Class AbstractPaymentMethod
 */
abstract class AbstractPaymentMethod extends WC_Payment_Gateway {

	/**
	 * @var Container $connector
	 */
	protected Container $c;

	public string $save_method = 'no';
	public string $token       = '';
	protected string $transaction_type;
	protected Vault $vault;
	protected Recurring $rec;
	protected Transaction $transaction;

	/**
	 * AbstractPaymentMethod constructor.
	 */
	public function __construct( Container $c ) {
		$this->c           = $c;
		$this->vault       = new Vault( $this->c );
		$this->transaction = new Transaction( $this->c );
		$this->rec         = new Recurring( $this->c );
		$this->id          = $this->get_method_id();
		$this->has_fields  = true;
		$this->enabled     = $this->get_option( 'enabled' );

		// Actions.
		add_action(
			'woocommerce_update_options_payment_gateways_' . $this->id,
			[
				$this,
				'process_admin_options',
			]
		);
		add_filter( 'woocommerce_available_payment_gateways', [ $this, 'filter_gateway' ] );

		// Add actions to extend the action's behavior with our subscription cancel function.
		// $is_payment_method_change make sure that it will cancel the subscription only in case of cancel, otherwise it will cancel on update as well.
		$is_payment_method_change = WoocommerceSubscriptions::plugin_available() && WoocommerceSubscriptions::is_change_payment_method_request();
		if ( ! $is_payment_method_change ) {
			add_action(
				'woocommerce_subscription_pending-cancel_' . $this->id,
				[
					$this,
					'cancel_subscription',
				]
			);
			add_action(
				'woocommerce_subscription_cancelled_' . $this->id,
				[
					$this,
					'cancel_subscription',
				]
			);
		}

		if ( $is_payment_method_change ) {
			wp_enqueue_script(
				'custom_payment_gateway_tokenization_form',
				plugins_url( '/gateway/frontend/src/js/tokenization.js' ),
				[ 'jquery' ],
				Constants::PLUGIN_VERSION,
				true
			);
		}
		add_action( 'woocommerce_cart_totals_get_fees_from_cart_taxes', [ $this, 'exclude_cart_fees_taxes' ], 10, 3 );
	}

	public function exclude_cart_fees_taxes( $taxes, $fee, $cart ): array {
		return [];
	}

	/**
	 * Returns the ID of the WC_Payment_Token, which is the saved version of a payment method.
	 *
	 * @return string|null The token ID if it's available.
	 */
	public function get_token_id_from_post(): ?string {
		$http      = $this->c->http;
		$token_key = 'wc-' . $this->id . '-payment-token';
		if ( $http->post( $token_key )
			&& $http->post( $token_key ) !== 'new'
		) {
			return $http->post( $token_key );
		}
		if ( isset( $_POST[ $token_key ] )
			&& $_POST[ $token_key ] !== 'new'
		) {
			return $_POST[ $token_key ];
		}

		return null;
	}

	/**
	 * Decide if the payment method should be saved
	 */
	public function should_save_payment_method(): bool {
		$add_payment_method = $this->c->http->post( 'woocommerce_add_payment_method' );
		// On the add payment method page this should always return true
		if ( $add_payment_method === '1' ) {
			return true;
		}
		if ( isset( $_REQUEST['save_method'] ) && $_REQUEST['save_method'] ) {
			return true;
		}
		$is_new_payment_method = $this->c->http->post( 'wc-' . $this->id . '-new-payment-method' );
		return $is_new_payment_method === 'true' && $this->save_method === 'yes';
	}

	/**
	 * Checkbox for saving payment methods
	 */
	public function save_payment_method_checkbox(): void {
		?>
		<p class="form-row woocommerce-SavedPaymentMethods-saveNew">
			<input id="wc-<?php echo esc_attr( $this->id ); ?>-new-payment-method"
				name="wc-<?php echo esc_attr( $this->id ); ?>-new-payment-method" type="checkbox"
				value="true" style="width:auto;"/>
			<label for="wc-<?php echo esc_attr( $this->id ); ?>-new-payment-method"
				style="display:inline;"><?php echo esc_html__( 'Save to account', 'woocommerce' ); ?>
				<?php
				if ( WoocommerceSubscriptions::plugin_available() && ( \WC_Subscriptions_Cart::cart_contains_subscription() || WoocommerceSubscriptions::is_change_payment_method_request() ) ) {
					echo '<span class="required">*</span>';
				}
				?>
			</label>
		</p>
		<?php
	}

	/**
	 * @inheritDoc
	 * @throws Exception
	 */
	public function process_payment( $order_id ) {
		$order                      = \wc_get_order( $order_id );
		$checkout_block_used        = isset( WC()->session ) && WC()->session->get( 'checkout_block_used' );
		$checkout_block_ach_company = isset( WC()->session ) ? WC()->session->get( 'checkout_block_ach_company', '' ) : '';
		$cart                       = WC()->cart;
		if ( $checkout_block_used && $order->get_total( '' ) !== $cart->get_total( '' ) ) {
			$order->set_total( $cart->get_total( '' ) );
			$order_tax = $order->get_total_tax( '' ) - $order->get_cart_tax( '' );
			$order->set_total( $cart->get_total_tax() - $order_tax, 'tax' );
			foreach ( $order->get_fees() as $fee_item ) {
				if ( floatval( $fee_item->get_amount( '' ) ) < 0.00 ) {
					$fee_item->set_taxes(
						[
							'total'    => [],
							'subtotal' => [],
						]
					);
					$fee_item->set_total_tax( 0 );
				}
			}
			foreach ( $order->get_taxes() as $tax_item ) {
				$tax_item->set_tax_total( $order->get_total_tax( '' ) - floatval( $tax_item->get_shipping_tax_total( '' ) ) );
			}
			$order->save();
		}
		if ( $checkout_block_used && $checkout_block_ach_company !== '' ) {
			$order->set_billing_address( [ 'company' => $checkout_block_ach_company ] );
			$order->save();
		}
		$wc_token_id = $this->get_token_id_from_post();
		$this->token = $wc_token_id ? WC_Payment_Tokens::get( $wc_token_id )->get_token() : '';
		// $is_sub_change change payment method on the subscription
		$is_sub_change = WoocommerceSubscriptions::plugin_available() && wcs_is_subscription( $order_id );
		$cart_helper   = new Cart( $cart );
		$b             = new Builder( $this->c );

		$simple_items    = $cart_helper->get_simple_items();
		$recurring_items = $cart_helper->get_recurring_items();

		if ( $this->c->http->get( 'pay_for_order' ) ) {
			foreach ( $order->get_items() as $item ) {
				$product = $item->get_product();
				if ( $product && ! $product->is_type( 'subscription' ) ) {
					$simple_items[] = $product;
					$cart->add_to_cart( $product->get_id(), $item->get_quantity() );
				}
			}
			$cart_helper->set_simple_items( $cart );
		}

		$transactions  = new Transactions();
		$subscriptions = new Subscriptions();

		if ( $is_sub_change ) {
			if ( ! $this->token ) {
				// We don't need the result, because the create_payment_method attaches the payment method to the end of the list,
				// and it's safer to get the last one in here.
				$this->create_payment_method();
				$saved_tokens = WC_Payment_Tokens::get_customer_tokens( get_current_user_id(), $this->id );
				$this->token  = end( $saved_tokens )->get_token();
			}
			$this->handle_subscription_change( new WC_Subscription( $order_id ) );

			return [
				'result'   => 'success',
				'redirect' => $this->get_return_url( $order ),
			];
		}

		$checkout = new Checkout( $this->c );
		WC()->session->__unset( 'checkout_block_fee' );
		$sign_up_fee = 0;
		if ( \count( $recurring_items ) > 0 ) {
			/** @var CartItem $item */
			foreach ( $cart_helper->get_recurring_items() as $item ) {
				$this->add_plan_id_to_product( $item->data, $order );
				$pm                   = $this->get_payment_method_for_request();
				$subscription_request = $b->build_subscription_request( $order, $item, $pm->customer ?? null );
				$subscriptions->add( $subscription_request['request'] );
				$sign_up_fee += $subscription_request['signup_fee'];
			}
			$checkout->subscriptions = $subscriptions;
		}
		if ( \count( $simple_items ) > 0 || $sign_up_fee > 0 ) {
			$transaction_request = $b->build_transaction_request( $cart, $order, $this->get_transaction_type(), $this->get_payment_method_for_request(), $sign_up_fee );
			if ( $transaction_request->amount > 0 ) {
				$transactions->add( $transaction_request );
			}
			$checkout->transactions = $transactions;
		}

		// TODO: How will we use AddressCreate?
		// $address_create = null;

		// When the user is paying with a token but has no customer_id attached yet as a result of
		// an older implementation.
		if ( ! $this->c->meta->get_current_user_customer_id() && $this->token ) {
			$this->token = $this->attach_customer_id_for_user( $this->token, $wc_token_id );
		}

		// When the user would like to save a payment method and there's no existing token.
		$should_update_customer_id = false;
		if ( ! $this->token && ( $this->should_save_payment_method() ) ) {
			if ( $this->customer_exists_for_user() ) {
				try {
					$vault = new Vault( $this->c );
					if ( $vault->get_customer( $this->c->meta->get_current_user_customer_id() ) ) {
						$payment_create            = new Customer\PaymentTypeCreateRequest();
						$payment_create->record_id = $this->c->meta->get_current_user_customer_id();
						$this->set_payment_create_method( $payment_create );
						$payment_create->validate_payment_method = true;
						$checkout->payment_type_create_request   = $payment_create;
					}
				} catch ( Exception $e ) {
					if ( strpos( $e->getMessage(), 'unable to find customer' ) !== false ) {
						$this->c->logger->error( 'Saved customer id is not found in gateway!' );
						$checkout->customer_create_request = $this->create_customer_create_request( $b, $order );
						$should_update_customer_id         = true;
					}
				}
			} else {
				$checkout->customer_create_request = $this->create_customer_create_request( $b, $order );
				$should_update_customer_id         = true;
			}
		}

		if ( empty( $checkout->transactions ) && empty( $checkout->subscriptions ) ) {
			// TODO: this method should support for manual created order payment, Now only support cart
			$this->c->logger->error( 'Payment related data is empty, so the plugin won’t be able to process a payment.' );
			throw new Exception( __( 'Payment attempt unsuccessful. Please contact the site administrator.', 'custom_payment_gateway' ) );
		}

		ApiTestAction::logPluginVersions( $this->c );
		try {
			$res = $checkout->checkout( $order );
		} catch ( GatewayException | \JsonMapper_Exception $e ) {
			if ( strpos( $e->getMessage(), 'plan not found' ) !== false ) {
				$subscriptions = new Subscriptions();
				foreach ( $recurring_items as $item ) {
					$plan_id = $this->c->meta->get_plan_id( $item->data );
					try {
						$this->c->gateway->recurring->get_plan( $plan_id );
					} catch ( \JsonMapper_Exception | GatewayException $e ) {
						$this->c->meta->update_plan_id( $item->data, '' );
						$item->data->save();
					}
					$this->add_plan_id_to_product( $item->data, $order );
					$pm                   = $this->get_payment_method_for_request();
					$subscription_request = $b->build_subscription_request( $order, $item, $pm->customer ?? null );
					$subscriptions->add( $subscription_request['request'] );
				}
				$checkout->subscriptions = $subscriptions;
				$res                     = $checkout->checkout( $order );
			} elseif ( strpos( $e->getMessage(), 'error getting payment method' ) !== false ) {
				$this->c->logger->error( 'Saved payment method id and customer id is not found in gateway!' );
				Settings::throw_exception( 0, 'Saved payment method id and customer id is not found in gateway!' );
			} else {
				$this->c->logger->error( $e->getMessage() );
				Settings::throw_exception( $e->getCode(), $e->getMessage() );
			}
		}

		$this->handle_subscriptions( $order, $res );
		$this->handle_transaction( $order, $res );

		// If there isn't customer ID for the user, then add it or if customer not exists, update it
		if ( $should_update_customer_id && isset( $res->data->record ) ) {
			$this->c->meta->update_current_user_customer_id( $res->data->record->get_id() );
		}
		if ( $this->should_save_payment_method() ) {
			$this->save_payment_method( $res->data );
		}

		WC()->session->__unset( 'checkout_block_used' );
		WC()->session->__unset( 'checkout_block_ach_company' );

		return [
			'result'   => 'success',
			'redirect' => $this->get_return_url( $order ),
		];
	}

	public function create_customer_create_request( $b, $order ): Customer\CreateRequest {
		$customer_create                                   = new Customer\CreateRequest();
		$customer_create->validate_payment_method          = true;
		$customer_create->customer_create                  = new Customer\Create();
		$customer_create->customer_create->default_payment = $this->build_vault_payment_method();
		$customer_create->customer_create->default_billing_address = $b->build_vault_address( $order );
		if ( $order->has_shipping_address() ) {
			$customer_create->customer_create->default_shipping_address = $b->build_vault_address( $order, true );
		} else {
			$customer_create->customer_create->default_shipping_address = $b->build_vault_address( $order );
		}
		return $customer_create;
	}

	/**
	 * @inheritDoc
	 */
	public function add_payment_method() {
		try {
			$res = $this->create_payment_method();
		} catch ( \JsonMapper_Exception | GatewayException | Exception $e ) {
			$this->c->logger->error( $e->getMessage() );
			Settings::throw_exception( $e->getCode(), $e->getMessage() );
		}
		$result = [
			'redirect' => wc_get_endpoint_url( 'payment-methods' ),
		];
		if ( $res->status === 'success' ) {
			$result['result'] = 'success';
		} else {
			$result['result'] = 'failure';
		}

		return $result;
	}

	/**
	 * @param $order_id
	 * @param $amount
	 * @param $reason
	 *
	 * @return bool|\WP_Error
	 * @throws Exception
	 */
	public function process_refund( $order_id, $amount = null, $reason = '' ) {
		// phpcs:enable
		if ( ! $amount ) {
			$this->c->logger->error( 'process_refund order_id: ' . $order_id . 'amount null' );
			return false;
		}
		$order = wc_get_order( $order_id );
		if ( ! $order || ! $order->get_transaction_id() ) {
			$this->c->logger->error( 'process_refund order_id: ' . $order_id . 'order is null' );
			return false;
		}
		try {
			$transaction = $this->c->gateway->transaction->get( $order->get_transaction_id(), true );
			$this->c->logger->info( Formatter::correlation_id_to_log( $transaction->headers, 'Process refund 1;' ) );
		} catch ( \JsonMapper_Exception | GatewayException $e ) {
			$this->c->logger->error( $e->getMessage() );
			Settings::throw_exception( $e->getCode(), $e->getMessage() );
		}

		$transaction_status = $transaction->data->status;
		$res                = null;
		try {
			if ( in_array( $transaction_status, [ 'settled', 'partially_refunded' ], true ) ) {
				$req         = new \PaymentGateway\Types\Transaction\Refund\Request();
				$req->amount = Formatter::format_amount( $amount );
				$res         = $this->c->gateway->transaction->refund( $req, $order->get_transaction_id(), true );
				$this->c->logger->info( Formatter::correlation_id_to_log( $res->headers, 'Process refund 2;' ) );
			}
			if ( in_array( $transaction_status, [ 'authorized', 'pending_settlement' ], true ) ) {
				$order = new \WC_Order( $order_id );
				if ( $amount !== $order->get_total() ) {
					return new \WP_Error( 'custom_payment_gateway_refund', __( 'The transaction is not settled yet and can only be voided. Please enter the full amount to void the transaction.', \CustomPaymentGateway\Helper\Constants::PLUGIN_ID ) );
				}

				$res = $this->c->gateway->transaction->void( $order->get_transaction_id(), true );
				$this->c->logger->info( Formatter::correlation_id_to_log( $res->headers, 'Process refund 3;' ) );
			}
		} catch ( \JsonMapper_Exception | GatewayException $e ) {
			$this->c->logger->error( $e->getMessage() );
			Settings::throw_exception( $e->getCode(), $e->getMessage() );
		}
		if ( $res->status === 'success' ) {
			return true;
		}

		$this->c->logger->error( 'Invalid transaction status: ' . $transaction_status );

		return false;
	}

	/**
	 * @inheritDoc
	 */
	public function validate_fields() {
		$all_green = true;

		if ( WoocommerceSubscriptions::plugin_available() && ( \WC_Subscriptions_Cart::cart_contains_subscription() || WoocommerceSubscriptions::is_change_payment_method_request() ) ) {
			$token_id = $this->get_token_id_from_post();
			if ( ! $token_id ) {
				$save_method_form_id = 'wc-' . $this->id . '-new-payment-method';
				if ( ! isset( $_POST[ $save_method_form_id ] ) || $_POST[ $save_method_form_id ] !== 'true' ) {
					if ( ! isset( $_REQUEST['save_method'] ) || $_REQUEST['save_method'] !== true ) {
						wc_add_notice( __( 'It is mandatory to save a payment method when purchasing a subscription.' ), 'error' );
						$all_green = false;
					}
				}
			}
		}

		return $all_green;
	}

	/**
	 * This method exists because of a previous implementation where the customer_id was used instead of a
	 * payment_method_id for payment tokens.
	 *
	 * @param string $payment_token
	 * @param string $wc_token_id
	 *
	 * @return string
	 * @throws Exception
	 */
	private function attach_customer_id_for_user( string $payment_token, string $wc_token_id ): string {
		try {
			$res = $this->vault->get_customer( $payment_token );
		} catch ( \JsonMapper_Exception | GatewayException $e ) {
			// TODO: Maybe handle logging and catching in Vault/Transaction... .php?
			$this->c->logger->error( $e->getMessage() );
			Settings::throw_exception( $e->getCode(), $e->getMessage() );
		}
		$this->c->meta->update_current_user_customer_id( $payment_token );
		$wc_token = WC_Payment_Tokens::get( $wc_token_id );
		$wc_token->set_token( $res->data->data->customer->defaults->get_payment_method_id() );
		$wc_token->save();

		return $wc_token->get_token();
	}

	/**
	 * @param WC_Product_Subscription $product
	 * @param WC_Order                $order
	 *
	 * @throws Exception
	 */
	private function add_plan_id_to_product( \WC_Product_Subscription $product, \WC_Order $order ) {
		if ( ! $this->c->meta->get_plan_id( $product ) ) {
			try {
				$res = $this->rec->create_plan( $order, $product );
			} catch ( \JsonMapper_Exception | GatewayException $e ) {
				$this->c->logger->error( $e->getMessage() );
				Settings::throw_exception( $e->getCode(), $e->getMessage() );
			}
			$this->c->meta->update_plan_id( $product, $res->data->id );
			$product->save();
		}
	}

	private function customer_exists_for_user() {
		return (bool) ( $this->c->meta->get_current_user_customer_id() );
	}

	/**
	 * @return WrappedResponse
	 * @throws GatewayException
	 * @throws \JsonMapper_Exception
	 */
	private function create_customer(): WrappedResponse {
		$res = $this->vault->create_customer( $this->get_payment_method_type(), $this->get_payment_method_for_request() );
		if ( $res->data->get_id() ) {
			$this->c->meta->update_current_user_customer_id( $res->data->get_id() );

			return $res;
		}

		throw new Exception( __( "Response didn't contain customer id.", Constants::PLUGIN_ID ) );
	}

	/**
	 * @return WrappedResponse
	 * @throws GatewayException
	 * @throws \JsonMapper_Exception
	 */
	private function create_payment_method(): WrappedResponse {
		$pm_type = $this->get_payment_method_type();
		$res     = $this->customer_exists_for_user() ? $this->vault->create_payment_method( $this->c->meta->get_current_user_customer_id(), $pm_type, $this->get_payment_method_for_request() ) : $this->create_customer();
		$this->save_payment_method_from_customer( $res->data->data->customer );

		return $res;
	}

	/**
	 * @param $available_gateways
	 *
	 * @return mixed
	 */
	public function filter_gateway( $available_gateways ) {
		$method_id = $this->id;
		if ( ! isset( $available_gateways[ $method_id ] ) ) {
			return $available_gateways;
		}

		if ( ! is_checkout() ) {
			return $available_gateways;
		}
		if ( WoocommerceSubscriptions::plugin_available() ) {
			$cart = WC()->cart;

			$recurring_carts = is_array( $cart->recurring_carts ) && count( $cart->recurring_carts ) > 0 ? $cart->recurring_carts : null;
			// When the cart contains a subscription.
			if ( $recurring_carts ) {
				foreach ( $recurring_carts as $subscription ) {
					// There's only one product per recurring cart.
					$cart_contents = $subscription->get_cart_contents();
					$product       = reset( $cart_contents )['data'];

					if (
						( \WC_Subscriptions_Product::get_period( $product ) === 'day' && (int) \WC_Subscriptions_Product::get_interval( $product ) < 4 ) ||
						$this->save_method !== 'yes'
					) {
						unset( $available_gateways[ $method_id ] );

						return $available_gateways;
					}
				}
			}
		}

		return $available_gateways;
	}

	/**
	 * @param WC_Subscription $subscription
	 *
	 * @return bool
	 */
	public function cancel_subscription( WC_Subscription $subscription ) {
		$subscription_id = $this->c->meta->get_subscription_id( $subscription );
		$res             = $this->c->gateway->recurring->update_subscription_status( $subscription_id, 'cancelled', true );
		$this->c->logger->info( Formatter::correlation_id_to_log( $res->headers, 'Subscription cancel;' ) );

		if ( $res->status === 'success' ) {
			return true;
		}
		$this->c->logger->error(
			sprintf(
			// translators: %1$s: subscription id, %2$s: response message
				__(
					'Cancelling subscription failed. Subscription ID: %1$s / Message: %2$s',
				),
				$subscription_id,
				$res->msg
			)
		);

		return false;
	}

	/**
	 * Payment section's fields implementation.
	 **/
	public function payment_fields(): void {
		wp_enqueue_script( 'wc-credit-card-form' );
		if ( $this->supports( 'tokenization' ) && $this->save_method === 'yes' && is_checkout() ) {
			$this->tokenization_script();
			$this->saved_payment_methods();
			$this->print_payment_form();
			$this->save_payment_method_checkbox();
			$this->echo_totals_calculate_button();
		} else {
			$this->print_payment_form();
			$this->echo_totals_calculate_button();
		}
	}

	protected function echo_totals_calculate_button() {
		?>
		<div style="display:none" class="custom-payment-gateway-update-totals">
			<p><br>
			<?php
				/* translators: $1 and $2 opening and closing emphasis tags respectively */
				printf( esc_html__( 'Payment method details changed, checkout needs to be updated. Please click the %1$sUpdate Totals%2$s button after filling out the payment method details.' ), '<em>', '</em>' );
			?>
				</p><br>
			<button type="button"
					class="button alt custom-payment-gateway-update-totals-button"><?php echo esc_html__( 'Update totals' ); ?></button>
		</div>
		<?php
	}

	private function handle_transaction( \WC_Order $order, \PaymentGateway\Types\Transaction\Checkout\WrappedResponse $res ) {
		if ( ! isset( $res->data->transactions ) || ! $res->data->transactions ) {
			return;
		}
		$tr_res        = reset( $res->data->transactions );
		$response_code = $tr_res->response_code ?? null;
		$response_text = $tr_res->response ?? '';
		$status        = $tr_res->status ?? '';

		// The plugin does not check the gateway for settlement after checkout, so an
		// approved sale that is awaiting batch settlement (pending_settlement) — or
		// one that has already settled — is treated as a fully processed payment.
		if ( $this->is_paid_transaction_status( $status ) ) {
			$order->payment_complete( $tr_res->id );
			return;
		}

		$wc_status = $this->map_response_code_to_status( $response_code );

		switch ( $wc_status ) {
			case Constants::WC_STATUS_PROCESSING:
			case Constants::WC_STATUS_COMPLETED:
				// Approvals and partial approvals (100-199). payment_complete()
				// decides between processing and completed based on the order's
				// contents (e.g. virtual/downloadable products complete immediately).
				$order->payment_complete( $tr_res->id );
				break;
			case Constants::WC_STATUS_ON_HOLD:
			case Constants::WC_STATUS_PENDING:
				// Pending payment (99) or unknown (0): the payment is not a hard
				// failure, but it is not confirmed either. Keep the order open and
				// flag it for manual review rather than completing or failing it.
				if ( $tr_res->id ) {
					$order->set_transaction_id( $tr_res->id );
				}
				$order->update_status(
					$wc_status,
					sprintf(
						// translators: %1$s: response code, %2$s: response text.
						__( 'Payment awaiting confirmation. Response code: %1$s, Response: %2$s', 'custom_payment_gateway' ),
						(string) $response_code,
						(string) $response_text
					)
				);
				break;
			case Constants::WC_STATUS_FAILED:
			default:
				// Declines (200-299), gateway declines (300-399) and processor
				// errors (400-499) all fail the payment.
				$this->c->logger->error( 'Transaction declined. Please check if your chosen payment method is valid. Response code: ' . $response_code . ', Response: ' . $response_text . ', Order id: ' . $order->get_id() );
				$order->update_status(
					Constants::WC_STATUS_FAILED,
					sprintf(
						// translators: %1$s: response code, %2$s: response text.
						__( 'Transaction declined. Response code: %1$s, Response: %2$s', 'custom_payment_gateway' ),
						(string) $response_code,
						(string) $response_text
					)
				);
				throw new Exception( __( 'Transaction declined. Please check if your chosen payment method is valid.', 'custom_payment_gateway' ) );
		}
	}

	/**
	 * Maps a gateway transaction response code to the WooCommerce order status it
	 * should produce.
	 *
	 * The gateway groups response codes into ranges (see
	 * https://sandbox.fluidpay.com/docs/api/transactions_response):
	 *   0           - Unknown, contact support       => on-hold (needs manual review).
	 *   99          - Pending payment                 => on-hold (awaiting payment).
	 *   100 - 199   - Approvals and partial approvals => processing (completed via payment_complete()).
	 *   200 - 299   - Declines from the issuer        => failed.
	 *   300 - 399   - Gateway declines                => failed.
	 *   400 - 499   - Processor errors                => failed.
	 * A missing or unrecognised code is treated as a failure.
	 *
	 * @param int|null $response_code
	 *
	 * @return string One of the Constants::WC_STATUS_* slugs.
	 */
	public function map_response_code_to_status( ?int $response_code ): string {
		if ( $response_code === null ) {
			return Constants::WC_STATUS_FAILED;
		}
		if ( $response_code >= Constants::RESPONSE_CODE_APPROVAL_MIN && $response_code <= Constants::RESPONSE_CODE_APPROVAL_MAX ) {
			return Constants::WC_STATUS_PROCESSING;
		}
		if ( $response_code === Constants::RESPONSE_CODE_PENDING || $response_code === Constants::RESPONSE_CODE_UNKNOWN ) {
			return Constants::WC_STATUS_ON_HOLD;
		}
		if ( $response_code >= Constants::RESPONSE_CODE_DECLINE_MIN && $response_code <= Constants::RESPONSE_CODE_PROCESSOR_ERROR_MAX ) {
			return Constants::WC_STATUS_FAILED;
		}

		return Constants::WC_STATUS_FAILED;
	}

	/**
	 * Whether the gateway transaction status represents a captured payment.
	 *
	 * Because the plugin does not poll the gateway for settlement after checkout,
	 * a sale that is approved and awaiting batch settlement (pending_settlement)
	 * is treated the same as one that has already settled.
	 *
	 * @param string|null $status The transaction status returned by the gateway.
	 *
	 * @return bool
	 */
	public function is_paid_transaction_status( ?string $status ): bool {
		return in_array( $status, Constants::GW_PAID_TRANSACTION_STATUSES, true );
	}

	/**
	 * @param WC_Order                                                   $order
	 * @param \PaymentGateway\Types\Transaction\Checkout\WrappedResponse $res
	 *
	 * @throws \WC_Data_Exception
	 */
	private function handle_subscriptions( \WC_Order $order, \PaymentGateway\Types\Transaction\Checkout\WrappedResponse $res ) {
		if ( ! isset( $res->data->subscriptions ) || ! $res->data->subscriptions ) {
			return;
		}
		$subscriptions    = wcs_get_subscriptions_for_order( $order ) ?: [ wcs_get_subscription( $order ) ];
		$gw_subscriptions = [];
		foreach ( $res->data->subscriptions as $gw_subscription ) {
			$gw_subscriptions[ $gw_subscription->plan_id ] = $gw_subscription;
		}

		/** @var \WC_Subscription $subscription */
		foreach ( $subscriptions as $subscription ) {
			$order_item = $subscription->get_items();
			$product    = reset( $order_item )->get_product();
			$plan_id    = $this->c->meta->get_plan_id( $product );
			$gw_sub     = $gw_subscriptions[ $plan_id ];
			$this->c->meta->update_subscription_id( $subscription, $gw_sub->id );
			$has_discounts = is_array( $gw_sub->discounts ) && isset( $gw_sub->discounts[0] );
			if ( $has_discounts && ( $gw_sub->discounts[0]->duration === 0 || $gw_sub->discounts[0]->duration > 2 ) ) {
				$gw_sub_total = $gw_sub->amount - $gw_sub->total_discounts;
				$subscription->set_total( number_format( $gw_sub_total / 100, 2, '.', '' ) );
			} else {
				$subscription->set_total( number_format( $gw_sub->amount / 100, 2, '.', '' ) );
			}
			$subscription->payment_complete();
			if ( is_callable( [ $subscription, 'save' ] ) ) {
				$subscription->save();
			}
		}
	}

	/**
	 * @param WC_Subscription $subscription
	 *
	 * @throws Exception
	 */
	private function handle_subscription_change( WC_Subscription $subscription ) {
		$order_items = $subscription->get_items();
		$order_item  = reset( $order_items );
		if ( ! $order_item ) {
			return;
		}
		try {
			$this->rec->update_subscription( $subscription, $order_item, $this->get_payment_method_for_request() );
		} catch ( \JsonMapper_Exception | GatewayException $e ) {
			$this->c->logger->error( $e->getMessage() );
			Settings::throw_exception( $e->getCode(), $e->getMessage() );
		}
	}

	/**
	 * Creates the payment method based on the payment type, and if the token is not set, then we go with the type specific builder.
	 *
	 * @return Request
	 */
	private function get_payment_method_for_request(): Request {
		if ( $this->token ) {
			$pm = new Request();
			$ct = new CustomerToken();
			$ct->set_id( $this->c->meta->get_current_user_customer_id() );
			$ct->payment_method_type = $this->get_payment_method_type();
			$ct->set_payment_method_id( $this->token );
			$pm->customer = $ct;
			return $pm;
		} else {
			return $this->build_transaction_payment_method();
		}
	}

	public function is_token_already_saved( string $card_id ): bool {
		$user_tokens = \WC_Payment_Tokens::get_customer_tokens( get_current_user_id(), $this->id );
		foreach ( $user_tokens as $token ) {
			if ( $token->get_token() === $card_id ) {
				return true;
			}
		}
		return false;
	}

	/**
	 * @param Response $res
	 */
	abstract public function save_payment_method( Response $res ): void;

	/**
	 * @param Customer $customer
	 */
	abstract public function save_payment_method_from_customer( Customer $customer ): void;

	/**
	 * Print the form for using a payment method
	 */
	abstract public function print_payment_form(): void;

	/**
	 * @return string The name of the payment method on the GW.
	 */
	abstract public function get_payment_method_type(): string;

	abstract public function get_method_id(): string;

	abstract public function get_transaction_type(): string;

	abstract public function build_transaction_payment_method(): Request;

	abstract public function build_vault_payment_method(): Create;

	abstract public function set_payment_create_method( Customer\PaymentTypeCreateRequest &$req ): void;
}
