<?php

namespace CustomPaymentGateway\Gateway\Helper;

use CustomPaymentGateway\Helper\Constants;
use CustomPaymentGateway\Helper\Container;

class SessionManager extends \CustomPaymentGateway\Helper\Woocommerce\SessionManager {
	/**
	 * Get the card number's session value
	 *
	 * @return string
	 */
	public function get_card_number(): string {
		return WC()->session->get( Constants::FORM_CC_NUMBER_ID ) ?: '';
	}

	/**
	 * Sets the card number's session value
	 *
	 * @param string $card_number
	 */
	public function set_card_number( string $card_number ): void {
		WC()->session->set( Constants::FORM_CC_NUMBER_ID, substr( $card_number, 0, 6 ) );
	}

	/**
	 * Unsets the card number's session value
	 */
	public function unset_card_number(): void {
		$this->unset_session( Constants::FORM_CC_NUMBER_ID );
	}

	/**
	 * Get the payment method's session value
	 *
	 * @return string
	 */
	public function get_payment_method(): string {
		return WC()->session->get( Constants::FORM_PAYMENT_METHOD_ID ) ?: '';
	}

	/**
	 * Sets the payment method's session value
	 *
	 * @param string $payment_method
	 */
	public function set_payment_method( string $payment_method ): void {
		WC()->session->set( Constants::FORM_PAYMENT_METHOD_ID, $payment_method );
	}

	/**
	 * Sets the stored_customer's session value
	 *
	 * @param string $stored_customer
	 */
	public function set_stored_customer( string $stored_customer ): void {
		WC()->session->set( Constants::FORM_STORED_CUSTOMER, $stored_customer );
	}

	/**
	 * Sets the payment_id's session value
	 *
	 * @param string $payment_id
	 */
	public function set_payment_id( string $payment_id ): void {
		WC()->session->set( Constants::FORM_PAYMENT_ID, $payment_id );
	}

	/**
	 * Unsets the payment method's session value
	 */
	public function unset_payment_method(): void {
		$this->unset_session( Constants::FORM_PAYMENT_METHOD_ID );
	}

	/**
	 * Get the gateway ID's session value
	 *
	 * @return string
	 */
	public function get_gateway_id(): string {
		return WC()->session->get( Constants::FORM_GATEWAY_ID ) ?: '';
	}

	/**
	 * Sets the gateway ID's session value
	 *
	 * @param string $gateway_id
	 */
	public function set_gateway_id( string $gateway_id ): void {
		WC()->session->set( Constants::FORM_GATEWAY_ID, $gateway_id );
	}

	/**
	 * Unsets the gateway ID's session value
	 */
	public function unset_gateway_id(): void {
		$this->unset_session( Constants::FORM_GATEWAY_ID );
	}

	/**
	 * Resets the session
	 */
	public function reset_session(): void {
		$this->unset_card_number();
		$this->unset_gateway_id();
		$this->unset_payment_method();
	}
}
