<?php declare( strict_types=1 );

namespace CustomPaymentGateway\Gateway;

use CustomPaymentGateway\Helper\Container;
use CustomPaymentGateway\Helper\Formatter;
use Exception;
use JsonMapper_Exception;
use PaymentGateway\Exceptions\GatewayException;
use PaymentGateway\Types\Transaction\PaymentMethod\Request;
use PaymentGateway\Types\Transaction\WrappedResponse;
use WC_Order;

class Transaction {

	private Container $c;
	private Builder $b;

	public function __construct( Container $c ) {
		$this->b = new Builder( $c );
		$this->c = $c;
	}

	/**
	 * @param WC_Order                                  $order
	 * @param \PaymentGateway\Types\Transaction\Request $req
	 *
	 * @return WrappedResponse
	 * @throws Exception
	 */
	public function transaction( WC_Order $order, \PaymentGateway\Types\Transaction\Request $req ): WrappedResponse {
		$order_id = $order->get_id();

		$this->c->logger->info( "Transaction request: [${order_id}]: " . $req->to_safe_json() );
		try {
			switch ( $req->type ) {
				case 'sale':
					$res = $this->c->gateway->transaction->sale( $req, true );
					$this->c->logger->info( Formatter::correlation_id_to_log( $res->headers, 'Transaction sale;' ) );

					break;
				case 'authorize':
					$res = $this->c->gateway->transaction->auth( $req, true );
					$this->c->logger->info( Formatter::correlation_id_to_log( $res->headers, 'Transaction authorize;' ) );
					break;
				default:
					throw new Exception( __( 'Gateway exception. Please contact the site administrator.' ) );
			}
		} catch ( JsonMapper_Exception | GatewayException $e ) {
			$this->c->logger->error( $e->getMessage() );
			throw new Exception( __( 'Gateway exception. Please contact the site administrator.' ) );
		}
		$this->c->logger->info( "Transaction response: [${order_id}]: " . $res->to_safe_json() );

		return $res;
	}

	/**
	 * @param \PaymentGateway\Types\Transaction\Refund\Request $req
	 * @param string $order_id
	 *
	 * @return WrappedResponse
	 * @throws GatewayException
	 * @throws JsonMapper_Exception
	 */
	public function refund( \PaymentGateway\Types\Transaction\Refund\Request $req, string $order_id ): WrappedResponse {
		$res = $this->c->gateway->transaction->refund( $req, $order_id, true );
		$this->c->logger->info( Formatter::correlation_id_to_log( $res->headers, 'Transaction refund;' ) );
		return $res;
	}

	/**
	 * @param string $order_id
	 *
	 * @return WrappedResponse
	 * @throws GatewayException
	 * @throws JsonMapper_Exception
	 */
	public function void( string $order_id ): WrappedResponse {
		$res = $this->c->gateway->transaction->void( $order_id, true );
		$this->c->logger->info( Formatter::correlation_id_to_log( $res->headers, 'Transaction void;' ) );
		return $res;
	}
}
