<?php declare( strict_types=1 );

namespace CustomPaymentGateway\Gateway;

use CustomPaymentGateway\Gateway\Checkout\Subscriptions;
use CustomPaymentGateway\Gateway\Checkout\Transactions;
use CustomPaymentGateway\Helper\Container;
use CustomPaymentGateway\Helper\Formatter;
use PaymentGateway\Types\Transaction\Checkout\Addresses;
use PaymentGateway\Types\Transaction\Checkout\AddressesFor;
use PaymentGateway\Types\Transaction\Checkout\Request;
use PaymentGateway\Types\Transaction\Checkout\WrappedResponse;
use PaymentGateway\Types\Vault\Customer\CreateRequest;
use PaymentGateway\Types\Vault\Customer\PaymentTypeCreateRequest;

class Checkout {

	private Container $c;

	public ?Transactions $transactions                            = null;
	public ?Subscriptions $subscriptions                          = null;
	public ?CreateRequest $customer_create_request                = null;
	public ?PaymentTypeCreateRequest $payment_type_create_request = null;
	public ?AddressesFor $addresses_for                           = null;
	public ?Addresses $addresses                                  = null;

	public function __construct( Container $c ) {
		$this->c = $c;
	}

	/**
	 * @param \WC_Order $order
	 *
	 * @return WrappedResponse
	 * @throws \JsonMapper_Exception
	 * @throws \PaymentGateway\Exceptions\GatewayException
	 */
	public function checkout( \WC_Order $order ): WrappedResponse {
		$req = new Request();

		if ( $this->transactions ) {
			$req->transactions = \iterator_to_array( $this->transactions );
		}

		if ( $this->subscriptions ) {
			$req->subscriptions = \iterator_to_array( $this->subscriptions );
		}

		if ( $this->customer_create_request ) {
			$req->customer_create = $this->customer_create_request;
		}

		if ( $this->payment_type_create_request ) {
			$req->payment_create = $this->payment_type_create_request;
		}

		if ( $this->addresses && $this->addresses_for ) {
			$req->addresses_for = $this->addresses_for;
			$req->set_addresses( $this->addresses );
		}

		$order_id = $order->get_id();
		$this->c->logger->info( "Checkout request: [${order_id}]: " . $req->to_safe_json() );
		$res = $this->c->gateway->transaction->checkout( $req, true );
		$this->c->logger->info( Formatter::correlation_id_to_log( $res->headers, 'Checkout response: [${order_id}]: ' . $res->to_safe_json() ) );

		$this->save_as_custom_fields( $order_id, $res );

		return $res;
	}

	/**
	 * @param int             $order_id
	 * @param WrappedResponse $res
	 *
	 * @return void
	 */
	private function save_as_custom_fields( int $order_id, WrappedResponse $res ) {
		$order_transaction_data  = null;
		$order_subscription_data = null;
		$avs_code                = '';
		$cvv_code                = '';

		if ( isset( $res->data->subscriptions ) ) {
			$order_subscription_data = $res->data->subscriptions[0];
		}

		if ( isset( $res->data->transactions ) ) {
			$order_transaction_data = $res->data->transactions[0];
			if ( isset( $order_transaction_data->response_body->card ) ) {
				$avs_code = $order_transaction_data->response_body->card->avs_response_code;
				$cvv_code = $order_transaction_data->response_body->card->cvv_response_code;
			}
		}

		if ( isset( $order_subscription_data ) ) {
			if ( count( $res->data->subscriptions ) > 1 ) {
				$responses = '';
				$ids       = '';
				$messages  = '';
				foreach ( $res->data->subscriptions as $sub ) {
					$responses .= 'Your subscription is ' . $sub->status . '; ';
					$ids       .= $sub->id . '; ';
					$messages  .= $sub->status . '; ';
				}
				update_post_meta( $order_id, 'Gateway - Subscription Responses', $responses );
				update_post_meta( $order_id, 'Gateway - Subscription IDs', $ids );
				update_post_meta( $order_id, 'Gateway - Subscription Messages', $messages );
			} else {
				update_post_meta( $order_id, 'Gateway - Subscription Response', 'Your subscription is ' . $order_subscription_data->status );
				update_post_meta( $order_id, 'Gateway - Subscription ID', $order_subscription_data->id );
				update_post_meta( $order_id, 'Gateway - Subscription Message', $order_subscription_data->status );
			}
		}
		if ( isset( $order_transaction_data ) ) {
			update_post_meta( $order_id, 'Gateway - Transaction Response', $order_transaction_data->response_code . ' your transaction was ' . $order_transaction_data->response );
			update_post_meta( $order_id, 'Gateway - Transaction ID', $order_transaction_data->id );
			update_post_meta( $order_id, 'Gateway - Transaction Message', $order_transaction_data->response );
		}
		update_post_meta( $order_id, 'Gateway - AVS Response', $avs_code );
		update_post_meta( $order_id, 'Gateway - CVV Response', $cvv_code );
	}
}
