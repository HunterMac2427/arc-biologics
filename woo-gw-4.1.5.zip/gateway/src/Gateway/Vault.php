<?php declare( strict_types=1 );

namespace CustomPaymentGateway\Gateway;

use CustomPaymentGateway\Helper\Container;
use CustomPaymentGateway\Helper\Formatter;
use JsonMapper_Exception;
use PaymentGateway\Exceptions\GatewayException;
use PaymentGateway\Types\Transaction\PaymentMethod\Request;
use PaymentGateway\Types\Vault\Customer\Create;
use PaymentGateway\Types\Vault\PaymentMethod\ACH;
use PaymentGateway\Types\Vault\PaymentMethod\Card;
use PaymentGateway\Types\Vault\WrappedResponse;

class Vault {

	private Container $c;
	private Builder $b;

	public function __construct( Container $c ) {
		$this->c = $c;
		$this->b = new Builder( $this->c );
	}

	/**
	 * @param string $customer_id
	 *
	 * @return WrappedResponse
	 * @throws JsonMapper_Exception
	 * @throws GatewayException
	 */
	public function get_customer( string $customer_id ): WrappedResponse {
		$res = $this->c->gateway->vault->get_customer( $customer_id, true );
		$this->c->logger->info( Formatter::correlation_id_to_log( $res->headers, 'Get customer;' ) );
		return $res;
	}

	/**
	 * @param string $customer_id
	 * @param string $pm_type
	 * @param string $pm_id
	 *
	 * @return \PaymentGateway\Types\WrappedResponse
	 * @throws JsonMapper_Exception
	 * @throws GatewayException
	 */
	public function delete_customer_payment_method( string $customer_id, string $pm_type, string $pm_id ): \PaymentGateway\Types\WrappedResponse {
		$res = $this->c->gateway->vault->delete_payment_method( $customer_id, $pm_type, $pm_id, true );
		$this->c->logger->info( Formatter::correlation_id_to_log( $res->headers, 'Delete customer payment method;' ) );
		return $res;
	}

	/**
	 * @param string $pm_type
	 * @param Request $req
	 * @param \WC_Order|null $order
	 *
	 * @return WrappedResponse
	 * @throws JsonMapper_Exception
	 * @throws GatewayException
	 */
	public function create_customer( string $pm_type, Request $req, ?\WC_Order $order = null ): WrappedResponse {
		$r                          = new Create();
		$pm                         = $this->transform_method_request( $pm_type, $req );
		$r->default_payment         = $pm;
		$r->default_billing_address = $this->b->build_vault_address( $order );

		$order_id = null;
		if ( $order instanceof \WC_Order ) {
			$order_id = $order->get_id();

			if ( $order->has_shipping_address() ) {
				$r->default_shipping_address = $this->b->build_vault_address( $order, true );
			}
		}
		$user_id = get_current_user_id();
		$this->c->logger->info( 'Create customer request [' . isset( $order_id ) ? 'orderID: ' . $order_id : 'userID: ' . $user_id . ']: ' . $r->to_safe_json() );
		$res = $this->c->gateway->vault->create_customer( $r, true, true );
		$this->c->logger->info( Formatter::correlation_id_to_log( $res->headers, 'Create customer response [' . isset( $order_id ) ? 'orderID: ' . $order_id : 'userID: ' . $user_id . ']: ' . $res->to_safe_json() ) );

		return $res;
	}

	/**
	 * @param string $customer_id
	 * @param string $pm_type
	 * @param Request $req
	 *
	 * @return WrappedResponse
	 * @throws JsonMapper_Exception
	 * @throws GatewayException
	 */
	public function create_payment_method( string $customer_id, string $pm_type, Request $req, ?\WC_Order $order = null ): WrappedResponse {
		$res      = $this->c->gateway->vault->create_payment_method( $customer_id, $pm_type, $this->transform_method_request( $pm_type, $req )->$pm_type, true, true, true );
		$order_id = null;
		if ( $order instanceof \WC_Order ) {
			$order_id = $order->get_id();
		}
		$user_id = get_current_user_id();
		$this->c->logger->info( Formatter::correlation_id_to_log( $res->headers, 'Create customer response [' . isset( $order_id ) ? 'orderID: ' . $order_id : 'userID: ' . $user_id . ']: ' . $res->to_safe_json() ) );

		return $res;
	}

	/**
	 * @param string $pm_type
	 * @param Request $req
	 *
	 * @return \PaymentGateway\Types\Vault\PaymentMethod\Create
	 */
	private function transform_method_request( string $pm_type, Request $req ): \PaymentGateway\Types\Vault\PaymentMethod\Create {
		// TODO: can't this be handled with an abstraction in the *Method.php files?
		switch ( $pm_type ) {
			case 'card':
				$pm   = new \PaymentGateway\Types\Vault\PaymentMethod\Create();
				$card = new Card();
				$card->set_number( $req->card->get_number() );
				$card->set_expiration_date( $req->card->get_expiration_date() );
				$card->set_cvc( $req->card->get_cvc() );
				$pm->card = $card;

				return $pm;
			case 'ach':
				$pm  = new \PaymentGateway\Types\Vault\PaymentMethod\Create();
				$ach = new ACH();
				$ach->set_routing_number( ( $req->ach->get_routing_number() ) );
				$ach->set_account_number( ( $req->ach->get_account_number() ) );
				$ach->set_account_type( ( $req->ach->get_account_type() ) );
				$ach->set_sec_code( ( $req->ach->get_sec_code() ) );
				$pm->ach = $ach;

				return $pm;
		}
		throw new \InvalidArgumentException( 'Invalid payment type.' );
	}
}
