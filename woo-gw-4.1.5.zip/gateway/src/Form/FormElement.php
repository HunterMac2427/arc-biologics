<?php

namespace CustomPaymentGateway\Form;

use CustomPaymentGateway\Helper\Container;

abstract class FormElement {
	public string $id;
	public string $value;
	public Args $args;
	public string $description;

	/**
	 * FormElement constructor.
	 *
	 * @param string $id          The form element id
	 * @param string $value       The form element value
	 * @param string $description The form element description
	 * @param ?Args  $args
	 */
	public function __construct( string $id, string $value, string $description = '', ?Args $args = null ) {
		$this->id          = esc_attr( $id );
		$this->value       = esc_attr( $value );
		$this->description = esc_html( $description );
		$this->args        = $args ?: new Args();
	}

	public function render() {
		$this->element();
		if ( ! empty( $this->description ) ) {
			echo '<p class="description">' . $this->description . '</p>';
		}
	}

	abstract protected function element();
}
