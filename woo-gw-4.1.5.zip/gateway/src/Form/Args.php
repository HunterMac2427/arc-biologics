<?php declare( strict_types=1 );

namespace CustomPaymentGateway\Form;

class Args {
	public string $placeholder;
	public Classes $classes;
	public bool $label_for;

	/**
	 * @param string   $placeholder
	 * @param ?Classes $classes
	 * @param bool     $label_for
	 */
	public function __construct( string $placeholder = '', ?Classes $classes = null, bool $label_for = true ) {
		$this->placeholder = esc_attr( $placeholder );
		$this->classes     = $classes ?: new Classes();
		$this->label_for   = $label_for;
	}
}
