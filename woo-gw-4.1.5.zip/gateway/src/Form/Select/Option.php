<?php declare( strict_types=1 );

namespace CustomPaymentGateway\Form\Select;

use CustomPaymentGateway\Helper\Container;

class Option {
	public string $key;
	public string $value;

	/**
	 * @param string $key
	 * @param string $value
	 */
	public function __construct( string $key = '', string $value = '' ) {
		$this->key   = esc_attr( $key );
		$this->value = esc_html( $value );
	}
}
