<?php declare( strict_types=1 );

namespace CustomPaymentGateway\Form\Select;

class Options implements \IteratorAggregate {
	private array $options = [];

	public function add( Option $option ) {
		$this->options[] = $option;
	}

	public function getIterator(): \ArrayIterator {
		return new \ArrayIterator( $this->options );
	}
}
