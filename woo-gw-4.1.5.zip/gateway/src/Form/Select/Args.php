<?php declare( strict_types=1 );

namespace CustomPaymentGateway\Form\Select;

use CustomPaymentGateway\Form\Classes;

class Args extends \CustomPaymentGateway\Form\Args {
	public Options $options;
	/**
	 * @param string $placeholder
	 * @param Classes|null $classes
	 * @param Options|null $options
	 */
	public function __construct( string $placeholder = '', ?Classes $classes = null, ?Options $options = null ) {
		parent::__construct( $placeholder, $classes );
		$this->options = $options;
	}
}
