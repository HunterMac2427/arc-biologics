<?php

namespace CustomPaymentGateway\Form;

final class Checkbox extends FormElement {

	public function render() {
		$this->element();
	}

	protected function element() {
		?>
		<label for="<?php echo $this->id; ?>">
			<input
				type="hidden"
				name="<?php echo $this->id; ?>"
				id="<?php echo $this->id; ?>_hidden"
				value="no"
				<?php checked( $this->value, 'no' ); ?>
			>
			<input
				type="checkbox"
				name="<?php echo $this->id; ?>"
				id="<?php echo $this->id; ?>"
				value="yes"
				<?php
				if ( $this->args->classes->count() > 0 ) {
					echo 'class="' . $this->args->classes->get_classes() . '"';
				}
				?>
				<?php checked( $this->value, 'yes' ); ?>
			>
			<?php echo $this->description; ?>
		</label>
		<?php
	}
}
