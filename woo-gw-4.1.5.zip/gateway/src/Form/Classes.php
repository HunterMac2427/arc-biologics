<?php declare( strict_types=1 );

namespace CustomPaymentGateway\Form;

use CustomPaymentGateway\Helper\Container;

class Classes implements \IteratorAggregate {
	private array $classes = [];

	public function __construct() {
	}

	public function add( string $class ) {
		$this->classes[] = esc_attr( $class );
	}

	public function count() {
		return count( $this->classes );
	}

	public function get_classes(): string {
		return implode( ' ', $this->classes );
	}

	public function getIterator(): \ArrayIterator {
		return new \ArrayIterator( $this->classes );
	}
}
