<?php

namespace CustomPaymentGateway\Form;

final class Text extends FormElement {

	protected function element() {
		$this->args->classes->add( 'regular-text' );
		$this->args->classes->add( 'form-control' );

		$value       = ! empty( $this->value ) ? 'value="' . $this->value . '"' : '';
		$placeholder = ! empty( $this->args->placeholder ) ? 'placeholder="' . $this->args->placeholder . '"' : '';

		$html = <<<HTML
		<input
			type="text"
			name="{$this->id}"
			id="{$this->id}"
			{$value}
			{$placeholder}
			class="{$this->args->classes->get_classes()}"
		>
HTML;

		echo $html;
	}
}
