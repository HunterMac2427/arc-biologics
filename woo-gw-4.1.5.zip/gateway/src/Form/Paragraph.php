<?php

namespace CustomPaymentGateway\Form;

final class Paragraph extends FormElement {

	protected function element() {
		$this->value = html_entity_decode( $this->value );

		$html = <<<HTML
		<p
			name="{$this->id}"
			id="{$this->id}"
			class="{$this->args->classes->get_classes()}"
		>{$this->value}</p>
HTML;

		echo $html;
	}
}
