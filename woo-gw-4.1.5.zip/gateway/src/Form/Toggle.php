<?php

namespace CustomPaymentGateway\Form;

final class Toggle extends FormElement {

	public function render() {
		$this->element();
		if ( ! empty( $this->args->placeholder ) ) {
			echo '<p class="description">' . $this->args->placeholder . '</p>';
		}
	}

	protected function element() {
		$is_checked = ( $this->value === 'yes' ) ? 'checked="checked"' : '';
		echo <<<HTML
        <div class="form-check form-switch form-switch-lg">
            <input
                    type="checkbox"
                    name="{$this->id}"
                    id="{$this->id}"
                    role="switch"
                    value="yes"
                    class="form-check-input {$this->args->classes->get_classes()}"
                    {$is_checked}
            >
            <label class="form-check-label" for="{$this->id}">{$this->description}</label>
        </div>
HTML;
	}
}
