<?php

namespace CustomPaymentGateway\Form;

use CustomPaymentGateway\Helper\Container;

final class FileUpload extends FormElement {
	protected function element() {
		$class_attribute = $this->args->classes->count() > 0 ? 'class="' . $this->args->classes->get_classes() . '"' : '';
		echo <<<HTML
			<label class="title">Screenshot/Screen recording:</label>
			<div id="file-list"></div>
			<label class="upload-button">
				Upload file(s)
				<input type="file"
			       name="{$this->id}[]"
			       id="{$this->id}"
			       {$class_attribute}
			       multiple
				/>
			</label>
		HTML;
	}
}
