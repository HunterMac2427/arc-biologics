<?php

namespace CustomPaymentGateway\Form;

final class Textarea extends FormElement {

	protected function element() {
		$this->args->classes->add( 'large-text' );
		$placeholder = ! empty( $this->args->placeholder ) ? 'placeholder="' . $this->args->placeholder . '"' : '';
		$value       = ! empty( $this->value ) ? $this->value : '';

		echo <<<HTML
		<textarea
			type="textarea"
			rows="2"
			cols="20"
			name="{$this->id}"
			id="{$this->id}"
			{$placeholder}
			class="{$this->args->classes->get_classes()}"
		>{$value}</textarea>
		HTML;
	}
}
