<?php

namespace CustomPaymentGateway\Form;

use CustomPaymentGateway\Helper\Container;

final class Select extends FormElement {
	public function __construct( string $id, string $value, string $description = '', ?\CustomPaymentGateway\Form\Select\Args $args = null ) {
		parent::__construct( $id, $value, $description, $args );
		$this->args = $args;
	}

	protected function element() {
		$this->args->classes->add( 'form-select' );
		$class_attribute = '';
		if ( $this->args->classes->count() > 0 ) {
			$class_attribute = 'class="' . $this->args->classes->get_classes() . '"';
		}

		$options = '';
		if ( $this->args->options ) {
			foreach ( $this->args->options as $option ) {
				$options .= <<<HTML
					<option value="{$option->key}" {$this->isSelected($option->key)}>{$option->value}</option>
				HTML;
			}
		}

		$html = <<<HTML
		<select name="{$this->id}" id="{$this->id}" {$class_attribute}>
			{$options}
		</select>
		HTML;

		echo $html;
	}

	private function isSelected( $option_key ): string {
		return $this->value === $option_key ? 'selected' : '';
	}
}
