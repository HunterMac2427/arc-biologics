<?php
namespace CustomPaymentGateway\CheckoutBlocks;

use Automattic\WooCommerce\Blocks\Payments\Integrations\AbstractPaymentMethodType;
use CustomPaymentGateway\Helper\Constants;

final class WC_Card_Blocks extends AbstractPaymentMethodType {

	private $gateway;
	protected $name = 'custom_payment_gateway_card';


	public function initialize() {
		$this->settings = get_option( 'woocommerce_' . $this->name . '_settings', [] );
		$gateways       = WC()->payment_gateways->payment_gateways();
		$this->gateway  = $gateways[ $this->name ];
	}

	public function is_active() {
		return $this->get_setting( 'enabled' ) === 'yes';
	}

	public function get_payment_method_script_handles() {
		wp_register_script(
			'wc_custom_gateway_card_blocks_integration',
			plugins_url( 'frontend/src/js/checkout_blocks_card.js', plugin_dir_path( __DIR__ ) ),
			[
				'wc-blocks-registry',
				'wc-settings',
				'wp-element',
				'wp-html-entities',
				'wp-i18n',
			],
			Constants::PLUGIN_VERSION,
			true
		);
		wp_register_script(
			'wc_custom_gateway_card_ajax_handle_fee',
			plugins_url( 'frontend/src/js/fee_block.js', plugin_dir_path( __DIR__ ) ),
			[
				'wc-blocks-registry',
				'wc-settings',
				'wp-element',
				'wp-html-entities',
				'wp-i18n',
			],
			Constants::PLUGIN_VERSION,
			true
		);
		wp_register_script(
			'wc_custom_gateway_card_blocks_tokenization',
			plugins_url( 'frontend/src/js/tokenization.js', plugin_dir_path( __DIR__ ) ),
			[
				'wc-blocks-registry',
				'wc-settings',
				'wp-element',
				'wp-html-entities',
				'wp-i18n',
			],
			Constants::PLUGIN_VERSION,
			true
		);
		if ( function_exists( 'wp_set_script_translations' ) ) {
			wp_set_script_translations( 'wc_custom_gateway_card_blocks_integration' );
			wp_set_script_translations( 'wc_custom_gateway_card_ajax_handle_fee' );
			wp_set_script_translations( 'wc_custom_gateway_card_blocks_tokenization' );
		}

		return [ 'wc_custom_gateway_card_blocks_integration', 'wc_custom_gateway_card_ajax_handle_fee', 'wc_custom_gateway_card_blocks_tokenization' ];
	}

	public function get_payment_method_data() {
		return [
			'title'                    => $this->gateway->title,
			'description'              => $this->gateway->description,
			'supports'                 => $this->gateway->supports,
			'enableForShippingMethods' => [],
			'enableForVirtual'         => true,
		];
	}
}
