<?php
namespace CustomPaymentGateway\CheckoutBlocks;

use Automattic\WooCommerce\StoreApi\Schemas\V1\CartItemSchema;
use Automattic\WooCommerce\Utilities\FeaturesUtil;
use CustomPaymentGateway\Actions\FeeAction;
use CustomPaymentGateway\Helper\Constants;
use WC_Payment_Tokens;

class CheckoutBlockUpdateTotals {
	private FeeAction $fee_action;

	public function __construct( $fee_action ) {
		add_action( 'woocommerce_review_order_before_payment', [ $this, 'output_add_button' ] );
		add_filter( 'render_block_woocommerce/checkout-order-summary-block', [ $this, 'modify_order_summary_block' ] );

		add_action( 'wp_ajax_nopriv_update_totals', [ $this, 'handle_update_totals_ajax_action' ] );
		add_action( 'wp_ajax_update_totals', [ $this, 'handle_update_totals_ajax_action' ] );

		add_action( 'woocommerce_blocks_loaded', [ $this, 'register_store_api_callbacks' ] );

		add_action( 'wp_enqueue_scripts', [ $this, 'enqueue_update_totals_script' ] );

		$this->fee_action = $fee_action;
	}

	public function output_add_button() {
		$style = array(
			'margin: 0 auto 15px',
			'display: block',
			has_block( 'woocommerce/checkout' ) ? 'margin-top: 15px' : '',
		);

		wp_nonce_field( 'add-update-totals', '_wpnonce-update-totals' );
		?>
		<button id="update-totals" class="update-totals__button" style="<?php echo esc_attr( join( ';', $style ) ); ?>" type="button">
			<?php echo __( 'Update Totals', 'update-totals' ); ?>
		</button>
		<?php
	}

	public function modify_order_summary_block( $block_content ) {
		ob_start();
		$this->output_add_button();
		return $block_content . ob_get_clean();
	}

	public function update_totals_to_cart( $data = [] ) : bool {
		if ( $data['payment_id'] !== 'new' ) {
			$token = WC_Payment_Tokens::get( $data['payment_id'] );
			$type  = $token->get_gateway_id();
			if ( $type === 'custom_payment_gateway_ach' ) {
				$data['custom_payment_gateway_payment_method'] = 'ach';
			}
			if ( $type === 'custom_payment_gateway_card' ) {
				$data['custom_payment_gateway_payment_method'] = 'card';
			}
		}
		if ( $data['custom_payment_gateway_payment_method'] === 'card' && $data['custom_payment_gateway_card_number'] === '' && $data['stored_customer'] === false ) {
			$fee_value = 0;
		} else {
			$fee_value = $this->fee_action->calculate_fees_entrypoint( WC()->cart, true, $data );
		}

		add_action(
			'woocommerce_cart_calculate_fees',
			function() use ( $fee_value ) {
				WC()->session->set( 'checkout_block_used', true );
				$fees = WC()->session->get( 'checkout_block_fee', [] );
				if ( $fee_value && ! empty( $fees ) ) {
					foreach ( $fees as $fee ) {
						if ( $fee['amount'] !== 0.0 ) {
							WC()->cart->add_fee( $fee['title'], $fee['amount'], false, '' );
						}
					}
				} else {
					WC()->session->__unset( 'checkout_block_fee' );
				}
			},
			9999,
			1
		);
		return true;
	}

	public function handle_update_totals_ajax_action() {
		if ( wp_verify_nonce( $_POST['_wpnonce-update-totals'] ?? '' ) ) {
			wp_send_json_error( 'Invalid nonce', 400 );
		}

		if ( ! $this->update_totals_to_cart() ) {
			wp_send_json_error( null, 500 );
		}

		wp_send_json_success();
	}

	public function register_store_api_callbacks() {
		woocommerce_store_api_register_update_callback(
			[
				'namespace' => 'update_totals',
				'callback'  => function( $data ) {
					$this->update_totals_to_cart( $data );
				},
			]
		);

		woocommerce_store_api_register_endpoint_data(
			[
				'endpoint'      => CartItemSchema::IDENTIFIER,
				'namespace'     => 'update_totals',
				'data_callback' => function( $cart_item ) {
					return [
						'randomly_added' => ! empty( $cart_item['random-product'] ),
					];
				},
				'schema_type'   => ARRAY_A,
			]
		);
	}

	public function enqueue_update_totals_script() {
		if ( ! is_checkout() && ! has_block( 'woocommerce/checkout' ) ) {
			return;
		}

		$checkout_page_id = wc_get_page_id( 'checkout' );
		if ( $checkout_page_id && function_exists( 'has_block' ) ) {
			if ( ! has_block( 'woocommerce/checkout', $checkout_page_id ) ) {
				return;
			}
		}

		if ( is_plugin_active( 'flux-checkout/flux-checkout.php' ) ) {
			return;
		}

		wp_enqueue_script(
			'custom-update-totals',
			plugins_url( '/gateway/src/CheckoutBlocks/src/js/update-totals.js' ),
			[ 'jquery', 'wp-i18n', 'wc-blocks-checkout' ],
			'1.0',
			true
		);

		wp_localize_script(
			'custom-update-totals',
			'custom_payment_gateway_data',
			[
				'form_gateway_id' => Constants::FORM_GATEWAY_ID_FEE,
			]
		);

		wp_set_script_translations( 'custom-update-totals', 'update-totals', plugin_dir_path( __DIR__ ) . 'languages' );
	}
}
