/**
 * External dependencies
 */
import { registerCheckoutFilters } from '@woocommerce/blocks-checkout';
import { registerPaymentMethodExtensionCallbacks } from '@woocommerce/blocks-registry';
import { __, sprintf } from '@wordpress/i18n';

export const registerFilters = (pointsLabelPlural, discountRegex) => {
    registerCheckoutFilters('checkout-payment-extend', {
		itemName: (name) => {
			return `${name}`;
		},
	});

	registerPaymentMethodExtensionCallbacks('checkout-payment-extend', {
        cod: () => true,
	});
};
