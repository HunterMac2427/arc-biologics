jQuery(function($) {
    if (typeof wc !== 'undefined' && wc?.blocksCheckout) {
        $(document).on('click', '#update-totals', function() {
            const { extensionCartUpdate } = wc.blocksCheckout;

            $('.wc-block-components-order-summary__content').block({
                message: null,
                overlayCSS: { background: '#fff', opacity: 0.6 }
            });

            $(this).attr('disabled', true);

            const selected_saved = jQuery('input[name="radio-control-wc-payment-method-saved-tokens"]:checked').val();
            const card_number = $("#custom_payment_gateway_card_number").val().replace(/\s+/g, '');

            var payment_method = '';
            let checked = $('input[name="radio-control-wc-payment-method-options"]:checked').val();
            if (checked === 'custom_payment_gateway_ach') {
                payment_method = "ach";
            }
            if (checked === 'custom_payment_gateway_card') {
                payment_method = "card";
            }

            extensionCartUpdate({
                namespace: 'update_totals',
                data: {
                    reset: card_number !== "",
                    custom_payment_gateway_card_number: card_number,
                    custom_payment_gateway_payment_method: payment_method,
                    customPaymentGatewayID: custom_payment_gateway_data.form_gateway_id,
                    stored_customer: selected_saved !== undefined && selected_saved !== 'new',
                    payment_id: selected_saved ? selected_saved : 'new',
                }})
                .then(() => { $('.update-totals__button').hide(); })
                .finally(() => {
                    $('.wc-block-components-order-summary__content').unblock();
                    $('.update-totals__button').attr('disabled', false);
                    $(".wc-block-components-checkout-place-order-button").prop("disabled", false);
                });
        });

        const { registerCheckoutFilters } = wc.blocksCheckout;
        const { sprintf, __ } = wp.i18n;

        registerCheckoutFilters('update_totals', {
            itemName: function(defaultValue, extensions) {
                if (!extensions?.update_totals?.randomly_added) {
                    return defaultValue;
                }
                return sprintf(__('%s (Random)'), defaultValue);
            }
        });

        return;
    }
});