/*
 * An example component that will be rendered at the bottom of the sidebar in
 * the Cart and Checkout blocks.
 */
export const ExampleComponent = ({ data }) => {
	return (
		<div className="checkout-payment-extend-example-component"></div>
	);
};
