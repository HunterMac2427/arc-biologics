/**
 * External dependencies
 */
import { useEffect, useState } from '@wordpress/element';
import { CheckboxControl, ValidatedTextInput } from '@woocommerce/blocks-checkout';
import { useSelect, useDispatch } from '@wordpress/data';

const Block = ({children, checkoutExtensionData}) => {
    const {setExtensionData} = checkoutExtensionData;

    const [cardSave, setCardSave] = useState(false);
    const [cardNumber, setCardNumber] = useState("");
    const [cardCvc, setCardCvc] = useState("");
    let [cardExpiry, setCardExpiry] = useState("");
    let [oldExpiry, setOldExpiry] = useState("");

    const [achSave, setAchSave] = useState(false);
    let [routingNumber, setRoutingNumber] = useState("");
    let [accountNumber, setAccountNumber] = useState("");
    let [accountType, setAccountType] = useState("");
    let [accountSecCode, setAccountSecCode] = useState("");
    let [achCompany, setAchCompany] = useState("");

	const { setValidationErrors, clearValidationError } = useDispatch(
		'wc/store/validation'
	);

	useEffect(() => {
        setExtensionData('checkout-payment-extend', 'cardSave', cardSave);
        setExtensionData('checkout-payment-extend', 'achSave', achSave);

        if(jQuery('input[name="radio-control-wc-payment-method-options"]:checked').val() === "custom_payment_gateway_card"
            && (cardNumber !== "" || cardExpiry !== "" || cardCvc !== "")){
            setExtensionData('checkout-payment-extend', 'paymentType', 'card');
            setExtensionData('checkout-payment-extend', 'cardNumber', cardNumber);
            if (cardNumber === "") {
                setValidationErrors({
                    'checkout-payment-extend': {
                        message: 'Please fill credit card number',
                        hidden: false,
                        type: "card",
                    },
                });
                return;
            }

            if (cardExpiry === "") {
                setValidationErrors({
                    'checkout-payment-extend': {
                        message: 'Please fill credit card expiry date',
                        hidden: false,
                        type: "card",
                    },
                });
                return;
            }

            if(cardExpiry.length < 4){
                const pattern_month = /^(0[1-9]|1[0-2])/gm;
                if(cardExpiry.length === 2 && pattern_month.test(cardExpiry)){
                    if(oldExpiry.length !== 3){
                        setCardExpiry(cardExpiry + "/");
                        setOldExpiry(cardExpiry + "/");
                    }
                } else {
                    setOldExpiry(cardExpiry);
                    setValidationErrors({
                        'checkout-payment-extend': {
                            message: 'Please fill credit card expiry date with valid data',
                            hidden: false,
                            type: "card",
                        },
                    });
                    return;
                }
            } else{
                const pattern_full = /^(0[1-9]|1[0-2])\/?([0-9]{2}$)/gm;
                if (!pattern_full.test(cardExpiry)) {
                    setOldExpiry(cardExpiry);
                    setValidationErrors({
                        'checkout-payment-extend': {
                            message: 'Please fill credit card expiry date based on given pattern and use valid data',
                            hidden: false,
                            type: "card",
                        },
                    });
                    return;
                } else {
                    setOldExpiry(cardExpiry);
                    setExtensionData('checkout-payment-extend', 'cardExpiry', cardExpiry);
                }
            }

            setExtensionData('checkout-payment-extend', 'cardCvc', cardCvc);
            if (cardCvc === "") {
                setValidationErrors({
                    'checkout-payment-extend': {
                        message: 'Please fill credit card cvc or cvv',
                        hidden: false,
                        type: "card",
                    },
                });
                return;
            }
        }

        if(jQuery('input[name="radio-control-wc-payment-method-options"]:checked').val() === "custom_payment_gateway_ach"
            && (routingNumber !== "" || accountNumber !== "")){
            setExtensionData('checkout-payment-extend', 'paymentType', 'ach');
            setExtensionData('checkout-payment-extend', 'routingNumber', routingNumber);
            if (routingNumber === "") {
                setValidationErrors({
                    'checkout-payment-extend': {
                        message: 'Please fill routing number',
                        hidden: false,
                        type: "ach",
                    },
                });
                return;
            }

            setExtensionData('checkout-payment-extend', 'accountNumber', accountNumber);
            if (accountNumber === "") {
                setValidationErrors({
                    'checkout-payment-extend': {
                        message: 'Please fill account number',
                        hidden: false,
                        type: "ach",
                    },
                });
                return;
            }


            accountType = document.querySelector("#accountType").value;
            setExtensionData('checkout-payment-extend', 'accountType', accountType);
            if (accountType !== "checking" && accountType !== "savings") {
                setValidationErrors({
                    'checkout-payment-extend': {
                        message: 'Please normal account type',
                        hidden: false,
                        type: "ach",
                    },
                });
                return;
            }

            accountSecCode = document.querySelector("#accountSecCode").value;
            setExtensionData('checkout-payment-extend', 'accountSecCode', accountSecCode);
            if (accountSecCode !== "ppd" && accountSecCode !== "ccd" && accountSecCode !== "web") {
                setValidationErrors({
                    'checkout-payment-extend': {
                        message: 'Please normal account type',
                        hidden: false,
                        type: "ach",
                    },
                });
                return;
            }

            setExtensionData('checkout-payment-extend', 'achCompany', achCompany);
            if (accountSecCode === "ccd" && achCompany === "") {
                setValidationErrors({
                    'checkout-payment-extend': {
                        message: 'Please fill company field',
                        hidden: false,
                        type: "ach",
                    },
                });
                return;
            }
        }
        clearValidationError('checkout-payment-extend');

	}, [clearValidationError, setValidationErrors, cardSave, cardNumber, cardCvc, cardExpiry, achSave, accountNumber, routingNumber, accountType, accountSecCode, achCompany, setExtensionData]);

	const { validationError } = useSelect((select) => {
		const store = select('wc/store/validation');
		return {
			validationError: store.getValidationError(
				'checkout-payment-extend'
			),
		};
	});

    const handleCardNumberChange = (value) => {
        const formattedValue = value.replace(/\D/g, '').replace(/(.{4})/g, '$1 ').trim();
        setCardNumber(formattedValue);
    };

    const handleCardExpiryChange = (value) => {
        if (value.length === 2 && !cardExpiry.includes('/')) {
            value += '/';
        } else if (value.length === 3 && value[2] !== '/') {
            value = value.slice(0, 2) + '/' + value.slice(2);
        }
        setCardExpiry(value);
    };

	return (
        <div id="payment-extend-block">
            <div id="payment-extend-card">
                <h4>Credit Card informations</h4>
                {validationError?.hidden === false && validationError?.type === "card" && (
                    <div className="payment-extend-error">
                        <span role="img" aria-label="Warning emoji">
                            ⚠️
                        </span>
                        {validationError?.message}
                    </div>
                )}

                <ValidatedTextInput
                    id="custom_payment_gateway_card_number"
                    type="text"
                    data-fp-track="pan"
                    label={'Credit Card Number(•••• •••• •••• ••••)'}
                    value={cardNumber}
                    onChange={handleCardNumberChange}
                    maxLength={19}
                />

                <ValidatedTextInput
                    type="text"
                    data-fp-track="expiry"
                    label={'Credit Card Expiry Date(MM / YY)'}
                    value={cardExpiry}
                    onChange={handleCardExpiryChange}
                    maxLength={5}
                />

                <ValidatedTextInput
                    type="number"
                    data-fp-track="cvv"
                    label={'Credit Card CVC'}
                    value={cardCvc}
                    onChange={setCardCvc}
                />

                <CheckboxControl
                    checked={cardSave}
                    onChange={setCardSave}
                    id="card-save-checkbox"
                >
                    Save to account
                </CheckboxControl>
            </div>

            <div id="payment-extend-ach">
                <h4>ACH informations</h4>
                {validationError?.hidden === false && validationError?.type === "ach" && (
                    <div className="payment-extend-error">
                        <span role="img" aria-label="Warning emoji">
                            ⚠️
                        </span>
                        {validationError?.message}
                    </div>
                )}

                <ValidatedTextInput
                    type="number"
                    label={'Routing number'}
                    value={routingNumber}
                    onChange={setRoutingNumber}
                />

                <ValidatedTextInput
                    type="number"
                    label={'Account number'}
                    value={accountNumber}
                    onChange={setAccountNumber}
                />

                <label htmlFor="accountType">Account type</label>
                <select name="accountType" id="accountType" onChange={setAccountType}
                        className="wc-enhanced-select">
                    <option value="checking" selected>Checking</option>
                    <option value="savings">Saving</option>
                </select>

                <label htmlFor="accountSecCode">Account SEC Code</label>
                <select name="accountSecCode" id="accountSecCode" onChange={setAccountSecCode}
                        className="wc-enhanced-select">
                    <option value="ppd" selected>Personal</option>
                    <option value="ccd">Corporate</option>
                    <option value="web">Web</option>
                </select>


                <CheckboxControl
                    checked={achSave}
                    onChange={setAchSave}
                    id="ach-save-checkbox"
                >
                    Save to account
                </CheckboxControl>

                <p id="achCompanyBlock">
                    <ValidatedTextInput
                        type="text"
                        label={'Company for ACH Payment'}
                        value={achCompany}
                        onChange={setAchCompany}
                    />
                </p>
            </div>
        </div>
    );
};

export default Block;
