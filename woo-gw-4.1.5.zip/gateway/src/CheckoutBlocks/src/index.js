import './js/index';
import './js/checkout-payment-extend-block';
