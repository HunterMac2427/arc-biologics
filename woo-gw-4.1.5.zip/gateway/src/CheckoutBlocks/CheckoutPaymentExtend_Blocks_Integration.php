<?php
namespace CustomPaymentGateway\CheckoutBlocks;

use Automattic\WooCommerce\Blocks\Integrations\IntegrationInterface;

define( 'CHECKOUTPAYMENTEXTEND_VERSION', '0.1.0' );

/**
 * Class for integrating with WooCommerce Blocks
 */
class CheckoutPaymentExtend_Blocks_Integration implements IntegrationInterface {

	/**
	 * The name of the integration.
	 *
	 * @return string
	 */
	public function get_name() {
		return 'checkout-payment-extend';
	}

	/**
	 * When called invokes any initialization/setup for the integration.
	 */
	public function initialize() {
		$this->register_payment_block_frontend_scripts();
		$this->register_payment_block_editor_scripts();
		$this->register_payment_block_editor_styles();
		$this->register_main_integration();
	}

	/**
	 * Registers the main JS file required to add filters and Slot/Fills.
	 */
	public function register_main_integration() {
		$script_path = '/build/index.js';
		$style_path  = '/build/style-index.css';

		$script_url = plugins_url( $script_path, __FILE__ );
		$style_url  = plugins_url( $style_path, __FILE__ );

		$script_asset_path = dirname( __FILE__ ) . '/build/index.asset.php';
		$script_asset      = file_exists( $script_asset_path )
			? require $script_asset_path
			: array(
				'dependencies' => array(),
				'version'      => $this->get_file_version( $script_path ),
			);

		wp_enqueue_style(
			'checkout-payment-extend-blocks-integration',
			$style_url,
			[],
			$this->get_file_version( $style_path )
		);

		wp_register_script(
			'checkout-payment-extend-blocks-integration',
			$script_url,
			$script_asset['dependencies'],
			$script_asset['version'],
			true
		);
		wp_set_script_translations(
			'checkout-payment-extend-blocks-integration',
			'checkout-payment-extend',
			dirname( __FILE__ ) . '/languages'
		);
	}

	/**
	 * Returns an array of script handles to enqueue in the frontend context.
	 *
	 * @return string[]
	 */
	public function get_script_handles() {
		return array( 'checkout-payment-extend-blocks-integration', 'checkout-payment-extend-checkout-payment-extend-block-frontend' );
	}

	/**
	 * Returns an array of script handles to enqueue in the editor context.
	 *
	 * @return string[]
	 */
	public function get_editor_script_handles() {
		return array( 'checkout-payment-extend-blocks-integration', 'checkout-payment-extend-checkout-payment-extend-block-editor' );
	}

	/**
	 * An array of key, value pairs of data made available to the block on the client side.
	 *
	 * @return array
	 */
	public function get_script_data() {
		$data = array(
			'checkout-payment-extend-active' => true,
		);

		return $data;
	}

	public function register_payment_block_editor_styles() {
		$style_path = '/build/style-checkout-payment-extend-checkout-payment-extend-block.css';

		$style_url = plugins_url( $style_path, __FILE__ );
		wp_enqueue_style(
			'checkout-payment-extend-checkout-payment-extend-block',
			$style_url,
			[],
			$this->get_file_version( $style_path )
		);
	}

	public function register_payment_block_editor_scripts() {
		$script_path       = '/src/js/checkout-payment-extend-block/block.js';
		$script_url        = plugins_url( $script_path, __FILE__ );
		$script_asset_path = dirname( __FILE__ ) . '/build/checkout-payment-extend-checkout-payment-extend-block.asset.php';
		$script_asset      = file_exists( $script_asset_path )
			? require $script_asset_path
			: array(
				'dependencies' => array(),
				'version'      => $this->get_file_version( $script_asset_path ),
			);

		wp_register_script(
			'checkout-payment-extend-checkout-payment-extend-block-editor',
			$script_url,
			$script_asset['dependencies'],
			$script_asset['version'],
			true
		);

		wp_set_script_translations(
			'checkout-payment-extend-payment-block-editor', // script handle
			'checkout-payment-extend', // text domain
			dirname( __FILE__ ) . '/languages'
		);
	}

	public function register_payment_block_frontend_scripts() {
		$script_path       = '/build/checkout-payment-extend-checkout-payment-extend-block-frontend.js';
		$script_url        = plugins_url( $script_path, __FILE__ );
		$script_asset_path = dirname( __FILE__ ) . '/build/payment-block-frontend.asset.php';
		$script_asset      = file_exists( $script_asset_path )
			? require $script_asset_path
			: array(
				'dependencies' => array(),
				'version'      => $this->get_file_version( $script_asset_path ),
			);

		wp_register_script(
			'checkout-payment-extend-checkout-payment-extend-block-frontend',
			$script_url,
			$script_asset['dependencies'],
			$script_asset['version'],
			true
		);
		wp_set_script_translations(
			'checkout-payment-extend-checkout-payment-extend-block-frontend', // script handle
			'checkout-payment-extend', // text domain
			dirname( __FILE__ ) . '/languages'
		);
	}

	/**
	 * Get the file modified time as a cache buster if we're in dev mode.
	 *
	 * @param string $file Local path to the file.
	 * @return string The cache buster value to use for the given file.
	 */
	protected function get_file_version( $file ) {
		if ( defined( 'SCRIPT_DEBUG' ) && SCRIPT_DEBUG && file_exists( $file ) ) {
			return filemtime( $file );
		}
		return CHECKOUTPAYMENTEXTEND_VERSION;
	}
}
