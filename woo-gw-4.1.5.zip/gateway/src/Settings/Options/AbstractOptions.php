<?php declare( strict_types=1 );

namespace CustomPaymentGateway\Settings\Options;

use CustomPaymentGateway\Form\Select\Option;
use CustomPaymentGateway\Form\Select\Options;
use CustomPaymentGateway\Helper\Container;
use CustomPaymentGateway\Settings\Form\FormFields;
use CustomPaymentGateway\Settings\Form\SettingsForm;
use Throwable;

abstract class AbstractOptions {
	protected Container $c;
	protected array $defaults;

	public function __construct( Container $c ) {
		$this->c        = $c;
		$this->defaults = \get_object_vars( $this );
		$this->set_options_from_db();
	}

	public function get_defaults(): array {
		return $this->defaults;
	}

	public function get_options_from_db() {
		return get_option( $this->get_options_id(), $this->defaults );
	}

	public function update_options_in_db( array $options ): bool {
		return update_option( $this->get_options_id(), $options );
	}

	public function set_options_from_db() {
		$option_keys = array_keys( $this->defaults );
		$options     = $this->get_options_from_db();
		foreach ( $option_keys as $option_key ) {
			if ( isset( $options[ $option_key ] ) ) {
				$this->$option_key = $options[ $option_key ];
			}
		}
	}

	abstract public function get_options_id(): string;

	abstract protected function get_settings_form_fields(): FormFields;

	abstract protected function get_settings_form_title(): string;

	abstract protected function get_settings_form_header(): string;

	public function create_settings_form(): SettingsForm {
		return new SettingsForm(
			$this->get_settings_form_fields(),
			$this->get_defaults(),
			$this->get_options_id(),
			$this->get_settings_form_title(),
			$this->get_settings_form_header(),
		);
	}

	public static function is_valid_api_url_and_api_key( $c, $api_url, $api_key ): bool {
		if ( empty( $api_url ) || empty( $api_key ) || strpos( $api_key, 'api_' ) !== 0 || strlen( $api_key ) < 5 ) {
			return false;
		}
		try {
			$get_user = $c->gateway->user->get();
			if ( $get_user->status !== 'success' ) {
				return false;
			}
			return true;
		} catch ( Throwable $e ) {
			// Catches JsonMapper_Exception and GatewayException (the documented SDK
			// failures) but also InvalidArgumentException (raised by JsonMapper when the
			// API responds with a non-JSON body — e.g. an HTML 404 page caused by a
			// trailing-slash on api_url, a misconfigured WAF, or maintenance mode).
			// Without this we fatal during pre_update_option and lock the merchant out
			// of the settings page; with it the gateway falls back to the
			// "invalid_api_connection" admin notice.
			self::log_probe_failure( $c, 'is_valid_api_url_and_api_key', $e );
			return false;
		}
	}

	public static function get_merchant_id( $c ) {
		try {
			$merchant = $c->gateway->user->merchant();
			if ( $merchant->status !== 'success' ) {
				return false;
			}
			return $merchant->data->id;
		} catch ( Throwable $e ) {
			self::log_probe_failure( $c, 'get_merchant_id', $e );
			return false;
		}
	}

	public static function get_processors( $c, $merchant_id ): array {
		try {
			$response = $c->gateway->merchant->get_processors( $merchant_id );
			if ( $response->status !== 'success' || ! is_array( $response->data ) ) {
				return [];
			}
			return $response->data;
		} catch ( Throwable $e ) {
			self::log_probe_failure( $c, 'get_processors', $e );
			return [];
		}
	}

	private static function log_probe_failure( $c, string $method, Throwable $e ): void {
		if ( ! isset( $c->logger ) ) {
			return;
		}
		try {
			$c->logger->error(
				sprintf(
					'AbstractOptions::%s caught %s while probing the gateway API: %s',
					$method,
					get_class( $e ),
					$e->getMessage()
				)
			);
		} catch ( Throwable $ignored ) { // phpcs:ignore Generic.CodeAnalysis.EmptyStatement.DetectedCatch
			// Logging must never escalate into a second fatal during settings save.
		}
	}

	public static function set_ach_processor_default( $c, $options, $create_field = false ) {
		$ps_options              = new Options();
		$merchant_id             = self::get_merchant_id( $c );
		$processors              = self::get_processors( $c, $merchant_id );
		$available_processor_ids = array_column( $processors, 'id' );
		$ach_processor_exists    = in_array( $options->ach_processor, $available_processor_ids );
		foreach ( $processors as $processor ) {
			if ( $processor->supported_payment_methods !== null && in_array( 'ach', $processor->supported_payment_methods ) ) {
				if ( $create_field ) {
					$ps_options->add( new Option( $processor->id, $processor->name ) );
				}
				if ( ( $options->ach_processor === '' || ! $ach_processor_exists ) && $processor->default_ach ) {
					$options->ach_processor = $processor->id;
				}
			}
		}
		return $ps_options;
	}
}
