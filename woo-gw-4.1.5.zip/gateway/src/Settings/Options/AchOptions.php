<?php declare( strict_types=1 );

namespace CustomPaymentGateway\Settings\Options;

use CustomPaymentGateway\Form\Args;
use CustomPaymentGateway\Form\Select;
use CustomPaymentGateway\Form\Select\Options;
use CustomPaymentGateway\Form\Text;
use CustomPaymentGateway\Form\Textarea;
use CustomPaymentGateway\Form\Toggle;
use CustomPaymentGateway\Helper\Constants;
use CustomPaymentGateway\Settings\Form\FormField;
use CustomPaymentGateway\Settings\Form\FormFields;
use JsonMapper_Exception;
use PaymentGateway\Exceptions\GatewayException;
use PaymentGateway\Gateway;

class AchOptions extends AbstractOptions {
	public string $title            = 'ACH Payment';
	public string $description      = 'Please remit payment to Store Name upon pickup or delivery.';
	public string $transaction_type = 'sale';
	public string $save_method      = 'no';
	public string $ach_processor    = '';

	/**
	 * @throws JsonMapper_Exception
	 * @throws GatewayException
	 */
	public function get_settings_form_fields(): FormFields {
		$form_fields = new FormFields();

		$form_fields->add(
			( new FormField(
				__( 'ACH Title:' ),
				new Text(
					'title',
					$this->title,
					__( 'Payment method title that the customer will see during checkout.' )
				)
			) )->add_separator()
		);

		$form_fields->add(
			( new FormField(
				__( 'ACH Description:' ),
				new Textarea(
					'description',
					$this->description,
					__( 'Payment method description that the customer will see during checkout.' )
				)
			) )->add_separator()
		);

		$tt_options = new Select\Options();
		$tt_options->add( new Select\Option( 'sale', __( 'Sale(Authorize and Capture)' ) ) );
		$form_fields->add(
			( new FormField(
				__( 'Transaction Type:' ),
				new Select(
					'transaction_type',
					$this->transaction_type,
					__( 'Select the transaction type for this method.' ),
					new Select\Args( '', null, $tt_options )
				)
			) )->add_separator()
		);

		$form_fields->add(
			( new FormField(
				'Save Payment Method:',
				new Toggle(
					'save_method',
					$this->save_method,
					__( 'Enable Saving Payment Method' ),
					new Args( __( 'If enabled, users will be able to pay with a saved payment method during checkout. Payment method details are saved on payment gateway servers, not on your store. This must be enabled for subscriptions.' ) )
				)
			) )->add_separator()
		);

		$api_url          = $_POST['custom_payment_gateway']['api_url'] ?? $this->c->gw_options->api_url;
		$api_key          = $_POST['custom_payment_gateway']['api_key'] ?? $this->c->gw_options->api_key;
		Gateway::$api_url = $api_url;
		Gateway::$api_key = $api_key;
		$ps_options       = new Options();
		if ( $this->is_valid_api_url_and_api_key( $this->c, $api_url, $api_key ) ) {
			$ps_options = self::set_ach_processor_default( $this->c, $this, true );
		}

		$form_fields->add(
			new FormField(
				__( 'Active ACH Processor:' ),
				new Select(
					'ach_processor',
					$this->ach_processor,
					__( 'Active ACH Processor used for processing transactions.' ),
					new Select\Args( '', null, $ps_options )
				)
			)
		);

		return $form_fields;
	}

	protected function get_settings_form_title(): string {
		return __( 'Configure eCheck payment method' );
	}

	protected function get_settings_form_header(): string {
		return '<p id="' . Constants::ACH_METHOD_ID . '">' . __( 'Configure the eCheck payment method.' ) . '</p>';
	}

	public function get_options_id(): string {
		return Constants::ACH_METHOD_ID;
	}
}
