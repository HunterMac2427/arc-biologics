<?php declare( strict_types=1 );

namespace CustomPaymentGateway\Settings\Options;

use CustomPaymentGateway\Form\Args;
use CustomPaymentGateway\Form\Classes;
use CustomPaymentGateway\Form\Paragraph;
use CustomPaymentGateway\Form\Password;
use CustomPaymentGateway\Form\Select;
use CustomPaymentGateway\Form\Text;
use CustomPaymentGateway\Form\Textarea;
use CustomPaymentGateway\Form\Toggle;
use CustomPaymentGateway\Helper\Constants;
use CustomPaymentGateway\Settings\Form\FormField;
use CustomPaymentGateway\Settings\Form\FormFields;
use PaymentGateway\Gateway;
use WC_Log_Handler_File;

class GatewayOptions extends AbstractOptions {
	public string $api_key                       = '';
	public string $api_url                       = '';
	public string $debug                         = 'no';
	public string $cash_discount                 = 'no';
	public string $service_fee                   = 'no';
	public string $service_fee_title             = 'Service Fee';
	public string $discount_amount_title         = 'Discount Amount';
	public string $fee_calculation_with_shipping = 'no';
	public string $fingerprint_public_key        = '';

	protected function get_settings_form_fields(): FormFields {
		$form_fields = new FormFields();
		$form_fields->add(
			new FormField(
				__( 'API Key:' ),
				new Password(
					'api_key',
					$this->api_key,
					__( 'Your Gateway API Key; this is needed in order to take payment.' ),
					new Args( __( 'Add new API key' ) )
				)
			)
		);
		$form_fields->add(
			( new FormField(
				__( 'URL:' ),
				new Text(
					'api_url',
					$this->api_url,
					__( 'URL of the payment gateway without trailing slashes and path components. (e.g. no "/" or "/api" at the end)' ),
					new Args( __( 'https://www.example.com' ) )
				)
			) )->add_separator()
		);

		$form_fields->add(
			( new FormField(
				__( 'Fingerprint Public Key:' ),
				new Textarea(
					'fingerprint_public_key',
					$this->fingerprint_public_key,
					__( 'Public key used by checkout fingerprint encryption. Paste the full PEM block.' ),
					new Args( __( "-----BEGIN PUBLIC KEY-----\n...\n-----END PUBLIC KEY-----" ) )
				)
			) )->add_separator()
		);

		$form_fields->add(
			( new FormField(
				'Fee calculation:',
				new Toggle(
					'fee_calculation_with_shipping',
					$this->fee_calculation_with_shipping,
					'Fee calculation with shipping',
					new Args(
						__( 'Include shipping amount in fee calculation' )
					)
				)
			) )->add_separator()
		);

		$fee_text = 'Please note, from now on all fee programs and payment adjustments are inherited from your Gateway settings.<br>' .
					'If you wish to change your current configuration, please reach out to support.<br><br>';

		$api_url          = $_POST['custom_payment_gateway']['api_url'] ?? $this->c->gw_options->api_url;
		$api_key          = $_POST['custom_payment_gateway']['api_key'] ?? $this->c->gw_options->api_key;
		Gateway::$api_url = $api_url;
		Gateway::$api_key = $api_key;
		if ( $this->is_valid_api_url_and_api_key( $this->c, $api_url, $api_key ) ) {
			$merchant                = $this->c->gateway->user->merchant()->data;
			$surcharge_active        = $merchant->permissions->allow_surcharge || $merchant->flags->surcharge_enabled ?? false;
			$cash_discount_active    = $merchant->flags->cash_discount_enabled ?? false;
			$processors              = $this->c->gateway->merchant->get_processors( $merchant->id );
			$card_payment_adj        = '';
			$card_payment_adj_amount = 0;
			$ach_payment_adj         = '';
			$ach_payment_adj_amount  = 0;

			$available_processor_ids = array_column( $processors->data, 'id' );
			$card_processor_exists   = in_array( $this->c->cc_options->card_processor, $available_processor_ids );
			$ach_processor_exists    = in_array( $this->c->ach_options->ach_processor, $available_processor_ids );
			$cc_settings             = get_option( 'custom_payment_gateway_card', [] );
			$ach_settings            = get_option( 'custom_payment_gateway_ach', [] );

			foreach ( $processors->data as $processor ) {
				if ( $card_processor_exists && $this->c->cc_options->card_processor === $processor->id ) {
					$card_payment_adj        = $this->get_fee_value_as_text( $processor->payment_adj_type, $processor->payment_adj_val );
					$card_payment_adj_amount = $processor->payment_adj_val;
				} elseif ( ( $this->c->cc_options->card_processor === '' || ! $card_processor_exists ) && $processor->default_card ) {
					$this->c->cc_options->card_processor = $processor->id;
					$cc_settings['card_processor']       = $this->c->cc_options->card_processor;
					update_option( 'custom_payment_gateway_card', $cc_settings );
					$card_payment_adj        = $this->get_fee_value_as_text( $processor->payment_adj_type, $processor->payment_adj_val );
					$card_payment_adj_amount = $processor->payment_adj_val;
				}
				if ( $ach_processor_exists && $this->c->ach_options->ach_processor === $processor->id ) {
					$ach_payment_adj        = $this->get_fee_value_as_text( $processor->payment_adj_type, $processor->payment_adj_val );
					$ach_payment_adj_amount = $processor->payment_adj_val;
				} elseif ( ( $this->c->ach_options->ach_processor === '' || ! $ach_processor_exists ) && $processor->default_ach ) {
					$this->c->ach_options->ach_processor = $processor->id;
					$ach_settings['ach_processor']       = $this->c->ach_options->ach_processor;
					update_option( 'custom_payment_gateway_ach', $ach_settings );
					$ach_payment_adj        = $this->get_fee_value_as_text( $processor->payment_adj_type, $processor->payment_adj_val );
					$ach_payment_adj_amount = $processor->payment_adj_val;
				}
			}

			$items = '';
			if ( $surcharge_active ) {
				$items .= "<li>Card surcharge (current configuration is {$card_payment_adj})</li>";
			} elseif ( $card_payment_adj_amount > 0 ) {
				$items .= "<li>Card service fee (current configuration is {$card_payment_adj})</li>";
			}

			if ( $ach_payment_adj_amount > 0 ) {
				$items .= "<li>ACH service fee (current configuration is {$ach_payment_adj})</li>";
			}

			if ( $cash_discount_active ) {
				$items .= "<li>ACH cash discount (current configuration is {$ach_payment_adj})</li>";
			}

			if ( ! empty( $items ) ) {
				$fee_text .= 'Your active fee programs:';
				$fee_text .= "<ul class='fee_program_list'>{$items}</ul>";
			} else {
				$fee_text .= "You currently don't have any active fee programs.";
			}
		} else {
			$fee_text .= "You currently don't have any active fee programs.";
		}

		$fee_text_class = new Classes();
		$fee_text_class->add( 'fee_text_block' );

		$form_fields->add(
			( new FormField(
				__( 'Fee Programs:' ),
				new Paragraph(
					'fee_text',
					$fee_text,
					'',
					new Args( '', $fee_text_class )
				)
			) )->add_separator()
		);

		$form_fields->add(
			new FormField(
				'Logging:',
				new Toggle(
					'debug',
					$this->debug,
					'Allow debug log',
					new Args(
						__( 'This will allow us to log requests, inside ' ) . WC_Log_Handler_File::get_log_file_path( Constants::PLUGIN_ID )
					)
				)
			)
		);

		return $form_fields;
	}

	protected function get_fee_value_as_text( string $type, int $amount ): string {
		if ( $type === 'percentage' ) {
			return number_format( $amount / 1000, 3, '.', '' ) . '%';
		} elseif ( $type === 'flat' ) {
			return '$' . number_format( $amount / 100, 2, '.', '' );
		} else {
			return '$0';
		}
	}

	protected function get_settings_form_title(): string {
		return __( 'Gateway' );
	}

	protected function get_settings_form_header(): string {
		return '<p>' . __( 'General settings.' ) . '</p>';
	}

	public function get_options_id(): string {
		return Constants::PLUGIN_ID;
	}
}
