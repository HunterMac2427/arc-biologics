<?php declare( strict_types=1 );

namespace CustomPaymentGateway\Settings\Options;

use CustomPaymentGateway\Form\Args;
use CustomPaymentGateway\Form\Paragraph;
use CustomPaymentGateway\Form\Select;
use CustomPaymentGateway\Form\Text;
use CustomPaymentGateway\Form\Textarea;
use CustomPaymentGateway\Form\Toggle;
use CustomPaymentGateway\Helper\Constants;
use CustomPaymentGateway\Settings\Form\FormField;
use CustomPaymentGateway\Settings\Form\FormFields;
use JsonMapper_Exception;
use PaymentGateway\Exceptions\GatewayException;
use PaymentGateway\Gateway;

class CcOptions extends AbstractOptions {
	public string $title            = 'Credit Card Payment';
	public string $description      = 'Please remit payment to Store Name upon pickup or delivery.';
	public string $transaction_type = 'sale';
	public string $save_method      = 'no';
	public string $card_processor   = '';

	/**
	 * @throws JsonMapper_Exception
	 * @throws GatewayException
	 */
	public function get_settings_form_fields(): FormFields {
		$form_fields = new FormFields();
		$form_fields->add(
			( new FormField(
				__( 'Credit Card Title:' ),
				new Text(
					'title',
					$this->title,
					__( 'Payment method title that the customer will see during checkout.' ),
					new Args( __( 'Credit Card Payment' ) )
				)
			) )->add_separator()
		);

		$form_fields->add(
			( new FormField(
				__( 'Credit Card Description:' ),
				new Textarea(
					'description',
					$this->description,
					__( 'Payment method description that the customer will see during checkout.' ),
					new Args( '' )
				)
			) )->add_separator()
		);

		$tt_options = new Select\Options();
		$tt_options->add( new Select\Option( 'sale', __( 'Sale(Authorize and Capture)' ) ) );
		$tt_options->add( new Select\Option( 'authorize', __( 'Authorize Only' ) ) );
		$form_fields->add(
			( new FormField(
				__( 'Transaction Type:' ),
				new Select(
					'transaction_type',
					$this->transaction_type,
					__( 'Select the transaction type for credit card payments.' ),
					new Select\Args( '', null, $tt_options )
				)
			) )->add_separator()
		);

		$form_fields->add(
			( new FormField(
				'',
				new Toggle(
					'save_method',
					$this->save_method,
					__( 'Allow Saving Payment Method' ),
					new Args( __( 'If enabled, users will be able to pay with a saved payment method during checkout. Payment method details are saved on payment gateway servers, not on your store. This must be enabled for subscriptions.' ) )
				)
			) )->add_separator()
		);

		$form_fields->add(
			( new FormField(
				'Save Payment Method:',
				new Toggle(
					'save_method',
					$this->save_method,
					__( 'Enable Saving Payment Method' ),
					new Args( __( 'If enabled, users will be able to pay with a saved payment method during checkout. Payment method details are saved on payment gateway servers, not on your store. This must be enabled for subscriptions.' ) )
				)
			) )->add_separator()
		);

		$ps_options       = new Select\Options();
		$api_url          = $_POST['custom_payment_gateway']['api_url'] ?? $this->c->gw_options->api_url;
		$api_key          = $_POST['custom_payment_gateway']['api_key'] ?? $this->c->gw_options->api_key;
		Gateway::$api_url = $api_url;
		Gateway::$api_key = $api_key;
		if ( $this->is_valid_api_url_and_api_key( $this->c, $api_url, $api_key ) ) {
			$merchant                = $this->c->gateway->user->merchant();
			$processors              = $this->c->gateway->merchant->get_processors( $merchant->data->id );
			$available_processor_ids = array_column( $processors->data, 'id' );
			$card_processor_exists   = in_array( $this->card_processor, $available_processor_ids );
			foreach ( $processors->data as $processor ) {
				if ( $processor->supported_payment_methods !== null && in_array( 'card', $processor->supported_payment_methods ) ) {
					$ps_options->add( new Select\Option( $processor->id, $processor->name ) );
					if ( ( $this->card_processor === '' || ! $card_processor_exists ) && $processor->default_card ) {
						$this->card_processor = $processor->id;
					}
				}
			}
		}

		$form_fields->add(
			new FormField(
				__( 'Active Card Processor:' ),
				new Select(
					'card_processor',
					$this->card_processor,
					__( 'Active Card Processor used for processing transactions.' ),
					new Select\Args( '', null, $ps_options )
				)
			)
		);

		return $form_fields;
	}

	protected function get_settings_form_title(): string {
		return __( 'Configure Credit Card payment method' );
	}

	protected function get_settings_form_header(): string {
		return '<p id="' . Constants::CC_METHOD_ID . '">' . __( 'Configure the Credit Card payment method.' ) . '</p>';
	}

	public function get_options_id(): string {
		return Constants::CC_METHOD_ID;
	}
}
