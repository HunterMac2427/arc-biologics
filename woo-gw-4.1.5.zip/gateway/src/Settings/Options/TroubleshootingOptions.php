<?php declare( strict_types=1 );

namespace CustomPaymentGateway\Settings\Options;

use CustomPaymentGateway\Form\Args;
use CustomPaymentGateway\Form\FileUpload;
use CustomPaymentGateway\Form\Textarea;
use CustomPaymentGateway\Form\Toggle;
use CustomPaymentGateway\Helper\Constants;
use CustomPaymentGateway\Settings\Form\FormField;
use CustomPaymentGateway\Settings\Form\FormFields;

class TroubleshootingOptions extends AbstractOptions {
	public string $description          = '';
	public string $screenshoots         = '';
	public string $send_critical_logs   = 'yes';
	public string $send_additional_logs = 'yes';

	protected function get_settings_form_fields(): FormFields {
		$form_fields = new FormFields();
		$form_fields->add(
			( new FormField(
				__( 'Bug/Feedback description*:' ),
				new Textarea(
					'description',
					$this->description,
					__( 'These pieces of information are crucial for us to understand what happened. The more detail you can give, the quicker the solution will be.' ),
					new Args( __( 'Please write down the incident in details. Every single step or action that you can remember.' ) )
				)
			) )->add_separator()
		);

		$form_fields->add(
			( new FormField(
				'Screenshot/Screen recording*:',
				new FileUpload(
					'attachments',
					$this->screenshoots,
					__( 'Upload your screenshots or screen recordings here.' ),
					new Args( '', null, false )
				)
			) )->add_separator()
		);

		$form_fields->add(
			( new FormField(
				'',
				new Toggle(
					'send_critical_logs',
					$this->send_critical_logs,
					__( 'Allow Sending Payment Gateway and Critical Logs' ),
					new Args( __( 'If enabled, our developers will have much better chance at figuring out the root of the problem.' ) )
				)
			) )->add_separator()
		);

		$form_fields->add(
			new FormField(
				'',
				new Toggle(
					'send_additional_logs',
					$this->send_additional_logs,
					__( 'Allow Sending Additional Information' ),
					new Args( __( 'If enabled, our developers will see your WordPress, Woocommerce versions, the list of versions of plugins etc. This is crucial to understanding the cause of the problem, because sometimes installed plugins or theme changes can cause malfunctions.' ) )
				)
			)
		);

		return $form_fields;
	}

	protected function get_settings_form_title(): string {
		return __( 'Gateway' );
	}

	protected function get_settings_form_header(): string {
		return '<p id="' . Constants::ACH_METHOD_ID . '">' . __( 'Troubleshooting' ) . '</p>';
	}

	public function get_options_id(): string {
		return Constants::TROUBLESHOOTING_METHOD_ID;
	}
}
