<?php declare( strict_types=1 );

namespace CustomPaymentGateway\Settings\Form;

use CustomPaymentGateway\Form\FormElement;

class FormField {
	public string $title;
	public FormElement $element;
	public string $layout;
	public bool $separator = false;

	public function __construct( string $title, FormElement $element ) {
		$this->title   = $title;
		$this->element = $element;
		$this->layout  = '';
	}

	public function set_layout( string $layout ): self {
		$this->layout = $layout;
		return $this;
	}

	public function add_separator(): self {
		$this->separator = true;
		return $this;
	}
}
