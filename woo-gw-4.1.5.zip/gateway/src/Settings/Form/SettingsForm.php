<?php declare( strict_types=1 );

namespace CustomPaymentGateway\Settings\Form;

use CustomPaymentGateway\Helper\Constants;

class SettingsForm {

	private FormFields $fields;
	private string $options_id;
	private string $title;
	private string $section_header;
	/**
	 * @var callable|null
	 */
	private $sanitize;
	private array $defaults;

	public function __construct( FormFields $fields, array $defaults, string $options_id, string $title, string $section_header = '', ?callable $sanitize = null ) {
		$this->options_id     = $options_id;
		$this->title          = $title;
		$this->fields         = $fields;
		$this->section_header = $section_header;
		$this->sanitize       = $sanitize;
		$this->defaults       = $defaults;
	}

	public function register_settings(): void {
		$setting_args = array(
			'type'    => 'array',
			'default' => $this->defaults,
		);
		if ( $this->sanitize ) {
			$setting_args['sanitize_callback'] = $this->sanitize;
		}
		register_setting(
			Constants::PLUGIN_ID,
			$this->options_id,
			$setting_args
		);
		add_settings_section(
			$this->options_id . '_section',
			$this->title,
			array( $this, 'echo_section_header' ),
			Constants::PLUGIN_ID
		);

		/** @var FormField $field */
		foreach ( $this->fields as $field ) {
			$option_key         = $field->element->id;
			$field->element->id = $this->options_id . '[' . $option_key . ']';
			$label_for          = $field->element->id;
			if ( $field->element->args->label_for === false ) {
				$label_for = '';
			}
			add_settings_field(
				$this->options_id . '_' . $option_key,
				$field->title,
				array( $field->element, 'render' ),
				Constants::PLUGIN_ID,
				$this->options_id . '_section',
				array(
					'label_for' => $label_for,
					'layout'    => $field->layout,
					'separator' => $field->separator,
				)
			);
		}
	}

	public function echo_section_header() {
		echo $this->section_header;
	}
}
