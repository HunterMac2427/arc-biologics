<?php declare( strict_types=1 );

namespace CustomPaymentGateway\Settings\Form;

class FormFields implements \IteratorAggregate {
	/**
	 * @var FormField[]
	 */
	private array $fields = [];

	public function add( FormField $field ) {
		$this->fields[] = $field;
	}

	public function getIterator(): \ArrayIterator {
		return new \ArrayIterator( $this->fields );
	}
}
