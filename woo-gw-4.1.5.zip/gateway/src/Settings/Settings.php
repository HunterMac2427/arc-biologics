<?php
namespace CustomPaymentGateway\Settings;

use CustomPaymentGateway\Actions\ApiTestAction;
use CustomPaymentGateway\Cron\SubscriptionCron;
use CustomPaymentGateway\Helper\Constants;
use CustomPaymentGateway\Helper\Container;
use CustomPaymentGateway\Helper\WoocommerceSubscriptions;
use CustomPaymentGateway\Install;
use CustomPaymentGateway\Settings\Options\AbstractOptions;
use Exception;
use JsonMapper_Exception;
use PaymentGateway\Exceptions\GatewayException;
use PaymentGateway\Gateway;
use PaymentGateway\Support;
use PaymentGateway\Types\Support\Request;
use WC_Payment_Tokens;

final class Settings {

	public Container $c;

	/**
	 * @var AbstractOptions[]
	 */
	private array $options;

	private Install $install;

	public function __construct( Container $c, array $options ) {
		$this->c       = $c;
		$this->install = new Install( $this->c );
		$this->options = $options;

		add_filter( 'pre_update_option_custom_payment_gateway', [ $this, 'check_gateway_settings_update_standard' ], 10, 2 );
		add_filter( 'pre_update_option_custom_payment_gateway_card', [ $this, 'check_gateway_settings_update_card' ], 10, 2 );
		add_filter( 'pre_update_option_custom_payment_gateway_ach', [ $this, 'check_gateway_settings_update_ach' ], 10, 2 );
		add_filter( 'pre_update_option_custom_payment_gateway_troubleshooting', [ $this, 'send_troubleshooting' ], 10, 2 );
	}

	public function init() {
		if ( ! class_exists( 'WC_Settings_API' ) ) {
			return;
		}
		foreach ( $this->options as $option ) {
			$form = $option->create_settings_form();
			$form->register_settings();
		}
	}

	public function check_gateway_settings_update_standard( $settings, $old_settings ) {
		if ( ( $settings === [] || $settings === null || $settings === '' ) && ( $old_settings !== null && $old_settings !== '' ) || isset( $settings['description'] ) ) {
			return $old_settings;
		}
		// Normalize api_url before any comparison or SDK call. A trailing slash on the
		// stored value collides with the SDK's leading-slash endpoints (e.g. '/api/merchant')
		// and produces '//api/...' which most edges 404 with HTML, which then triggers an
		// uncaught InvalidArgumentException out of JsonMapper during pre_update_option.
		// We also trim whitespace to defuse copy/paste with stray newlines.
		if ( isset( $settings['api_url'] ) && is_string( $settings['api_url'] ) ) {
			$settings['api_url'] = untrailingslashit( trim( $settings['api_url'] ) );
		}
		if ( $settings['api_key'] !== $old_settings['api_key'] || $settings['api_url'] !== $old_settings['api_url'] ) {
			Gateway::$api_url = $old_settings['api_url'];
			Gateway::$api_key = $old_settings['api_key'];
			$old_merchant_id  = AbstractOptions::get_merchant_id( $this->c );
			Gateway::$api_url = $settings['api_url'];
			Gateway::$api_key = $settings['api_key'];
			if ( AbstractOptions::is_valid_api_url_and_api_key( $this->c, $settings['api_url'], $settings['api_key'] ) ) {
				$merchant_id = AbstractOptions::get_merchant_id( $this->c );
				if ( $old_merchant_id !== $merchant_id ) {
					$processors = AbstractOptions::get_processors( $this->c, $merchant_id );
					foreach ( $processors as $processor ) {
						if ( $processor->supported_payment_methods !== null && in_array( 'card', $processor->supported_payment_methods ) ) {
							if ( $processor->default_card ) {
								$this->c->cc_options->card_processor = $processor->id;
							}
						}
					}
					AbstractOptions::set_ach_processor_default( $this->c, $this->c->ach_options );
					$user_id = get_current_user_id();
					if ( $user_id !== 0 ) {
						$tokens = WC_Payment_Tokens::get_customer_tokens( $user_id );
						foreach ( $tokens as $token ) {
							$GLOBALS['api_key_changed_delete'] = true;
							WC_Payment_Tokens::delete( $token->get_id() );
							$GLOBALS['api_key_changed_delete'] = false;
						}
					}
				}
			} else {
				$settings['invalid_api_connection'] = true;
			}
		}
		if ( isset( $_POST['submit_sync'] ) && isset( $_POST[ Constants::UPDATE_SUBSCRIPTIONS_NONCE ] ) && wp_verify_nonce( $_POST[ Constants::UPDATE_SUBSCRIPTIONS_NONCE ], Constants::UPDATE_SUBSCRIPTIONS_HOOK ) ) {
			$sub_cron = new SubscriptionCron( $this->c );
			$sub_cron->cron_job();
			$settings['submit_sync'] = true;
		}
		if ( isset( $_POST['submit_database'] ) && isset( $_POST[ Constants::UPDATES_NONCE ] ) && wp_verify_nonce( $_POST[ Constants::UPDATES_NONCE ], Constants::UPDATES_HOOK ) ) {
			$this->install->run_updates();
			$settings['submit_database'] = true;
		}
		return $settings;
	}

	public function check_gateway_settings_update_card( $settings, $old_settings ) {
		if ( ( $settings === [] || $settings === null || $settings === '' ) && ( $old_settings !== null && $old_settings !== [] && $old_settings !== '' ) ) {
			return $old_settings;
		}
		if ( $settings['description'] ) {
			$settings['description'] = $this->clean_string( $settings['description'] );
		}
		return $settings;
	}

	public function check_gateway_settings_update_ach( $settings, $old_settings ) {
		if ( ( $settings === [] || $settings === null || $settings === '' ) && ( $old_settings !== null && $old_settings !== [] && $old_settings !== '' ) ) {
			return $old_settings;
		}
		if ( $settings['description'] ) {
			$settings['description'] = $this->clean_string( $settings['description'] );
		}
		return $settings;
	}

	public function clean_string( string $text ): string {
		return trim( $text, " \t" );
	}

	/**
	 * @throws JsonMapper_Exception
	 * @throws GatewayException|Exception
	 */
	public function send_troubleshooting( $values ): array {
		$old_values = [];
		if ( isset( $_POST['submit_troubleshooting'] ) ) {
			if ( $values['description'] === '' || $_FILES['custom_payment_gateway_troubleshooting']['tmp_name']['attachments'][0] === '' ) {
				$values['error'] = 'Please fill description field and attach log files, screenshots, screen recordings!';
				return $values;
			}
			$req   = new Request();
			$files = array();
			foreach ( $_FILES['custom_payment_gateway_troubleshooting']['tmp_name']['attachments']  as $attachment ) {
				$files[] = $attachment;
			}
			$req->data = [
				'description' => $values['description'],
			];
			if ( isset( $values['send_critical_logs'] ) && $values['send_critical_logs'] === 'yes' ) {
				$gateway_log_file = self::get_latest_log_file( 'custom_payment_gateway' );
				if ( $gateway_log_file ) {
					$files[] = $gateway_log_file;
				}
				$fatal_error_log_file = self::get_latest_log_file( 'fatal-errors' );
				if ( $fatal_error_log_file ) {
					$files[] = $fatal_error_log_file;
				}
			}
			if ( isset( $values['send_additional_logs'] ) && $values['send_additional_logs'] === 'yes' ) {
				$versions              = ApiTestAction::logPluginVersions( $this->c );
				$req->data['versions'] = $versions;
			}
			$req->files = $files;
			$support    = new Support();
			try {
				$res = $support->support_woocommerce( $req );
				if ( $res->status === 'success' ) {
					$old_values['sent'] = true;
				}
			} catch ( GatewayException | JsonMapper_Exception | Exception $e ) {
				$old_values['error'] = self::throw_exception( $e->getCode(), $e->getMessage(), false );
				$this->c->logger->error( $e->getMessage() );
			}
		} else {
			unset( $old_values['sent'] );
			unset( $old_values['error'] );
		}
		return $old_values;
	}

	public static function get_latest_log_file( string $file_name ) {
		$upload_dir  = wp_upload_dir();
		$wc_logs_dir = trailingslashit( $upload_dir['basedir'] ) . 'wc-logs/';

		$log_files = glob( $wc_logs_dir . '*.log' );

		$latest_file = null;
		$latest_time = 0;

		foreach ( $log_files as $file ) {
			if ( strpos( basename( $file ), $file_name ) !== false ) {
				$file_time = filemtime( $file );
				if ( $file_time > $latest_time ) {
					$latest_time = $file_time;
					$latest_file = $file;
				}
			}
		}
		return $latest_file;
	}

	public function register_menu() {
		add_submenu_page(
			'woocommerce',
			__( 'Custom Payment Gateway Settings' ),
			__( 'Custom Payment Gateway' ),
			'manage_options',
			Constants::PLUGIN_ID,
			[ $this, 'settings_page' ]
		);
	}

	private function print_settings_fields( $page, $section ) {
		global $wp_settings_fields;

		if ( ! isset( $wp_settings_fields[ $page ][ $section ] ) ) {
			return;
		}

		foreach ( (array) $wp_settings_fields[ $page ][ $section ] as $field ) {
			$class = empty( $field['args']['layout'] ) ? 'col-12' : esc_attr( $field['args']['layout'] );
			echo sprintf( '<div class="%s">', $class );

			if ( ! empty( $field['args']['label_for'] ) && ! empty( $field['title'] ) ) {
				echo '<label for="' . esc_attr( $field['args']['label_for'] ) . '" class="title">' . $field['title'] . '</label>';
			}

			call_user_func( $field['callback'], $field['args'] );

			if ( $field['args']['separator'] ) {
				echo '<hr>';
			}

			echo '</div>';
		}
	}


	public function settings_page() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( __( 'You do not have sufficient permission to access this page.' ) );
		}
		if ( isset( $_GET['settings-updated'] ) ) {
			$gateway_options = get_option( 'custom_payment_gateway' );
			$options         = get_option( 'custom_payment_gateway_troubleshooting' );
			if ( isset( $options['sent'] ) ) {
				unset( $options['sent'] );
				update_option( 'custom_payment_gateway', $options );
				echo '<div class="notice notice-success"><p>' . __( 'Bug report was sent.' ) . '</p></div>';
			} elseif ( isset( $options['error'] ) ) {
				$error_message = $options['error'];
				unset( $options['error'] );
				update_option( 'custom_payment_gateway', $options );
				echo '<div class="notice notice-error"><p>' . $error_message . '</p></div>';
			} elseif ( isset( $gateway_options['submit_sync'] ) ) {
				unset( $gateway_options['submit_sync'] );
				update_option( 'custom_payment_gateway', $gateway_options );
				echo '<div class="notice notice-success"><p>' . __( 'Subscriptions synchronized.' ) . '</p></div>';
			} elseif ( isset( $gateway_options['submit_database'] ) ) {
				unset( $gateway_options['submit_database'] );
				update_option( 'custom_payment_gateway', $gateway_options );
				echo '<div class="notice notice-success"><p>' . __( 'Database updates successful.' ) . '</p></div>';
			} elseif ( isset( $gateway_options['invalid_api_connection'] ) ) {
				unset( $gateway_options['invalid_api_connection'] );
				update_option( 'custom_payment_gateway', $gateway_options );
				echo '<div class="notice notice-error"><p>' . __( 'API connection could not be established. Please provide a valid API key and url.' ) . '</p></div>';
			} else {
				echo '<div class="notice notice-success"><p>' . __( 'Settings updated.' ) . '</p></div>';
			}
		}
		//Echo '<div class="notice notice-warning"><p>'. 'Please be aware that transactions which haven't been settled yet can only be fully voided. Partial void is not possible.' . '</p></div>';
		?>
		<div class="wrap">
			<div class="container-fluid">
				<h1><?php echo esc_html( get_admin_page_title() ); ?></h1>
				<div class="row">
					<div class="col-lg-2">
						<nav class="navbar navbar-expand-lg navbar-custom">
							<div class="container">
								<button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
									<span class="navbar-toggler-icon"></span>
								</button>
								<div class="collapse navbar-collapse" id="navbarNav">
									<ul class="nav nav-pills flex-column">
										<li class="nav-item">
											<a class="nav-link" data-bs-toggle="pill" href="#general-settings">General Settings</a>
										</li>
										<li class="nav-item">
											<a class="nav-link" data-bs-toggle="pill" href="#credit-card-configuration">Credit Card Configuration</a>
										</li>
										<li class="nav-item">
											<a class="nav-link" data-bs-toggle="pill" href="#ach-configuration">ACH Configuration</a>
										</li>
										<li class="nav-item">
											<a class="nav-link" data-bs-toggle="pill" href="#sync-update">Sync/Update</a>
										</li>
										<li class="nav-item">
											<a class="nav-link" data-bs-toggle="pill" href="#troubleshooting">Troubleshooting</a>
										</li>
									</ul>
								</div>
							</div>
						</nav>
					</div>
					<div class="col-lg-10">
						<form id="custom_payment_gateway_form" action="options.php" method="post" enctype="multipart/form-data" class="tab-content">
							<div class="tab-pane fade show active" id="general-settings" role="tabpanel">
								<div class="container py-4">
									<div class="form-fields p-3">
										<input type="hidden" name="action" value="process_form">
										<?php
										settings_fields( Constants::PLUGIN_ID );
										$this->print_settings_fields( Constants::PLUGIN_ID, 'custom_payment_gateway_section' );
										?>
									</div>
									<div class="d-flex justify-content-end mt-2">
										<?php echo sprintf( '<button type="button" class="btn btn-outline-primary me-2" id="%s">%s</button>', ApiTestAction::AJAX_HANDLE . '_button', __( 'Test API connection' ) ); ?>
										<?php echo sprintf( '<input type="submit" name="submit_general" id="submit_general" class="btn btn-primary" value="%s">', __( 'Save All Changes' ) ); ?>
									</div>
								</div>
							</div>

							<div class="tab-pane fade" id="credit-card-configuration" role="tabpanel">
								<div class="container py-4">
									<div class="form-fields p-3">
										<?php
										settings_fields( Constants::PLUGIN_ID );
										$this->print_settings_fields( Constants::PLUGIN_ID, 'custom_payment_gateway_card_section' );
										?>
									</div>
									<div class="d-flex justify-content-end mt-2">
										<?php echo sprintf( '<input type="submit" name="submit_card" id="submit_card" class="btn btn-primary" value="%s">', __( 'Save All Changes' ) ); ?>
									</div>
								</div>
							</div>

							<div class="tab-pane fade" id="ach-configuration" role="tabpanel">
								<div class="container py-4">
									<div class="form-fields p-3">
										<?php
										settings_fields( Constants::PLUGIN_ID );
										$this->print_settings_fields( Constants::PLUGIN_ID, 'custom_payment_gateway_ach_section' );
										?>
									</div>
									<div class="d-flex justify-content-end mt-2">
										<?php echo sprintf( '<input type="submit" name="submit_ach" id="submit_ach" class="btn btn-primary" value="%s">', __( 'Save All Changes' ) ); ?>
									</div>
								</div>
							</div>

							<div class="tab-pane fade" id="sync-update" role="tabpanel">
								<div class="container py-4">
									<div class="form-fields p-3">
										<?php if ( WoocommerceSubscriptions::plugin_available() ) { ?>
											<h6>Subscriptions:</h6>
											<?php wp_nonce_field( Constants::UPDATE_SUBSCRIPTIONS_HOOK, Constants::UPDATE_SUBSCRIPTIONS_NONCE ); ?>
											<div class="d-grid gap-2 d-md-block">
												<?php echo sprintf( '<input type="submit" name="submit_sync" id="submit_sync" class="btn btn-outline-primary" value="%s">', __( 'Sync Subscriptions' ) ); ?>
											</div>
											<p class="description"><?php echo __( 'Click this button to manually synchronize the subscriptions in the GW. Subscriptions are automatically synchronized every day at 3:00 AM.' ); ?></p>
											<hr>
										<?php } ?>
										<h6>Database Updates:</h6>
										<?php wp_nonce_field( Constants::UPDATES_HOOK, Constants::UPDATES_NONCE ); ?>
										<div class="d-grid gap-2 d-md-block">
											<?php echo sprintf( '<input type="submit" name="submit_database" id="submit_database" class="btn btn-outline-primary" value="%s" %s>', __( 'Run database updates' ), empty( $this->install->get_runnable_updates() ) ? 'disabled' : '' ); ?>
										</div>
										<p class="description"><?php echo __( 'This button becomes active when the updated plugin has available database updates.' ); ?></p>
									</div>
								</div>
							</div>

							<div class="tab-pane fade" id="troubleshooting" role="tabpanel">
								<div class="container py-4">
									<div class="form-fields p-3">
										<?php
										settings_fields( Constants::PLUGIN_ID );
										$this->print_settings_fields( Constants::PLUGIN_ID, 'custom_payment_gateway_troubleshooting_section' );
										?>
									</div>
									<div class="d-flex justify-content-end mt-2">
										<?php echo sprintf( '<input type="submit" name="submit_troubleshooting" id="submit_troubleshooting" class="btn btn-primary" value="%s">', __( 'Send report' ) ); ?>
									</div>
								</div>
							</div>
						</form>
					</div>
				</div>
			</div>
		</div>
		<?php
	}

	/**
	 * @param      $code
	 * @param      $message
	 * @param bool $throw
	 *
	 * @return string
	 * @throws Exception
	 */
	public static function throw_exception( $code, $message, bool $throw = true ): string {
		if ( $code === 400 ) {
			$message       = explode( '}],', $message );
			$message       = explode( '}', $message[1] );
			$res           = json_decode( '{' . $message[0] . '}' );
			$error_message = 'Gateway error. Error message is: ' . $res->msg;
		} elseif ( $code === 0 ) {
			$error_message = 'Gateway error. Error message is: ' . $message;
		} else {
			$error_message = 'Gateway error. Please contact the site administrator.';
		}
		if ( $throw === true ) {
			throw new Exception( $error_message );
		} else {
			return $error_message;
		}
	}
}
