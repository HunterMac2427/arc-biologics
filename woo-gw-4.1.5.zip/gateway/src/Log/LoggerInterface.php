<?php declare(strict_types = 1);

namespace CustomPaymentGateway\Log;

/**
 * Interface LoggerInterface
 */
interface LoggerInterface {
	/**
	 * Set the debug flag
	 *
	 * @param bool $debug State of the debug
	 */
	public function set_debug( bool $debug): void;

	/**
	 * Perform an info log
	 *
	 * @param string $msg The message of the action
	 */
	public function info( string $msg): void;

	/**
	 * Perform a warning log. Unlike info() this fires regardless of the
	 * debug flag because warnings are diagnostic signals we want visible
	 * in production logs without forcing customers to flip debug on.
	 *
	 * @param string $msg The message of the action
	 */
	public function warning( string $msg): void;

	/**
	 * Perform an error log
	 *
	 * @param string $msg The message of the action
	 */
	public function error( string $msg): void;
}
