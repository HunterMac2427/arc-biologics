<?php


namespace CustomPaymentGateway\Helper;

interface HttpInterface {
	public function get( ?string $key = null);

	public function post( ?string $key = null);

	public function server( ?string $key = null);
}
