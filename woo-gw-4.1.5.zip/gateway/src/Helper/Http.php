<?php

namespace CustomPaymentGateway\Helper;

final class Http implements HttpInterface {

	public array $get    = [];
	public array $post   = [];
	public array $server = [];

	/**
	 * Http constructor.
	 */
	public function __construct( array $get, array $post, array $server ) {
		$this->get    = $get;
		$this->post   = $post;
		$this->server = $server;
	}

	public static function createFromGlobals(): self {
		return new self( $_GET, $_POST, $_SERVER );
	}

	public function get( $key = null ) {
		return $this->retrieve( $this->get, $key );
	}

	public function post( $key = null ) {
		return $this->retrieve( $this->post, $key );
	}

	public function server( $key = null ) {
		return $this->retrieve( $this->server, $key );
	}

	/**
	 * @param $str
	 *
	 * @return string
	 */
	private function sanitize( $str ): string {
		return sanitize_text_field( wp_unslash( $str ) );
	}

	/**
	 * @param array       $global
	 * @param string|null $key
	 *
	 * @return array|string|string[]|null
	 */
	private function retrieve( array $global, string $key = null ) {
		if ( $key ) {
			return isset( $global[ $key ] ) && $global[ $key ] ? $this->sanitize( $global[ $key ] ) : null;
		}

		return array_map(
			function ( $item ) {
				return $item ? $this->sanitize( $item ) : null;
			},
			$global
		);
	}
}
