<?php

namespace CustomPaymentGateway\Helper;

use CustomPaymentGateway\Log\LoggerInterface;
use CustomPaymentGateway\Settings\Options;
use PaymentGateway\Gateway;

class Container {
	public LoggerInterface $logger;

	public MetaFields $meta;

	public Gateway $gateway;
	public Options\GatewayOptions $gw_options;
	public Options\CcOptions $cc_options;
	public Options\AchOptions $ach_options;
	public Options\TroubleshootingOptions $troubleshooting_options;
	public Http $http;

	public function __construct() {
		$this->meta = new MetaFields();
		$this->http = Http::createFromGlobals();

		$this->cc_options              = new Options\CcOptions( $this );
		$this->ach_options             = new Options\AchOptions( $this );
		$this->gw_options              = new Options\GatewayOptions( $this );
		$this->troubleshooting_options = new Options\TroubleshootingOptions( $this );

		// New SDK
		$this->gateway = new Gateway( $this->gw_options->api_key, $this->gw_options->api_url );
	}
}
