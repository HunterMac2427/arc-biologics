<?php declare( strict_types=1 );

namespace CustomPaymentGateway\Helper;

// @@TODO: Move this to SDK?
// @@TODO: string keys should be defined in SDK as constants

use Automattic\WooCommerce\Utilities\NumberUtil;

final class Formatter {
	/**
	 * Remove useless parts of the card like whitespaces
	 *
	 * @param string $cc_number Credit card number
	 */
	public static function format_credit_card_number( string $cc_number ): string {
		return preg_replace(
			'/(?<=\d)\s+(?=\d)/',
			'',
			trim( $cc_number )
		);
	}

	/**
	 * Return first six characters of a card number
	 *
	 * @param string $cc_number
	 *
	 * @return string
	 */
	public static function format_cc_bin( string $cc_number ): string {
		return substr( self::format_credit_card_number( $cc_number ), 0, 6 );
	}

	/**
	 * Format the amount
	 *
	 * @param string|float $amount Amount to be formatted
	 */
	public static function format_amount( $amount ): int {
		return (int) NumberUtil::round( \wc_add_number_precision( floatval( $amount ) ) );
	}

	/**
	 * Format the percentage
	 *
	 * @param string|float $percentage Percentage to be formatted
	 */
	public static function format_percentage( $percentage ): int {
		return intval( str_replace( '.', '', number_format( floatval( $percentage ), 3, '.', '' ) ) );
	}

	/**
	 * Denormalize a normalized amount
	 *
	 * @param $amount
	 *
	 * @return float
	 */
	public static function denormalize_amount( $amount ): float {
		$str_amount    = strval( $amount );
		$cents         = substr( $str_amount, - 2 );
		$dollars       = substr( $str_amount, 0, - 2 );
		$cents_decimal = floatval( $cents ) / 100;

		return floatval( $dollars ) + $cents_decimal;
	}

	/**
	 * Format the expiry date
	 *
	 * @param string $date Date to be formatted
	 */
	public static function format_expiry_date( string $date ): string {
		// @@TODO Should be universal with more cases
		$date = str_replace(
			' ',
			'',
			trim( $date )
		);

		return $date;
	}

	/**
	 * Format the surcharge from the given values
	 *
	 * @param string $amount    The total amount, leave empty for flat rates, otherwise a percentage is calculated
	 * @param string $surcharge The surcharge amount
	 * @param string $type      'flat' or 'percentage'
	 */
	public static function format_surcharge( string $amount, string $surcharge, string $type ): float {
		$value = 0;
		switch ( $type ) {
			case 'flat':
				$value = floatval( $surcharge );
				break;
			case 'percentage':
				$value = floatval( $amount ) / 100 * floatval( $surcharge );
				break;
		}

		return $value;
	}

	/**
	 * Generate UUID
	 *
	 * @return string
	 * */
	public static function gen_uuid(): string {
		return sprintf(
			'%04x%04x-%04x-%04x-%04x-%04x%04x%04x',
			wp_rand( 0, 0xffff ),
			wp_rand( 0, 0xffff ),
			wp_rand( 0, 0xffff ),
			wp_rand( 0, 0x0fff ) | 0x4000,
			wp_rand( 0, 0x3fff ) | 0x8000,
			wp_rand( 0, 0xffff ),
			wp_rand( 0, 0xffff ),
			wp_rand( 0, 0xffff )
		);
	}

	/**
	 * @param int $id
	 * @param int $length
	 *
	 * @return string
	 */
	public static function format_numeric_id_to_string( int $id, $length = 17 ) {
		return str_pad( (string) $id, $length, '0', STR_PAD_LEFT );
	}

	/**
	 * @param $headers
	 * @param string $log_msg
	 *
	 * @return string
	 */
	public static function correlation_id_to_log( $headers, string $log_msg = '' ) {
		if ( isset( $headers ) ) {
			foreach ( $headers as $h ) {
				if ( strtolower( $h->key ) === 'x-correlation-id' ) {
					$log_msg .= ' CORRELATION ID: ' . $h->value;
					break;
				}
			}
		}
		return $log_msg;
	}
}
