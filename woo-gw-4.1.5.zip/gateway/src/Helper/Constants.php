<?php

namespace CustomPaymentGateway\Helper;

class Constants {
	public const PLUGIN_ID      = 'custom_payment_gateway';
	public const PLUGIN_VERSION = '4.1.5';
	public const DB_VERSION_KEY = 'custom_payment_gateway_db_version';

	// Meta fields
	public const META_PLAN_ID         = 'custom_payment_gateway_plan_id';
	public const META_SUBSCRIPTION_ID = 'custom_payment_gateway_subscription_id';
	public const META_CUSTOMER_ID     = 'custom_payment_gateway_customer_id';

	// Hooks
	public const SUBSCRIPTION_CRON_HOOK    = 'custom_payment_gateway_subscriptions_cron_hook';
	public const UPDATE_SUBSCRIPTIONS_HOOK = 'custom_payment_gateway_update_subscriptions';
	public const UPDATES_HOOK              = 'custom_payment_gateway_updates';

	// Re-entrancy guard shared by the daily subscription cron and the manual "Sync
	// Subscriptions" button so they cannot run concurrently and create duplicate renewals.
	public const SUBSCRIPTION_CRON_LOCK = 'custom_payment_gateway_subscription_cron_lock';

	// Nonces
	public const UPDATE_SUBSCRIPTIONS_NONCE = 'custom_payment_gateway_update_subscriptions_nonce';
	public const UPDATES_NONCE              = 'custom_payment_gateway_updates_nonce';

	// Gateway configs
	public const GATEWAY_CONFIG_KEY_API_KEY               = 'api_key';
	public const GATEWAY_CONFIG_KEY_API_URL               = 'api_url';
	public const GATEWAY_CONFIG_KEY_DEBUG                 = 'debug';
	public const GATEWAY_CONFIG_KEY_CASH_DISCOUNT         = 'cash_discount';
	public const GATEWAY_CONFIG_KEY_SERVICE_FEE           = 'service_fee';
	public const GATEWAY_CONFIG_KEY_SERVICE_FEE_TITLE     = 'service_fee_title';
	public const GATEWAY_CONFIG_KEY_DISCOUNT_AMOUNT_TITLE = 'discount_amount_title';

	// Payment Method config
	public const PM_CONFIG_KEY_TITLE            = 'title';
	public const PM_CONFIG_KEY_DESCRIPTION      = 'description';
	public const PM_CONFIG_KEY_TRANSACTION_TYPE = 'transaction_type';
	public const PM_CONFIG_KEY_SAVE_METHOD      = 'save_method';

	// Card Configs
	public const CARD_CONFIG_KEY_SURCHARGE       = 'surcharge';
	public const CARD_CONFIG_KEY_SURCHARGE_TYPE  = 'surcharge_type';
	public const CARD_CONFIG_KEY_SURCHARGE_TITLE = 'surcharge_title';

	public const PAYMENT_ADJUSTMENT_TYPE_FIELD  = 'payment_adjustment_type_field';
	public const PAYMENT_ADJUSTMENT_VALUE_FIELD = 'payment_adjustment_value_field';
	public const REQUESTED_AMOUNT_FIELD         = 'requested_amount_field';

	// CC
	public const CC_METHOD_ID           = 'custom_payment_gateway_card';
	public const CC_PAYMENT_METHOD_NAME = 'card';
	public const FORM_CC_ID             = 'custom_payment_gateway_card_form';
	public const FORM_CC_NUMBER_ID      = 'custom_payment_gateway_card_number';
	public const FORM_CC_EXPIRY_ID      = 'custom_payment_gateway_card_expiry';
	public const FORM_CC_CVC_ID         = 'custom_payment_gateway_card_cvc';

	// ACH
	public const ACH_METHOD_ID                = 'custom_payment_gateway_ach';
	public const ACH_PAYMENT_METHOD_NAME      = 'ach';
	public const FORM_ACH_ID                  = 'custom_payment_gateway_ach_form';
	public const FORM_ACH_ROUTING_NUMBER_ID   = 'custom_payment_gateway_ach_routing_number';
	public const FORM_ACH_ACCOUNT_NUMBER_ID   = 'custom_payment_gateway_ach_account_number';
	public const FORM_ACH_ACCOUNT_SEC_CODE_ID = 'custom_payment_gateway_ach_sec_code';
	public const FORM_ACH_ACCOUNT_TYPE_ID     = 'custom_payment_gateway_ach_account_type';
	public const FORM_ACH_COMPANY             = 'custom_payment_gateway_ach_company';

	public const FORM_PAYMENT_METHOD_ID = 'custom_payment_gateway_payment_method';
	public const FORM_GATEWAY_ID        = 'customPaymentGatewayID';

	// PA means Payment Adjustment
	public const PA_TYPE_SESSION  = 'custom_payment_gateway_payment_adjustment_type';
	public const PA_VALUE_SESSION = 'custom_payment_gateway_payment_adjustment_value';

	public const REQUESTED_AMOUNT_SESSION = 'custom_payment_gateway_requested_amount';
	public const FORM_STORED_CUSTOMER     = 'stored_customer';

	public const FORM_PAYMENT_ID                 = 'payment_id';
	public const FORM_DEVICE_FINGERPRINT_PAYLOAD = 'device_fingerprint_payload';
	public const TROUBLESHOOTING_METHOD_ID       = 'custom_payment_gateway_troubleshooting';

	// Maybe this value is used for security check, when create fee requests
	public const FORM_GATEWAY_ID_FEE = '3d4ca9aa-9ae1-4a99-b8ac-1fccb8e54170';

	/*
	 * Display titles used for the fees the gateway owns. These titles MUST be
	 * the same strings FeeAction::add_fees() writes when surfacing the gateway's
	 * service fee, cash discount, and surcharge on the WC_Cart, so Builder can
	 * recognise them on both the cart (WC_Cart::get_fees()) and the order
	 * (WC_Order::get_fees() returning WC_Order_Item_Fee items, where the title
	 * is exposed via WC_Order_Item_Fee::get_name()) and exclude them from the
	 * third-party-fee top-up applied to $r->amounts. The order is the source
	 * of truth for the top-up; the cart entries are used only for parity.
	 * Changing any of these strings without updating FeeAction will silently
	 * re-introduce the third-party-fee regression that was fixed in v4.1.2
	 * and hardened in v4.1.3.
	 */
	public const GATEWAY_FEE_TITLE_SERVICE_FEE   = 'Gateway Service Fee';
	public const GATEWAY_FEE_TITLE_CASH_DISCOUNT = 'Gateway Cash Discount';
	public const GATEWAY_FEE_TITLE_SURCHARGE     = 'Gateway Surcharge';
	public const GATEWAY_FEE_TITLES              = [
		self::GATEWAY_FEE_TITLE_SERVICE_FEE,
		self::GATEWAY_FEE_TITLE_CASH_DISCOUNT,
		self::GATEWAY_FEE_TITLE_SURCHARGE,
	];

	/*
	 * WooCommerce order statuses that a transaction response can be mapped to.
	 * These match the slugs WooCommerce uses internally (wc- prefix stripped).
	 */
	public const WC_STATUS_PENDING    = 'pending';
	public const WC_STATUS_ON_HOLD    = 'on-hold';
	public const WC_STATUS_PROCESSING = 'processing';
	public const WC_STATUS_COMPLETED  = 'completed';
	public const WC_STATUS_CANCELLED  = 'cancelled';
	public const WC_STATUS_REFUNDED   = 'refunded';
	public const WC_STATUS_FAILED     = 'failed';

	/*
	 * Transaction response code boundaries returned by the gateway. The gateway
	 * groups response codes into ranges (see
	 * https://sandbox.fluidpay.com/docs/api/transactions_response):
	 *   0           - Unknown, contact support.
	 *   99          - Pending payment (redirect processors before payment is received).
	 *   100 - 199   - Approvals and partial approvals.
	 *   200 - 299   - Declines from the issuer.
	 *   300 - 399   - Gateway declines (configuration or fraud).
	 *   400 - 499   - Errors returned by the processor.
	 */
	public const RESPONSE_CODE_UNKNOWN             = 0;
	public const RESPONSE_CODE_PENDING             = 99;
	public const RESPONSE_CODE_APPROVAL_MIN        = 100;
	public const RESPONSE_CODE_APPROVAL_MAX        = 199;
	public const RESPONSE_CODE_DECLINE_MIN         = 200;
	public const RESPONSE_CODE_DECLINE_MAX         = 299;
	public const RESPONSE_CODE_GATEWAY_DECLINE_MIN = 300;
	public const RESPONSE_CODE_GATEWAY_DECLINE_MAX = 399;
	public const RESPONSE_CODE_PROCESSOR_ERROR_MIN = 400;
	public const RESPONSE_CODE_PROCESSOR_ERROR_MAX = 499;

	/*
	 * Gateway transaction statuses that represent a captured payment. The plugin
	 * does not poll the gateway for settlement after checkout, so a sale that is
	 * approved and awaiting batch settlement (pending_settlement) is treated the
	 * same as one that has already settled. Mirrors
	 * SubscriptionCron::is_last_transaction_successful().
	 */
	public const GW_TRANSACTION_STATUS_PENDING_SETTLEMENT = 'pending_settlement';
	public const GW_TRANSACTION_STATUS_SETTLED            = 'settled';
	public const GW_PAID_TRANSACTION_STATUSES             = [
		self::GW_TRANSACTION_STATUS_PENDING_SETTLEMENT,
		self::GW_TRANSACTION_STATUS_SETTLED,
	];
}
