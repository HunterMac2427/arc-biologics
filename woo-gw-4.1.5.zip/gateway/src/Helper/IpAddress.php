<?php declare( strict_types=1 );

namespace CustomPaymentGateway\Helper;

class IpAddress implements IpAddressInterface {

	private HttpInterface $http;

	/**
	 * IpAddress constructor.
	 */
	public function __construct( HttpInterface $http ) {
		$this->http = $http;
	}

	public function get_ip(): string {
		// Whether ip is from the remote address
		$ip = $this->http->server( 'REMOTE_ADDR' );
		if ( $ip ) {
			return $ip;
		}
		// Whether ip is from the proxy
		$ip = $this->http->server( 'HTTP_X_FORWARDED_FOR' );
		if ( $ip ) {
			return $ip;
		}
		// Whether ip is from the share internet
		$ip = $this->http->server( 'HTTP_CLIENT_IP' );
		if ( $ip ) {
			return $ip;
		}

		return '';
	}
}
