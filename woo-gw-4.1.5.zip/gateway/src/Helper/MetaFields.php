<?php declare( strict_types=1 );

namespace CustomPaymentGateway\Helper;

class MetaFields {
	public function __construct() {
	}

	/**
	 * @return string | boolean
	 */
	public function get_current_user_customer_id() {
		return get_user_meta( get_current_user_id(), Constants::META_CUSTOMER_ID, true );
	}

	public function update_current_user_customer_id( string $customer_id ) {
		update_user_meta( get_current_user_id(), Constants::META_CUSTOMER_ID, $customer_id );
	}

	/**
	 * @return string | boolean
	 */
	public function get_subscription_id( \WC_Subscription $subscription ) {
		return $subscription->get_meta( Constants::META_SUBSCRIPTION_ID );
	}

	public function update_subscription_id( \WC_Subscription $subscription, string $subscription_id ) {
		$subscription->update_meta_data( Constants::META_SUBSCRIPTION_ID, $subscription_id );
	}

	/**
	 * @return string | boolean
	 */
	public function get_plan_id( \WC_Product $product ) {
		return $product->get_meta( Constants::META_PLAN_ID );
	}

	public function update_plan_id( \WC_Product $product, string $plan_id ) {
		$product->update_meta_data( Constants::META_PLAN_ID, $plan_id );
	}
}
