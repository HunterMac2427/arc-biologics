<?php

namespace CustomPaymentGateway\Helper\Woocommerce;

use CustomPaymentGateway\Helper\Container;

class SessionManager {
	public Container $c;

	public function __construct( Container $c ) {
		$this->c = $c;
	}

	/**
	 * Get session of the arbitrary key's value
	 *
	 * @param $key
	 *
	 * @return string
	 */
	public function get_session( $key ): string {
		return WC()->session->get( $key ) ?: '';
	}

	/**
	 * Set session of the arbitrary key's value
	 *
	 * @param string $key
	 * @param $value
	 */
	public function set_session( string $key, $value ): void {
		if ( $value ) {
			WC()->session->set( $key, $value );
		}
	}

	/**
	 * Unset session of the arbitrary key's value
	 *
	 * @param $key
	 */
	public function unset_session( $key ): void {
		if ( function_exists( 'WC' ) && WC()->session && is_callable( [ WC()->session, 'get' ] ) ) {
			if ( WC()->session->get( $key ) ) {
				WC()->session->__unset( $key );
			}
		}
	}
}
