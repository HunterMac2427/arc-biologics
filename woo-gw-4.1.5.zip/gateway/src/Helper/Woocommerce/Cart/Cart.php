<?php declare( strict_types=1 );

namespace CustomPaymentGateway\Helper\Woocommerce\Cart;

use CustomPaymentGateway\Helper\Formatter;
use CustomPaymentGateway\Helper\WoocommerceSubscriptions;

class Cart {
	private CartItems $simple_items;
	private CartItems $recurring_items;

	/**
	 * @param \WC_Cart $cart
	 */
	public function __construct( \WC_Cart $cart ) {
		$this->set_simple_items( $cart );
		if ( WoocommerceSubscriptions::plugin_available() ) {
			$this->set_recurring_items( $cart );
		}
	}

	/**
	 * @return array
	 */
	public function get_simple_items(): array {
		return \iterator_to_array( $this->simple_items );
	}

	/**
	 * @return array|null
	 */
	public function get_recurring_items(): ?array {
		if ( ! WoocommerceSubscriptions::plugin_available() ) {
			return [];
		}

		return \iterator_to_array( $this->recurring_items );
	}

	/**
	 * @return int
	 */
	public function get_simple_line_total(): int {
		$total = 0;
		/** @var CartItem $item */
		foreach ( $this->get_simple_items() as $item ) {
			$total += Formatter::format_amount( $item->line_total );
		}

		return $total;
	}

	/**
	 * @return int
	 */
	public function get_simple_tax_total(): int {
		$total = 0;
		/** @var CartItem $item */
		foreach ( $this->get_simple_items() as $item ) {
			$total += Formatter::format_amount( $item->line_tax );
		}

		return $total;
	}

	/**
	 * @return int
	 */
	public function get_simple_total(): int {
		return $this->get_simple_line_total() + $this->get_simple_tax_total();
	}

	/**
	 * @param \WC_Cart $cart
	 */
	public function set_simple_items( \WC_Cart $cart ) {
		$items = new CartItems();
		foreach ( $cart->get_cart() as $item ) {
			if ( ! ( $item['data'] instanceof \WC_Product_Subscription ) ) {
				$items->add( new CartItem( $item ) );
			}
		}
		$this->simple_items = $items;
	}

	/**
	 * @param \WC_Cart $cart
	 */
	public function set_recurring_items( \WC_Cart $cart ) {
		$items = new CartItems();
		foreach ( $cart->get_cart() as $item ) {
			if ( $item['data'] instanceof \WC_Product_Subscription ) {
				$items->add( new CartItem( $item ) );
			}
		}
		$this->recurring_items = $items;
	}
}
