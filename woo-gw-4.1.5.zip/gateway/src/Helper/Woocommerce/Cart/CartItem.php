<?php declare( strict_types=1 );

namespace CustomPaymentGateway\Helper\Woocommerce\Cart;

class CartItem {
	public string $key;
	public int $product_id;
	public int $variation_id;
	public array $variation;
	/**
	 * @var float|int
	 */
	public $quantity;
	public string $data_hash;
	public array $line_tax_data;
	/**
	 * @var float|int
	 */
	public $line_subtotal;
	/**
	 * @var float|int
	 */
	public $line_subtotal_tax;
	/**
	 * @var float|int
	 */
	public $line_total;
	/**
	 * @var float|int
	 */
	public $line_tax;
	public \WC_Product $data;

	public function __construct( array $init = [] ) {
		foreach ( $init as $key => $data ) {
			if ( \property_exists( $this, $key ) ) {
				// NOTE: Edge case when the variation is empty, and it is represented as a string instead of array
				if ( $key === 'variation' && gettype( $data ) === 'string' ) {
					continue;
				}
				if ( $key === 'product_id' && gettype( $data ) === 'string' ) {
					$data = (int) $data;
				}
				$this->$key = $data;
			}
		}
	}

}
