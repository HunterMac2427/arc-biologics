<?php declare( strict_types=1 );

namespace CustomPaymentGateway\Helper\Woocommerce\Cart;

class CartItems implements \IteratorAggregate {
	/**
	 * @var CartItem[]
	 */
	private array $items = [];

	public function add( CartItem $item ) {
		$this->items[] = $item;
	}

	public function getIterator(): \ArrayIterator {
		return new \ArrayIterator( $this->items );
	}
}
