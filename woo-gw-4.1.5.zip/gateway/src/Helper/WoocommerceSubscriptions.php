<?php

namespace CustomPaymentGateway\Helper;

class WoocommerceSubscriptions {
	public static function is_change_payment_method_request(): bool {
		return isset( $_GET['change_payment_method'] );
	}

	public static function plugin_available(): bool {
		return class_exists( '\WC_Subscription' );
	}
}
