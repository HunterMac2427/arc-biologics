<?php

namespace CustomPaymentGateway\Helper;

interface IpAddressInterface {
	public function get_ip(): string;
}
