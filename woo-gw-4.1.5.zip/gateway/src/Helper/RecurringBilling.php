<?php declare( strict_types=1 );

namespace CustomPaymentGateway\Helper;

class RecurringBilling {
	public string $billing_frequency;
	public int $billing_cycle_interval;
	public string $billing_days;

	/**
	 * @param string      $period 'day', 'week', 'month', 'year'
	 * @param int         $interval
	 * @param string|null $trial_expiration_date
	 */
	public function __construct( string $period, int $interval, ?string $trial_expiration_date = null ) {
		switch ( $period ) {
			case 'day':
				if ( $interval < 3 ) {
					throw new \InvalidArgumentException( 'When daily billing period is used, the interval must be greater than every 3 days.' );
				}
				$this->billing_frequency      = 'daily';
				$this->billing_cycle_interval = 1;
				$this->billing_days           = $interval . '';
				break;
			case 'week':
				$this->billing_frequency      = 'daily';
				$this->billing_cycle_interval = $interval;
				$this->billing_days           = '7';
				break;
			case 'month':
				$this->billing_frequency      = 'monthly';
				$this->billing_cycle_interval = $interval;
				$this->billing_days           = $this->calculate_monthly_billing_days( $trial_expiration_date );
				break;
			case 'year':
				$this->billing_frequency      = 'monthly';
				$this->billing_cycle_interval = $interval * 12;
				$this->billing_days           = $this->calculate_monthly_billing_days( $trial_expiration_date );
				break;
			default:
				// TODO: Localize all exceptions in the plugin.
				throw new \InvalidArgumentException( 'Period is not of "day", "week", "month" or "year".' );
		}
	}

	/**
	 * Don't use API incompatible monthly billing days.
	 *
	 * @param string|null $trial_expiration_date
	 *
	 * @return string
	 */
	private function calculate_monthly_billing_days( ?string $trial_expiration_date ): string {
		$current_day = $trial_expiration_date ? wp_date( 'j', \strtotime( $trial_expiration_date ) ) : wp_date( 'j' );
		if ( $current_day === '29' ) {
			return '28';
		} elseif ( $current_day === '30' ) {
			return '31';
		} else {
			return $current_day;
		}
	}
}
