<?php
/**
 * Plugin Name: GW for WooCommerce
 * Description: WooCommerce Plugin for accepting payment through GW.
 * Version: 4.1.5
 * Author: GW
 * Contributors: GW
 * Requires PHP: 7.4
 * Requires at least: 6.0
 * WC requires at least: 6.6
 *
 * Text Domain: custom_payment_gateway
 * Domain Path: /l10n/
 */

use Automattic\WooCommerce\Utilities\FeaturesUtil;
use CustomPaymentGateway\CheckoutBlocks\CheckoutPaymentExtend_Blocks_Integration;
use CustomPaymentGateway\CheckoutBlocks\WC_Card_Blocks;
use CustomPaymentGateway\CheckoutBlocks\WC_ACH_Blocks;
use CustomPaymentGateway\Helper\Container;
use CustomPaymentGateway\Install;
use CustomPaymentGateway\Plugin;

defined( 'ABSPATH' ) || exit;

require 'autoload.php';

if ( in_array( 'woocommerce/woocommerce.php', apply_filters( 'active_plugins', get_option( 'active_plugins' ) ), true ) ) {
	register_activation_hook( __FILE__, 'custom_payment_gateway_activate' );

	$gw_plugin = new Plugin(
		new Container()
	);
	$gw_plugin->init();

	add_action(
		'before_woocommerce_init',
		function() {
			if ( class_exists( '\Automattic\WooCommerce\Utilities\FeaturesUtil' ) ) {
				FeaturesUtil::declare_compatibility(
					'cart_checkout_blocks',
					__FILE__,
					true
				);
				FeaturesUtil::declare_compatibility(
					'custom_order_tables',
					__FILE__,
					true
				);
			}
		}
	);

	add_action(
		'woocommerce_blocks_loaded',
		function() {
			if ( ! class_exists( 'Automattic\WooCommerce\Blocks\Payments\Integrations\AbstractPaymentMethodType' ) ) {
				return;
			}
			require_once 'src/CheckoutBlocks/WC_Card_Blocks.php';
			add_action(
				'woocommerce_blocks_payment_method_type_registration',
				function( Automattic\WooCommerce\Blocks\Payments\PaymentMethodRegistry $payment_method_registry ) {
					$payment_method_registry->register( new WC_Card_Blocks() );
				}
			);

			require_once 'src/CheckoutBlocks/WC_ACH_Blocks.php';
			add_action(
				'woocommerce_blocks_payment_method_type_registration',
				function( Automattic\WooCommerce\Blocks\Payments\PaymentMethodRegistry $payment_method_registry ) {
					$payment_method_registry->register( new WC_ACH_Blocks() );
				}
			);
		}
	);

	add_action(
		'woocommerce_blocks_loaded',
		function() {
			require_once __DIR__ . '/src/CheckoutBlocks/CheckoutPaymentExtend_Blocks_Integration.php';
			add_action(
				'woocommerce_blocks_cart_block_registration',
				function( $integration_registry ) {
					$integration_registry->register( new CheckoutPaymentExtend_Blocks_Integration() );
				}
			);
			add_action(
				'woocommerce_blocks_checkout_block_registration',
				function( $integration_registry ) {
					$integration_registry->register( new CheckoutPaymentExtend_Blocks_Integration() );
				}
			);
		}
	);

	add_action( 'block_categories_all', 'register_checkout_payment_extend_block_category', 10, 2 );
}

function custom_payment_gateway_activate() {
	$c              = new Container();
	$install        = new Install( $c );
	$updates        = $install->get_all_updates();
	$db_version_key = $install->get_db_version_key();
	if ( ! get_option( $db_version_key ) ) {
		update_option( $db_version_key, array_keys( $updates )[ count( $updates ) - 1 ] );
	}
}

/**
 * Registers the slug as a block category with WordPress.
 */
function register_checkout_payment_extend_block_category( $categories ) {
	return array_merge(
		$categories,
		[
			[
				'slug'  => 'checkout-payment-extend',
				'title' => __( 'CheckoutPaymentExtend Blocks', 'checkout-payment-extend' ),
			],
		]
	);
}
